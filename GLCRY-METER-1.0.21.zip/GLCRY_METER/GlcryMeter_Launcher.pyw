"""GLCRY METER launcher: installs any new update, then opens GLCRY METER.

The desktop shortcut runs this file.
"""

import subprocess
import sys
import threading
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

import os  # noqa: E402
from glcry import crash  # noqa: E402
crash.install(Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "GLCRY METER", APP_DIR)


def _wants_virtual_pad():
    import json
    try:
        cfg = json.loads((Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "GLCRY METER" / "app.json")
                         .read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    return int(cfg.get("mode", 0)) == 0


def start_obs():
    """Open OBS with its Virtual Camera already started, so the video just works.
    Skipped if OBS isn't installed, is already running, or app.json has "auto_obs": false."""
    if sys.platform != "win32":
        return
    import json
    try:
        cfg = json.loads((Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "GLCRY METER" / "app.json")
                         .read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    if cfg.get("auto_obs") is False:
        return
    if cfg.get("shot_mode") in ("macro", "secret"):
        return          # no video needed in these modes
    if cfg.get("auto_cam", True) is False:
        # you picked a capture device yourself (e.g. a capture card): OBS would
        # only hold that device or add delay, so leave it closed
        return
    exe = None
    for base in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)")):
        if base and (Path(base) / "obs-studio" / "bin" / "64bit" / "obs64.exe").exists():
            exe = Path(base) / "obs-studio" / "bin" / "64bit" / "obs64.exe"
            break
    if exe is None:
        return
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq obs64.exe", "/NH"], capture_output=True,
                             text=True, timeout=5, creationflags=0x08000000).stdout
        if "obs64.exe" in out.lower():
            return
        # OBS must be started from its own folder; --disable-shutdown-check avoids the
        # "OBS didn't shut down properly" prompt after a PC restart
        subprocess.Popen([str(exe), "--startvirtualcam", "--minimize-to-tray", "--disable-shutdown-check"],
                         cwd=str(exe.parent), creationflags=0x00000008)   # DETACHED_PROCESS
    except Exception:
        pass


def start_app():
    """Virtual controller users get GLCRY METER with admin rights (Windows asks
    once), which it needs to hide the real controller from the game. If they
    say No it still opens normally."""
    app_file = str(APP_DIR / "GlcryMeter.pyw")
    if sys.platform == "win32" and _wants_virtual_pad():
        try:
            from glcry import hidhide
            if not hidhide.is_admin() and hidhide.run_elevated(sys.executable, '"%s"' % app_file,
                                                                wait_s=0, cwd=str(APP_DIR)):
                return
        except Exception:
            pass
    subprocess.Popen([sys.executable, app_file], cwd=str(APP_DIR))


def main():
    from glcry import updater

    try:
        from PySide6.QtCore import Qt, QTimer
        from PySide6.QtWidgets import QApplication, QLabel, QProgressBar, QVBoxLayout, QWidget
    except Exception:
        start_obs()
        start_app()            # UI library missing: let the app report it
        return

    app = QApplication(sys.argv)
    w = QWidget()
    w.setWindowTitle("GLCRY METER")
    w.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
    w.setStyleSheet("QWidget{background:#0b0f15;color:#eef1f6;font-family:'Segoe UI';}"
                    "QWidget#frame{border:1px solid #2d3b50;border-radius:0px;}"
                    "QLabel{background:transparent;}"
                    "QLabel#t{font-size:24px;font-weight:800;letter-spacing:2px;} QLabel#s{color:#98a2b3;font-size:13px;}"
                    "QProgressBar{background:#141b26;border:0;border-radius:3px;max-height:6px;}"
                    "QProgressBar::chunk{background:#f2b93b;border-radius:3px;}")
    w.setObjectName("frame")
    w.setAttribute(Qt.WA_StyledBackground, True)
    v = QVBoxLayout(w)
    v.setContentsMargins(30, 26, 30, 26)
    v.setSpacing(10)
    t = QLabel("GLCRY <span style='color:#f2b93b'>METER</span>")
    t.setTextFormat(Qt.RichText)
    t.setObjectName("t")
    v.addWidget(t)
    s = QLabel("Checking for updates...")
    s.setObjectName("s")
    v.addWidget(s)
    bar = QProgressBar()
    bar.setTextVisible(False)
    bar.setRange(0, 0)
    v.addWidget(bar)
    w.resize(440, 140)
    w.show()

    state = {"text": "Checking for updates...", "p": None, "done": False}

    def work():
        try:
            m, zurl = updater.check()
            if m:
                state["text"] = "Downloading update %s..." % m["version"]
                data = updater.download(m, zurl, progress=lambda f: state.__setitem__("p", f))
                state["text"] = "Installing update %s..." % m["version"]
                state["p"] = None
                if updater.install(data):
                    state["text"] = "Installing new components..."
                    updater.install_requirements()
                state["text"] = "Updated to %s" % m["version"]
        except Exception as exc:
            state["text"] = "Update skipped: %s" % exc
        state["done"] = True

    threading.Thread(target=work, daemon=True).start()

    def tick():
        s.setText(state["text"])
        if state["p"] is None:
            bar.setRange(0, 0)
        else:
            bar.setRange(0, 1000)
            bar.setValue(int(state["p"] * 1000))
        if state["done"]:
            timer.stop()
            start_obs()
            start_app()
            QTimer.singleShot(400, app.quit)

    timer = QTimer()
    timer.timeout.connect(tick)
    timer.start(80)
    app.exec()


if __name__ == "__main__":
    main()
