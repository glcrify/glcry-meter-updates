"""Secret: release on the game's own vibration (offline only).

  Button shot: press X (Square). Secret holds X for you until the game
  vibrates the controller, then lets go that instant.

  Shot stick: push the right stick in any direction. Secret holds the right
  stick straight down (no left or right at all) until the game vibrates the
  controller, then centres it that instant.

No values to set. The vibration arrives as a notification on GLCRY METER's
virtual controller; the release is pushed to the game from that same
notification, so nothing waits on a timer or a video frame.

After the release, your real X / right stick is kept from the game until you
let go of it (or the stick comes back to the centre), so the game sees one
clean shot. If no vibration comes within SAFETY_S, the shot is let go anyway
so nothing stays stuck.
"""

import threading
import time

X, RX, RY = 16, 21, 22          # GLCRY METER layout: RY +100 = stick down
STICK_START = 35                # right-stick travel (0-100) that starts a stick shot
STICK_CENTRE = 20               # back inside this = stick let go
SAFETY_S = 3.0


class Secret:
    def __init__(self, log=None):
        self.log = log
        self.enabled = False
        self.lock = threading.Lock()
        self.kind = None             # "x" / "stick" while a shot is held
        self.t0 = 0.0
        self.block_x = False
        self.block_stick = False
        self.prev_x = False
        self.prev_stick = False
        self.prev_rumble = 0
        self.last = ""
        self.shots = 0

    # called from the virtual controller's notification thread
    def on_rumble(self, large, small):
        """-> True if this vibration released a shot (caller pushes it now)."""
        total = int(large) + int(small)
        rising = total > self.prev_rumble
        self.prev_rumble = total
        if not (self.enabled and rising and total > 0):
            return False
        with self.lock:
            if self.kind is None:
                return False
            ms = (time.perf_counter() - self.t0) * 1000.0
            self.last = "%s released on vibration after %.0f ms" % (
                "X" if self.kind == "x" else "Shot stick", ms)
            if self.kind == "x":
                self.block_x = True
            else:
                self.block_stick = True
            self.kind = None
            self.shots += 1
        return True

    def apply(self, v, now=None):
        """Modify one controller snapshot `v` (list) in place."""
        x_down = v[X] >= 50
        stick_out = max(abs(v[RX]), abs(v[RY])) >= STICK_START
        stick_centre = max(abs(v[RX]), abs(v[RY])) < STICK_CENTRE
        if not self.enabled:
            self.kind, self.block_x, self.block_stick = None, False, False
            self.prev_x, self.prev_stick = x_down, stick_out
            return v
        now = time.perf_counter() if now is None else now
        with self.lock:
            x_press = x_down and not self.prev_x
            stick_press = stick_out and not self.prev_stick
            self.prev_x, self.prev_stick = x_down, stick_out

            if self.kind is None:
                if x_press and not self.block_x:
                    self.kind, self.t0 = "x", now
                elif stick_press and not self.block_stick:
                    self.kind, self.t0 = "stick", now

            if self.kind is not None and now - self.t0 > SAFETY_S:
                self.last = "No vibration within %.0f s - let go anyway" % SAFETY_S
                if self.kind == "x":
                    self.block_x = True
                else:
                    self.block_stick = True
                self.kind = None

            if self.kind == "x":
                v[X] = 100.0
            elif self.kind == "stick":
                v[RX], v[RY] = 0.0, 100.0

            if self.block_x:
                if x_down:
                    v[X] = 0.0
                else:
                    self.block_x = False
            if self.block_stick:
                if not stick_centre:
                    v[RX], v[RY] = 0.0, 0.0
                else:
                    self.block_stick = False
        return v
