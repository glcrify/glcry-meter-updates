"""GLCRY METER controller hider - needs admin rights.

Called directly by GLCRY METER when it runs as admin, or started on its own
with a Windows prompt when it doesn't.

Reads  %LOCALAPPDATA%\\NovaCV\\hidhide_request.json  {"id": ..., "action": "on"|"off"}
Writes %LOCALAPPDATA%\\NovaCV\\hidhide_result.json   {"id": ..., "ok": ..., ...}

on:  hide every game controller plugged in right now (GLCRY METER asks for
     this BEFORE it creates its virtual controller, so that one stays
     visible), let GLCRY METER's Python still see them, and switch hiding on.
off: switch hiding off, so the game sees your controller normally again.
"""

import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "NovaCV"
REQ = ROOT / "hidhide_request.json"
RES = ROOT / "hidhide_result.json"
NO_WINDOW = 0x08000000


def find_cli():
    for base in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramW6432", "")):
        if not base:
            continue
        root = Path(base) / "Nefarius Software Solutions"
        for p in (root / "HidHide" / "x64" / "HidHideCLI.exe", root / "HidHide" / "HidHideCLI.exe"):
            if p.exists():
                return str(p)
        if root.exists():
            for p in root.rglob("HidHideCLI.exe"):
                return str(p)
    return None


def run(cli, *args):
    r = subprocess.run([cli, *args], capture_output=True, text=True, timeout=20, creationflags=NO_WINDOW)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def gaming_devices(cli):
    """-> [(name, [instance paths])] for game controllers that are plugged in."""
    rc, out = run(cli, "--dev-gaming")
    try:
        data = json.loads(out[out.index("["):])
    except Exception:
        return [], out.strip()[:300]
    found = []

    def walk(node, name=""):
        if isinstance(node, list):
            for x in node:
                walk(x, name)
        elif isinstance(node, dict):
            name = node.get("friendlyName") or name
            if "deviceInstancePath" in node and node.get("present", True):
                desc = "%s %s" % (name, node.get("description", ""))
                if "vigem" not in desc.lower():
                    paths = [node.get("deviceInstancePath"), node.get("baseContainerDeviceInstancePath")]
                    found.append((name or node.get("description") or "controller", [p for p in paths if p]))
            for v in node.values():
                if isinstance(v, (list, dict)):
                    walk(v, name)
    walk(data)
    return found, ""


def handle(req):
    cli = find_cli()
    if not cli:
        return {"ok": False, "error": "HidHide isn't installed - run GLCRY METER Setup again."}
    if req.get("action") == "off":
        rc, out = run(cli, "--cloak-off")
        return {"ok": rc == 0, "error": out.strip()[:300] if rc else ""}
    exe_dir = Path(sys.executable).parent
    for exe in ("pythonw.exe", "python.exe"):
        if (exe_dir / exe).exists():
            run(cli, "--app-reg", str(exe_dir / exe))
    devs, err = gaming_devices(cli)
    hidden = []
    for name, paths in devs:
        for p in paths:
            run(cli, "--dev-hide", p)
        hidden.append(name)
    rc, out = run(cli, "--cloak-on")
    return {"ok": rc == 0 and bool(hidden), "hidden": hidden,
            "error": (out.strip()[:300] if rc else "") or (err if not hidden else "")
            or ("" if hidden else "No controller found - plug it in and press Apply output.")}


def main():
    try:
        req = json.loads(REQ.read_text(encoding="utf-8"))
    except Exception:
        return
    if time.time() - float(req.get("time", 0)) > 120:
        return                                  # stale request
    try:
        res = handle(req)
    except Exception as exc:
        res = {"ok": False, "error": str(exc)}
    res["id"] = req.get("id")
    tmp = RES.with_suffix(".tmp")
    tmp.write_text(json.dumps(res), encoding="utf-8")
    tmp.replace(RES)


if __name__ == "__main__":
    main()
