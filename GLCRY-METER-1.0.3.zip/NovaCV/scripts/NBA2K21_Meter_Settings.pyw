"""NBA 2K21 Meter - settings app (for script v4.4).

Double-click to open (needs Python 3 for Windows; tkinter is included).
Edits the settings file that NBA2K21_Meter.py reads. Changes save
automatically and the running script picks them up within about a second;
the Helios overlay shows "(settings updated)" when it does.

With verdict tuning on, the script tunes the lead from 2K's TIMING text after every shot;
this window shows the new value as it changes.
"""

import glob
import json
import os
import tkinter as tk
from tkinter import filedialog, ttk

SETTINGS_FILE = "settings_v6.json"
SCRIPT_NAME = "NBA2K21_Meter"

# Defaults must match SETTINGS in NBA2K21_Meter.py
DEFAULTS = {
    "lead_ms": 40,
    "auto_calibrate": True,
    "target_offset": 0.0,
    "target_mode": "center",
    "shoot_mode": "button",
    "enabled_on_start": True,
    "debug_overlay": True,
    "use_2k_verdict": True,
    "meter_overlay": False,
    "speed_samples": 10,
    "min_samples": 4,
    "search_step": 2,
}


def find_settings_file():
    """Newest settings file the script wrote, under Helios or GLCRY METER."""
    la = os.environ.get("LOCALAPPDATA", "")
    bases = [os.path.join(la, "NovaCV", "ScriptData"),
             os.path.join(la, "HeliosProject", "Helios", "ScriptData")]
    dirs, found = [], []
    for base in bases:
        for d in sorted(glob.glob(os.path.join(base, "*" + SCRIPT_NAME + "*"))):
            dirs.append(d)
            p = os.path.join(d, SETTINGS_FILE)
            if os.path.isfile(p):
                found.append(p)
    if found:
        return max(found, key=os.path.getmtime)
    if dirs:
        return os.path.join(dirs[0], SETTINGS_FILE)
    return None


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("2K21 Meter Settings")
        self.resizable(False, False)
        self.path = find_settings_file()
        self.data = {}
        self._save_job = None
        self._loading = False

        pad = {"padx": 10, "pady": 4}
        root = ttk.Frame(self, padding=12)
        root.grid(sticky="nsew")

        # --- file -----------------------------------------------------------
        ff = ttk.Frame(root)
        ff.grid(row=0, column=0, sticky="ew")
        self.path_var = tk.StringVar()
        ttk.Label(ff, textvariable=self.path_var, foreground="#666", wraplength=420).grid(row=0, column=0, sticky="w")
        ttk.Button(ff, text="Browse...", command=self.browse).grid(row=0, column=1, padx=(8, 0))

        # --- timing ---------------------------------------------------------
        tf = ttk.LabelFrame(root, text="Release timing", padding=10)
        tf.grid(row=1, column=0, sticky="ew", pady=(10, 4))

        self.lead = tk.IntVar(value=DEFAULTS["lead_ms"])
        ttk.Label(tf, text="Lead (ms): how far ahead of the target the script lets go.\n"
                           "Higher = releases EARLIER.  Shots early -> lower it.  Shots late -> raise it.",
                  justify="left").grid(row=0, column=0, columnspan=4, sticky="w")
        big = ttk.Label(tf, textvariable=self.lead, font=("Segoe UI", 22, "bold"), width=4, anchor="center")
        big.grid(row=1, column=1, columnspan=2, pady=4)
        ttk.Button(tf, text="-5", width=5, command=lambda: self.bump(-5)).grid(row=1, column=0)
        ttk.Button(tf, text="+5", width=5, command=lambda: self.bump(5)).grid(row=1, column=3)
        s = ttk.Scale(tf, from_=0, to=400, orient="horizontal", length=380,
                      command=lambda v: self.set_lead(int(float(v))))
        s.grid(row=2, column=0, columnspan=4, pady=4)
        self.lead_scale = s
        qb = ttk.Frame(tf)
        qb.grid(row=3, column=0, columnspan=4, pady=(6, 0))
        ttk.Button(qb, text="Shots EARLY  (-5 ms)", command=lambda: self.bump(-5)).grid(row=0, column=0, padx=4)
        ttk.Button(qb, text="Shots LATE  (+5 ms)", command=lambda: self.bump(5)).grid(row=0, column=1, padx=4)
        ttk.Button(qb, text="-1", width=4, command=lambda: self.bump(-1)).grid(row=0, column=2, padx=(12, 2))
        ttk.Button(qb, text="+1", width=4, command=lambda: self.bump(1)).grid(row=0, column=3, padx=2)
        self.auto = tk.BooleanVar(value=True)
        ttk.Checkbutton(tf, text="Fallback auto-calibrate (only when no TIMING verdict is read)",
                        variable=self.auto, command=self.changed).grid(row=4, column=0, columnspan=4,
                                                                       sticky="w", pady=(8, 0))
        self.verdict = tk.BooleanVar(value=True)
        ttk.Checkbutton(tf, text="Tune lead from 2K's TIMING verdict (recommended, works on its own)",
                        variable=self.verdict, command=self.changed).grid(row=5, column=0, columnspan=4,
                                                                          sticky="w")
        self.last_shot = tk.StringVar(value="")
        ttk.Label(tf, textvariable=self.last_shot, foreground="#555").grid(row=6, column=0, columnspan=4,
                                                                           sticky="w", pady=(4, 0))

        # --- target ---------------------------------------------------------
        gf = ttk.LabelFrame(root, text="Target", padding=10)
        gf.grid(row=2, column=0, sticky="ew", pady=4)
        ttk.Label(gf, text="Aim at").grid(row=0, column=0, sticky="w")
        self.mode = tk.StringVar(value=DEFAULTS["target_mode"])
        for i, (val, txt) in enumerate((("center", "Zone centre (recommended)"), ("start", "Zone start"), ("slit", "Slit (old)"))):
            ttk.Radiobutton(gf, text=txt, value=val, variable=self.mode,
                            command=self.changed).grid(row=0, column=i + 1, padx=6)
        ttk.Label(gf, text="Fine trim (% of bar, + = later)").grid(row=1, column=0, columnspan=2, sticky="w", pady=(8, 0))
        self.trim = tk.DoubleVar(value=0.0)
        sp = ttk.Spinbox(gf, from_=-10.0, to=10.0, increment=0.5, width=7, textvariable=self.trim,
                         command=self.changed)
        sp.grid(row=1, column=2, sticky="w", pady=(8, 0))
        sp.bind("<KeyRelease>", lambda e: self.changed())

        # --- controls -------------------------------------------------------
        cf = ttk.LabelFrame(root, text="Controls & display", padding=10)
        cf.grid(row=3, column=0, sticky="ew", pady=4)
        ttk.Label(cf, text="Shoot with").grid(row=0, column=0, sticky="w")
        self.shoot = tk.StringVar(value=DEFAULTS["shoot_mode"])
        ttk.Radiobutton(cf, text="Button (Square / X)", value="button", variable=self.shoot,
                        command=self.changed).grid(row=0, column=1, padx=6)
        ttk.Radiobutton(cf, text="Shot stick", value="stick", variable=self.shoot,
                        command=self.changed).grid(row=0, column=2, padx=6)
        self.enabled = tk.BooleanVar(value=True)
        self.overlay = tk.BooleanVar(value=True)
        ttk.Checkbutton(cf, text="On when script starts", variable=self.enabled,
                        command=self.changed).grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        ttk.Checkbutton(cf, text="Show overlay", variable=self.overlay,
                        command=self.changed).grid(row=1, column=2, sticky="w", pady=(6, 0))
        self.meter_ov = tk.BooleanVar(value=True)
        ttk.Checkbutton(cf, text="Helios meter readout (TIME / DISTANCE / SPEED / ETA)",
                        variable=self.meter_ov, command=self.changed).grid(row=2, column=0, columnspan=3,
                                                                           sticky="w")

        # --- advanced -------------------------------------------------------
        af = ttk.LabelFrame(root, text="Advanced", padding=10)
        af.grid(row=4, column=0, sticky="ew", pady=4)
        self.samples = tk.IntVar(value=DEFAULTS["speed_samples"])
        self.min_samples = tk.IntVar(value=DEFAULTS["min_samples"])
        self.step = tk.IntVar(value=DEFAULTS["search_step"])
        for r, (txt, var, lo, hi) in enumerate((
                ("Speed fit frames", self.samples, 3, 16),
                ("Min readings before release", self.min_samples, 2, 6),
                ("Search stride (1 = slower, finds smaller meters)", self.step, 1, 3))):
            ttk.Label(af, text=txt).grid(row=r, column=0, sticky="w")
            w = ttk.Spinbox(af, from_=lo, to=hi, width=5, textvariable=var, command=self.changed)
            w.grid(row=r, column=1, sticky="e", padx=(10, 0))
            w.bind("<KeyRelease>", lambda e: self.changed())

        # --- footer ---------------------------------------------------------
        bf = ttk.Frame(root)
        bf.grid(row=5, column=0, sticky="ew", pady=(8, 0))
        ttk.Button(bf, text="Reset to defaults", command=self.reset).grid(row=0, column=0)
        self.status = tk.StringVar()
        ttk.Label(bf, textvariable=self.status, foreground="#2a7").grid(row=0, column=1, padx=10)

        self._mtime = None
        self.load()
        self.after(1000, self.poll)

    def poll(self):
        """Show changes the script made (auto-calibrated lead)."""
        try:
            if self.path and self._save_job is None and os.path.isfile(self.path):
                mt = os.path.getmtime(self.path)
                if self._mtime is not None and mt != self._mtime:
                    old = self.lead.get()
                    self.load()
                    if self.lead.get() != old:
                        self.status.set("Script auto-tuned lead: %d -> %d ms" % (old, self.lead.get()))
        except OSError:
            pass
        self.show_last_shot()
        self.after(1000, self.poll)

    def show_last_shot(self):
        """Last 2K verdict from the script's shot log."""
        if not self.path:
            return
        log = os.path.join(os.path.dirname(self.path), "shots_log.txt")
        try:
            with open(log, "rb") as f:
                f.seek(0, 2)
                f.seek(max(0, f.tell() - 4096))
                lines = f.read().decode("utf-8", "ignore").splitlines()
            for line in reversed(lines):
                try:
                    rec = json.loads(line)
                except ValueError:
                    continue
                if "verdict" in rec:
                    self.last_shot.set("Last shot: 2K said %s  (lead then %s ms)"
                                       % (rec["verdict"], rec.get("lead_at_release")))
                    return
        except OSError:
            pass

    # ----- file -------------------------------------------------------------
    def browse(self):
        p = filedialog.askopenfilename(title="Find " + SETTINGS_FILE,
                                       filetypes=[("Settings", SETTINGS_FILE), ("JSON", "*.json")])
        if p:
            self.path = p
            self.load()

    def load(self):
        self._loading = True
        if not self.path:
            self.path_var.set("Settings file not found. Run NBA2K21_Meter.py in Helios once, "
                              "then reopen this app (or Browse to " + SETTINGS_FILE + ").")
            self.data = dict(DEFAULTS)
        else:
            self.path_var.set(self.path)
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    self.data = json.load(f)
                self._mtime = os.path.getmtime(self.path)
            except (OSError, ValueError):
                self.data = {}
        d = dict(DEFAULTS)
        d.update({k: v for k, v in self.data.items() if k in DEFAULTS})
        self.set_lead(int(d["lead_ms"]), save=False)
        self.auto.set(bool(d["auto_calibrate"]))
        self.verdict.set(bool(d["use_2k_verdict"]))
        self.meter_ov.set(bool(d["meter_overlay"]))
        self.trim.set(round(float(d["target_offset"]) * 100, 2))
        self.mode.set(d["target_mode"])
        self.shoot.set(d["shoot_mode"])
        self.enabled.set(bool(d["enabled_on_start"]))
        self.overlay.set(bool(d["debug_overlay"]))
        self.samples.set(int(d["speed_samples"]))
        self.min_samples.set(int(d["min_samples"]))
        self.step.set(int(d["search_step"]))
        self._loading = False

    def collect(self):
        def num(var, lo, hi, cast):
            try:
                return max(lo, min(hi, cast(var.get())))
            except (tk.TclError, ValueError):
                return None
        vals = {
            "lead_ms": num(self.lead, 0, 400, int),
            "auto_calibrate": bool(self.auto.get()),
            "use_2k_verdict": bool(self.verdict.get()),
            "meter_overlay": bool(self.meter_ov.get()),
            "target_offset": None if num(self.trim, -10.0, 10.0, float) is None
            else round(num(self.trim, -10.0, 10.0, float) / 100.0, 4),
            "target_mode": self.mode.get(),
            "shoot_mode": self.shoot.get(),
            "enabled_on_start": bool(self.enabled.get()),
            "debug_overlay": bool(self.overlay.get()),
            "speed_samples": num(self.samples, 3, 16, int),
            "min_samples": num(self.min_samples, 2, 6, int),
            "search_step": num(self.step, 1, 3, int),
        }
        return {k: v for k, v in vals.items() if v is not None}

    def save(self):
        self._save_job = None
        if not self.path:
            self.status.set("Not saved - settings file not found")
            return
        merged = dict(self.data)       # keep every other key the script wrote
        merged.update(self.collect())
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(merged, f, indent=2)
            os.replace(tmp, self.path)  # atomic: the script never reads half a file
            self._mtime = os.path.getmtime(self.path)
            self.data = merged
            self.status.set("Saved - lead %d ms" % merged["lead_ms"])
        except OSError as exc:
            self.status.set("Save failed: %s" % exc)

    # ----- events -----------------------------------------------------------
    def changed(self):
        if self._loading:
            return
        if self._save_job:
            self.after_cancel(self._save_job)
        self._save_job = self.after(250, self.save)

    def set_lead(self, v, save=True):
        v = max(0, min(400, int(v)))
        if self.lead.get() != v or not save:
            self.lead.set(v)
        if abs(float(self.lead_scale.get()) - v) >= 1:
            self.lead_scale.set(v)
        if save:
            self.changed()

    def bump(self, d):
        self.set_lead(self.lead.get() + d)

    def reset(self):
        self._loading = True
        self.set_lead(DEFAULTS["lead_ms"], save=False)
        self.auto.set(DEFAULTS["auto_calibrate"])
        self.verdict.set(DEFAULTS["use_2k_verdict"])
        self.meter_ov.set(DEFAULTS["meter_overlay"])
        self.trim.set(0.0)
        self.mode.set(DEFAULTS["target_mode"])
        self.shoot.set(DEFAULTS["shoot_mode"])
        self.enabled.set(DEFAULTS["enabled_on_start"])
        self.overlay.set(DEFAULTS["debug_overlay"])
        self.samples.set(DEFAULTS["speed_samples"])
        self.min_samples.set(DEFAULTS["min_samples"])
        self.step.set(DEFAULTS["search_step"])
        self._loading = False
        self.changed()


if __name__ == "__main__":
    App().mainloop()
