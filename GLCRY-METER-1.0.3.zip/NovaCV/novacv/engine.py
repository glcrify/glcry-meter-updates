"""Capture, script running and stats. No UI code here."""

import importlib.util
import io
import os
import sys
import threading
import time
import traceback
from collections import deque
from pathlib import Path

import cv2
import numpy as np

APP_NAME = "GLCRY METER"
APP_DIR_NAME = "NovaCV"

_COMPAT = Path(__file__).resolve().parent / "compat"
if str(_COMPAT) not in sys.path:
    sys.path.insert(0, str(_COMPAT))

from helios import controls as h_controls  # noqa: E402  (our stand-in package)
from helios import overlay as h_overlay    # noqa: E402
from helios import vision as h_vision      # noqa: E402


def data_root():
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / ".local" / "share")
    return Path(base) / APP_DIR_NAME


def list_cameras(max_index=8):
    """[(index, name)] for DirectShow video devices."""
    names = []
    try:
        from pygrabber.dshow_graph import FilterGraph  # optional, Windows only
        names = FilterGraph().get_input_devices()
    except Exception:
        names = []
    if names:
        return list(enumerate(names))
    return [(i, "Camera %d" % i) for i in range(max_index)]


def find_obs_camera():
    """Index of 'OBS Virtual Camera' (or any OBS video device), else None."""
    try:
        from pygrabber.dshow_graph import FilterGraph
        names = FilterGraph().get_input_devices()
    except Exception:
        return None
    for i, n in enumerate(names):
        if "obs" in n.lower():
            return i
    return None


class Log:
    """Thread-safe log lines for the UI console."""

    def __init__(self, maxlen=2000):
        self.lines = deque(maxlen=maxlen)
        self.lock = threading.Lock()
        self.seq = 0
        self.file = None
        try:
            d = data_root() / "reports"
            d.mkdir(parents=True, exist_ok=True)
            p = d / "novacv.log"
            if p.exists() and p.stat().st_size > 2_000_000:
                p.replace(d / "novacv.old.log")
            self.file = open(p, "a", encoding="utf-8", buffering=1)
        except Exception:
            self.file = None

    def write(self, msg):
        msg = msg.rstrip("\n")
        if not msg:
            return
        stamp = time.strftime("%H:%M:%S")
        with self.lock:
            for ln in msg.split("\n"):
                self.lines.append("[%s] %s" % (stamp, ln))
                self.seq += 1
                if self.file is not None:
                    try:
                        self.file.write("%s %s\n" % (time.strftime("%Y-%m-%d"), self.lines[-1]))
                    except Exception:
                        pass

    def snapshot(self):
        with self.lock:
            return self.seq, list(self.lines)


class _ScriptStdout(io.TextIOBase):
    """Routes print() from scripts into the log."""

    def __init__(self, log, prefix):
        self.log, self.prefix, self.buf = log, prefix, ""

    def write(self, s):
        self.buf += s
        while "\n" in self.buf:
            line, self.buf = self.buf.split("\n", 1)
            self.log.write(self.prefix + line)
        return len(s)

    def flush(self):
        if self.buf:
            self.log.write(self.prefix + self.buf)
            self.buf = ""


# ----------------------------------------------------------------------------
# Capture
# ----------------------------------------------------------------------------
class FrameSource:
    """Grabs frames on its own thread; keeps only the newest."""

    def __init__(self, log):
        self.log = log
        self.cap = None
        self.thread = None
        self.running = False
        self.cond = threading.Condition()
        self.frame = None
        self.ts_ns = 0
        self.seq = 0
        self.size = (0, 0)
        self.fps_measured = 0.0
        self.is_file = False

    def open(self, source, width=1920, height=1080, fps=240, backend="dshow"):
        self.close()
        self.is_file = isinstance(source, str)
        if self.is_file:
            cap = cv2.VideoCapture(source)
            self.file_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        else:
            api = {"dshow": getattr(cv2, "CAP_DSHOW", 0), "msmf": getattr(cv2, "CAP_MSMF", 0)}.get(backend, 0)
            cap = cv2.VideoCapture(int(source), api)
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
            cap.set(cv2.CAP_PROP_FPS, fps)
            try:
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            except Exception:
                pass
        if not cap.isOpened():
            self.log.write("Capture: could not open %s" % (source,))
            return False
        ok, frame = cap.read()
        if not ok or frame is None:
            self.log.write("Capture: opened %s but no frames arrive" % (source,))
            cap.release()
            return False
        self.cap = cap
        self.size = (frame.shape[1], frame.shape[0])
        self.log.write("Capture: %s at %dx%d (requested %d fps, device reports %.0f)" % (
            source, self.size[0], self.size[1], fps, cap.get(cv2.CAP_PROP_FPS)))
        self.running = True
        self.thread = threading.Thread(target=self._loop, name="capture", daemon=True)
        self.thread.start()
        return True

    def _loop(self):
        n, t_win = 0, time.perf_counter()
        next_t = time.perf_counter()
        while self.running:
            ok, frame = self.cap.read()
            if not ok or frame is None:
                if self.is_file:
                    self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)   # loop recordings
                    continue
                time.sleep(0.005)
                continue
            if self.is_file:                                     # play at real speed
                next_t += 1.0 / self.file_fps
                d = next_t - time.perf_counter()
                if d > 0:
                    time.sleep(d)
                else:
                    next_t = time.perf_counter()
            ts = time.perf_counter_ns()
            if frame.shape[1] != self.size[0] or frame.shape[0] != self.size[1]:
                self.size = (frame.shape[1], frame.shape[0])
            with self.cond:
                self.frame, self.ts_ns = frame, ts
                self.seq += 1
                self.cond.notify_all()
            n += 1
            now = time.perf_counter()
            if now - t_win >= 1.0:
                self.fps_measured = n / (now - t_win)
                n, t_win = 0, now

    def wait_new(self, last_seq, timeout=0.25):
        with self.cond:
            if self.seq == last_seq:
                self.cond.wait(timeout)
            return self.frame, self.ts_ns, self.seq

    def close(self):
        self.running = False
        if self.thread is not None:
            self.thread.join(timeout=1.0)
            self.thread = None
        if self.cap is not None:
            self.cap.release()
            self.cap = None
        with self.cond:
            self.frame = None
            self.cond.notify_all()


# ----------------------------------------------------------------------------
# Script engine
# ----------------------------------------------------------------------------
class Engine:
    """Runs the selected CV script on every new frame."""

    def __init__(self, log, output):
        self.log = log
        self.source = FrameSource(log)
        self.output = output                 # object with get_actual/send_cvdata
        h_controls._host = self
        # print() from scripts (and anything else) goes to the console panel
        if not isinstance(sys.stdout, _ScriptStdout):
            sys.stdout = _ScriptStdout(log, "")
        if sys.stderr is None:                     # pythonw has no console
            sys.stderr = _ScriptStdout(log, "[error] ")
        self.script_path = None
        self.module = None
        self.worker = None
        self.worker_size = None
        self.running = False
        self.thread = None
        self.lock = threading.Lock()
        # published for the UI
        self.display = (None, [], 0)         # (frame, overlay commands, seq)
        self.stats = {"script_fps": 0.0, "process_ms": 0.0, "jitter_ms": 0.0, "capture_fps": 0.0}
        self.last_packet = bytes(48)
        self.error = None

    # controls host interface ---------------------------------------------
    def get_actual(self, identifier):
        out = self.output
        return out.get_actual(identifier) if out is not None else 0.0

    def send_cvdata(self, data):
        self.last_packet = data
        out = self.output
        if out is not None:
            out.send_cvdata(data)

    def set_output(self, output):
        old = self.output
        self.output = output
        if old is not None and old is not output:
            try:
                old.close()
            except Exception:
                pass

    # script lifecycle ------------------------------------------------------
    def load_script(self, path):
        self.stop_script()
        path = Path(path)
        data_dir = data_root() / "ScriptData" / path.stem
        data_dir.mkdir(parents=True, exist_ok=True)
        os.environ["HELIOS_SCRIPT_DATA_DIR"] = str(data_dir)
        name = "novacv_script_%s" % abs(hash(str(path)))
        try:
            spec = importlib.util.spec_from_file_location(name, str(path))
            mod = importlib.util.module_from_spec(spec)
            sys.path.insert(0, str(path.parent))
            try:
                spec.loader.exec_module(mod)
            finally:
                try:
                    sys.path.remove(str(path.parent))
                except ValueError:
                    pass
        except Exception:
            self.log.write("Script %s failed to load:\n%s" % (path.name, traceback.format_exc()))
            self.error = "the script failed to load"
            return False
        if not hasattr(mod, "CVWorker"):
            self.log.write("Script %s has no CVWorker class" % path.name)
            self.error = "not a CV script"
            return False
        self.module = mod
        self.script_path = path
        self.log.write("Started script: %s  (data: %s)" % (path.name, data_dir))
        self.error = None
        self.running = True
        self.thread = threading.Thread(target=self._loop, name="script", daemon=True)
        self.thread.start()
        return True

    def stop_script(self):
        self.running = False
        if self.thread is not None:
            self.thread.join(timeout=2.0)
            self.thread = None
        self._close_worker()
        self.module = None
        if self.script_path is not None:
            self.log.write("Stopped script: %s" % self.script_path.name)
        self.script_path = None
        self.send_cvdata(bytes(48))          # release all overrides

    def _close_worker(self):
        w = self.worker
        self.worker = None
        self.worker_size = None
        if w is not None and hasattr(w, "close"):
            try:
                w.close()
            except Exception:
                self.log.write("Script close() error:\n" + traceback.format_exc())

    def _loop(self):
        last_seq = 0
        times = deque(maxlen=240)
        starts = deque(maxlen=240)
        n, t_win = 0, time.perf_counter()
        while self.running:
            frame, ts, seq = self.source.wait_new(last_seq)
            if frame is None or seq == last_seq:
                # no video: keep the controller passthrough alive
                continue
            last_seq = seq
            h, w = frame.shape[:2]
            if self.worker is None or self.worker_size != (w, h):
                self._close_worker()
                try:
                    self.worker = self.module.CVWorker(w, h)
                    self.worker_size = (w, h)
                except Exception:
                    self._fail("CVWorker(%d, %d) failed" % (w, h))
                    return
            h_vision._frame = frame
            h_vision._frame_ts_ns = ts
            h_overlay._size = (w, h)
            h_overlay._cmds = []
            t0 = time.perf_counter()
            starts.append(t0)
            try:
                self.worker.process(frame)
            except Exception:
                self._fail("process() error")
                return
            dt = (time.perf_counter() - t0) * 1000.0
            times.append(dt)
            cmds = h_overlay.take()
            with self.lock:
                self.display = (frame, cmds, seq)
            n += 1
            now = time.perf_counter()
            if now - t_win >= 0.5:
                iv = np.diff(np.array(starts)) * 1000.0 if len(starts) > 2 else np.array([0.0])
                self.stats = {"script_fps": n / (now - t_win),
                              "process_ms": float(np.mean(times)) if times else 0.0,
                              "jitter_ms": float(np.std(iv)),
                              "capture_fps": self.source.fps_measured}
                n, t_win = 0, now

    def _fail(self, what):
        self.error = what
        self.log.write("Script stopped - %s:\n%s" % (what, traceback.format_exc()))
        self.running = False
        self._close_worker()
        self.send_cvdata(bytes(48))

    def preview_display(self):
        """Frame for the UI when no script runs."""
        f = self.source.frame
        return f, [], self.source.seq

    def shutdown(self):
        self.stop_script()
        self.source.close()
        if self.output is not None:
            try:
                self.output.close()
            except Exception:
                pass
