"""Crash reports: anything that goes wrong is written to a file the user can
send to an admin, with a plain-English message instead of a silent close.

Reports go to %LOCALAPPDATA%\\NovaCV\\reports\\. Hard crashes (inside a native
library) are caught too, via faulthandler, in reports\\last_native_crash.txt.
"""

import datetime as _dt
import faulthandler
import os
import platform
import sys
import threading
import traceback
from pathlib import Path

_dir = None
_shown = 0
_native = None


def report_dir():
    return _dir


def _version(app_dir):
    try:
        return (Path(app_dir) / "novacv" / "version.txt").read_text().strip()
    except Exception:
        return "?"


def message_box(title, text):
    """Native Windows message box (works without the window library)."""
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, text, title, 0x40 | 0x10000)   # info, foreground
            return
        except Exception:
            pass
    try:
        sys.__stderr__.write("%s: %s\n" % (title, text))
    except Exception:
        pass


def write_report(where, exc_type, exc, tb, app_dir=None):
    if _dir is None:
        return None
    try:
        _dir.mkdir(parents=True, exist_ok=True)
        stamp = _dt.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        p = _dir / ("crash_%s_%03d.txt" % (stamp, _dt.datetime.now().microsecond // 1000))
        n = 1
        while p.exists():
            n += 1
            p = _dir / ("crash_%s_%d.txt" % (stamp, n))
        with open(p, "w", encoding="utf-8") as f:
            f.write("GLCRY METER crash report\n")
            f.write("time: %s\nwhere: %s\nversion: %s\n" % (stamp, where, _version(app_dir or ".")))
            f.write("windows: %s %s\npython: %s\n\n" % (platform.platform(), platform.machine(), sys.version))
            f.write("".join(traceback.format_exception(exc_type, exc, tb)))
        return p
    except Exception:
        return None


def install(data_root, app_dir, title="GLCRY METER"):
    """Catch unhandled errors on every thread and native crashes."""
    global _dir, _native
    _dir = Path(data_root) / "reports"
    try:
        _dir.mkdir(parents=True, exist_ok=True)
        _native = open(_dir / "last_native_crash.txt", "w", encoding="utf-8")
        faulthandler.enable(_native, all_threads=True)
    except Exception:
        pass

    def hook(et, ev, tb, where="main"):
        global _shown
        if issubclass(et, KeyboardInterrupt):
            return
        p = write_report(where, et, ev, tb, app_dir)
        if _shown < 2:               # don't bury the user in boxes
            _shown += 1
            message_box(title, "Something went wrong in %s, but your settings are safe.\n\n"
                               "A report was saved to:\n%s\n\nSend that file to an admin so it can be fixed. "
                               "If GLCRY METER stops working, close it and open it again." % (title, p or _dir))

    sys.excepthook = hook

    def thook(args):
        hook(args.exc_type, args.exc_value, args.exc_traceback,
             "thread %s" % (args.thread.name if args.thread else "?"))

    threading.excepthook = thook
    return hook
