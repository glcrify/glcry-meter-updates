"""Automatic updates.

The owner panel publishes two files at the update address:
  manifest.json      {"app", "version", "file", "sha256", "size", "notes", "sig"}
  NovaCV-<ver>.zip   the new app folder
`sig` is the owner's Ed25519 signature over the manifest (without `sig`), so
only updates made with the owner's key are installed. The zip must match the
signed sha256.
"""

import hashlib
import io
import json
import shutil
import subprocess
import sys
import tempfile
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from . import crypto
from .license import load_trust

APP_DIR = Path(__file__).resolve().parent.parent
SIG_DOMAIN = b"NOVACV-UPD1"
UA = {"User-Agent": "NovaCV-Updater", "Cache-Control": "no-cache"}


def local_version():
    try:
        return (APP_DIR / "novacv" / "version.txt").read_text().strip()
    except Exception:
        return "0"


def vtuple(v):
    out = []
    for part in str(v).split("."):
        num = "".join(ch for ch in part if ch.isdigit())
        out.append(int(num) if num else 0)
    return tuple(out)


def manifest_message(m):
    body = {k: v for k, v in m.items() if k != "sig"}
    return SIG_DOMAIN + json.dumps(body, sort_keys=True, separators=(",", ":")).encode()


def sign_manifest(secret, m):
    m = dict(m)
    m.pop("sig", None)
    m["sig"] = crypto.sign(secret, manifest_message(m)).hex()
    return m


def _get(url, timeout=6.0):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def check():
    """-> (manifest, zip url) if a newer signed version is available, else (None, reason)."""
    trust = load_trust()
    url = (trust.get("update_url") or "").strip()
    pk = trust.get("public_key")
    if not url or not pk:
        return None, "updates not configured"
    murl = url if url.endswith(".json") else url.rstrip("/") + "/manifest.json"
    murl += ("&" if "?" in murl else "?") + "nocache=%d" % (hash(murl) & 0xFFFF)
    try:
        m = json.loads(_get(murl).decode("utf-8"))
    except Exception as exc:
        return None, "couldn't reach the update server (%s)" % exc.__class__.__name__
    try:
        if not crypto.verify(bytes.fromhex(pk), manifest_message(m), bytes.fromhex(m.get("sig", ""))):
            return None, "update manifest signature invalid - ignored"
    except Exception:
        return None, "update manifest unreadable"
    if m.get("app") != "NovaCV" or vtuple(m.get("version")) <= vtuple(local_version()):
        return None, "up to date"
    zurl = urllib.parse.urljoin(murl.split("?")[0], m["file"])
    return m, zurl


def download(m, zurl, progress=None):
    req = urllib.request.Request(zurl, headers=UA)
    buf = io.BytesIO()
    with urllib.request.urlopen(req, timeout=20) as r:
        total = int(m.get("size") or r.headers.get("Content-Length") or 0)
        got = 0
        while True:
            chunk = r.read(65536)
            if not chunk:
                break
            buf.write(chunk)
            got += len(chunk)
            if progress and total:
                progress(min(1.0, got / float(total)))
    data = buf.getvalue()
    if hashlib.sha256(data).hexdigest() != m.get("sha256"):
        raise ValueError("download doesn't match the signed update - not installed")
    return data


def install(data):
    """Unpack over the app folder (files in the update replace old ones;
    anything else - e.g. your own scripts - is kept). Returns True if the
    Python package list changed."""
    old_req = (APP_DIR / "requirements.txt").read_text() if (APP_DIR / "requirements.txt").exists() else ""
    with tempfile.TemporaryDirectory() as td:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for n in z.namelist():
                p = Path(n)
                if p.is_absolute() or ".." in p.parts:
                    raise ValueError("bad path in update")
            z.extractall(td)
        root = Path(td)
        subs = [d for d in root.iterdir() if d.is_dir()]
        if len(subs) == 1 and not (root / "NovaCV.pyw").exists():
            root = subs[0]
        if not (root / "NovaCV.pyw").exists():
            raise ValueError("update package is missing NovaCV.pyw")
        for src in root.rglob("*"):
            if src.is_dir():
                continue
            dst = APP_DIR / src.relative_to(root)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
    new_req = (APP_DIR / "requirements.txt").read_text() if (APP_DIR / "requirements.txt").exists() else ""
    return new_req != old_req


def console_python():
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe":
        c = exe.with_name("python.exe")
        if c.exists():
            return str(c)
    return str(exe)


def install_requirements():
    flags = 0x08000000 if sys.platform == "win32" else 0      # CREATE_NO_WINDOW
    return subprocess.call([console_python(), "-m", "pip", "install", "--disable-pip-version-check",
                            "-q", "-r", str(APP_DIR / "requirements.txt")], creationflags=flags)
