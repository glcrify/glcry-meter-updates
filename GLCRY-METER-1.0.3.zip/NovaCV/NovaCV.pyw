"""GLCRY METER - computer-vision script host with virtual-controller and Titan Two output.

Opens on a lock screen (this PC's ID + a key box). Once activated it sets
itself up: finds OBS Virtual Camera, finds the controller, starts the shot
meter. 'Advanced view' shows the full script/capture/output panels.
"""

import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

# Crash reports first, so even a missing component gives a message + report.
from novacv import crash  # noqa: E402  (standard library only)
crash.install(Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "NovaCV", APP_DIR)

import cv2  # noqa: E402
from PySide6.QtCore import QDir, Qt, QTimer  # noqa: E402
from PySide6.QtGui import QColor, QFont, QIcon, QImage, QPainter  # noqa: E402
try:                                    # where it lives differs between PySide6 versions
    from PySide6.QtWidgets import QFileSystemModel  # noqa: E402
except ImportError:
    from PySide6.QtGui import QFileSystemModel  # noqa: E402
from PySide6.QtWidgets import (  # noqa: E402
    QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog, QDockWidget, QFileDialog,
    QFormLayout, QFrame, QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QMessageBox, QPlainTextEdit, QPushButton, QRadioButton, QSpinBox,
    QTreeView, QVBoxLayout, QWidget)

from novacv import license as lic  # noqa: E402
from novacv import render  # noqa: E402
from novacv.engine import APP_NAME, Engine, Log, data_root, find_obs_camera, list_cameras  # noqa: E402
from novacv.outputs import (PreviewOutput, TitanOutput, VirtualPadOutput,  # noqa: E402
                            pick_input_slot, xinput_slots_status)

SCRIPTS_DIR = APP_DIR / "scripts"
DEFAULT_SCRIPT = SCRIPTS_DIR / "NBA2K21_Meter.py"
CONFIG = data_root() / "app.json"
try:
    VERSION = (APP_DIR / "novacv" / "version.txt").read_text().strip()
except Exception:
    VERSION = "dev"

STYLE = """
QWidget { background: #15171c; color: #e4e7ee; font-family: 'Segoe UI'; font-size: 13px; }
QFrame#card { background: #1e2128; border: 1px solid #2c3039; border-radius: 12px; }
QLabel#title { font-size: 30px; font-weight: 600; }
QLabel#sub { color: #9aa3b2; font-size: 14px; }
QLabel#cardTitle { color: #9aa3b2; font-size: 12px; font-weight: 600; letter-spacing: 1px; }
QLabel#cardText { font-size: 15px; }
QLabel#hint { color: #9aa3b2; font-size: 12px; }
QLabel#err { color: #ff7676; font-size: 13px; }
QLabel#good { color: #52d98a; font-size: 13px; }
QLineEdit { background: #0f1115; border: 1px solid #343944; border-radius: 8px; padding: 10px; font-size: 16px; }
QLineEdit#hwid { font-family: Consolas; font-size: 24px; letter-spacing: 2px; color: #ffffff; }
QLineEdit#key { font-family: Consolas; font-size: 13px; }
QPushButton { background: #2a2e37; border: 1px solid #3a3f4a; border-radius: 8px; padding: 8px 16px; font-size: 13px; }
QPushButton:hover { background: #343944; }
QPushButton#big { font-size: 16px; padding: 14px 22px; }
QPushButton#on { background: #1f9d55; border-color: #1f9d55; color: white; font-size: 16px; padding: 14px 22px; font-weight: 600; }
QPushButton#off { background: #3a3f4a; color: #cfd4dd; font-size: 16px; padding: 14px 22px; font-weight: 600; }
QPushButton#choice { font-size: 16px; padding: 22px; text-align: left; border-radius: 12px; }
QPushButton#choice:hover { border-color: #2f6fed; }
QComboBox, QSpinBox, QPlainTextEdit, QTreeView { background: #0f1115; border: 1px solid #30343c; border-radius: 6px; padding: 3px; }
QGroupBox { border: 1px solid #2c3039; border-radius: 8px; margin-top: 12px; padding-top: 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; color: #9aa3b2; }
QDockWidget::title { background: #1e2128; padding: 5px; }
"""


def load_config():
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config(cfg):
    try:
        CONFIG.parent.mkdir(parents=True, exist_ok=True)
        CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception:
        pass


def dot(color):
    return "<span style='color:%s;font-size:18px'>&#9679;</span>" % color


GREEN, AMBER, RED, GREY = "#52d98a", "#f5b942", "#ff7676", "#6b7280"


def repolish(w):
    """Re-apply the stylesheet after changing a widget's objectName."""
    st = w.style()
    st.unpolish(w)
    st.polish(w)
    w.update()


# ----------------------------------------------------------------------------
# Lock screen
# ----------------------------------------------------------------------------
class LockPage(QWidget):
    """This PC's ID and a key box. Nothing else to click."""

    def __init__(self, on_unlock, message=None):
        super().__init__()
        self.on_unlock = on_unlock
        outer = QVBoxLayout(self)
        outer.addStretch(1)
        card = QFrame()
        card.setObjectName("card")
        card.setFixedWidth(620)
        v = QVBoxLayout(card)
        v.setContentsMargins(40, 36, 40, 36)
        v.setSpacing(10)
        t = QLabel(APP_NAME)
        t.setObjectName("title")
        t.setAlignment(Qt.AlignCenter)
        v.addWidget(t)
        s = QLabel("Activate this PC")
        s.setObjectName("sub")
        s.setAlignment(Qt.AlignCenter)
        v.addWidget(s)
        v.addSpacing(18)
        lab = QLabel("YOUR PC ID")
        lab.setObjectName("cardTitle")
        v.addWidget(lab)
        self.hwid = QLineEdit(lic.this_hwid())
        self.hwid.setObjectName("hwid")
        self.hwid.setReadOnly(True)
        self.hwid.setAlignment(Qt.AlignCenter)
        self.hwid.setContextMenuPolicy(Qt.NoContextMenu)
        v.addWidget(self.hwid)
        h = QLabel("Paste the key an admin sent you below. It locks to this PC the first time it's used.")
        h.setObjectName("hint")
        h.setWordWrap(True)
        v.addWidget(h)
        v.addSpacing(14)
        lab = QLabel("YOUR KEY")
        lab.setObjectName("cardTitle")
        v.addWidget(lab)
        self.key = QLineEdit()
        self.key.setObjectName("key")
        self.key.setPlaceholderText("Paste your key here (it starts with GLCRY-)")
        self.key.textChanged.connect(self.check)
        v.addWidget(self.key)
        self.msg = QLabel(" ")
        self.msg.setObjectName("hint")
        self.msg.setWordWrap(True)
        v.addWidget(self.msg)
        if message:
            self._say("err", message)
        ver = QLabel("Version %s" % VERSION)
        ver.setObjectName("hint")
        ver.setAlignment(Qt.AlignCenter)
        v.addSpacing(10)
        v.addWidget(ver)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(card)
        row.addStretch(1)
        outer.addLayout(row)
        outer.addStretch(1)
        self.key.setFocus()

    def showEvent(self, e):
        super().showEvent(e)
        self.hwid.selectAll()       # ready to copy with Ctrl+C
        self.key.setFocus()

    def check(self, text):
        t = text.strip()
        if len("".join(c for c in t if c.isalnum())) < 40:
            self._say("hint", " ")
            return
        ok, info = lic.check_key(t)
        if not ok:
            self._say("err", info)
            return
        if info.get("activate") and not lic.is_activated_here(data_root(), info["key_id"]):
            # first use: claim this key for this PC on the activation server
            self.key.setReadOnly(True)
            self._say("hint", "Activating this PC...")
            res = []
            threading.Thread(target=lambda: res.append(lic.activate_online(t)), daemon=True).start()

            def wait():
                if not res:
                    QTimer.singleShot(150, wait)
                    return
                self.key.setReadOnly(False)
                if res[0] == "ok":
                    try:
                        lic.mark_activated(data_root(), info["key_id"])
                    except Exception:
                        pass
                    self._accept(t, info)
                else:
                    self._say("err", lic.ACTIVATION_MESSAGES.get(res[0], res[0]))
            wait()
            return
        self._accept(t, info)

    def _accept(self, t, info):
        try:
            f = lic.key_file(data_root())
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text(t, encoding="utf-8")
        except Exception:
            pass
        self._say("good", "Key accepted - welcome, %s!" % (info["name"] or "player"))
        self.key.setReadOnly(True)
        QTimer.singleShot(900, lambda: self.on_unlock(info))

    def _say(self, kind, text):
        self.msg.setObjectName(kind)
        self.msg.setText(text)
        repolish(self.msg)


# ----------------------------------------------------------------------------
# Video
# ----------------------------------------------------------------------------
class VideoWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.img = None
        self.info = ""
        self.empty_text = "Waiting for video..."
        self.setMinimumSize(480, 270)
        self.setAttribute(Qt.WA_OpaquePaintEvent)

    def set_image(self, img):
        self.img = img
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(8, 9, 12))
        if self.img is not None:
            x = (self.width() - self.img.width()) // 2
            y = (self.height() - self.img.height()) // 2
            p.drawImage(x, y, self.img)
        else:
            p.setPen(QColor(130, 136, 148))
            p.setFont(QFont("Segoe UI", 13))
            p.drawText(self.rect(), Qt.AlignCenter, self.empty_text)
        if self.info:
            p.setPen(QColor(200, 205, 215))
            p.setFont(QFont("Consolas", 9))
            p.drawText(self.rect().adjusted(0, 6, -10, 0), Qt.AlignTop | Qt.AlignRight, self.info)
        p.end()


# ----------------------------------------------------------------------------
# Dialogs
# ----------------------------------------------------------------------------
class SetupDialog(QDialog):
    """'How do you play?' - two big choices."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("How do you play?")
        self.choice = None
        v = QVBoxLayout(self)
        v.setContentsMargins(28, 24, 28, 24)
        v.setSpacing(14)
        t = QLabel("How is your controller connected?")
        t.setStyleSheet("font-size: 20px; font-weight: 600;")
        v.addWidget(t)
        a = QPushButton("My controller is plugged into this PC\n"
                        "GLCRY METER passes it to the game as a virtual controller.")
        a.setObjectName("choice")
        a.clicked.connect(lambda: self.pick(0))
        v.addWidget(a)
        b = QPushButton("I use a Titan Two\n"
                        "Needs Gtuner IV open with the GLCRY METER bridge running.")
        b.setObjectName("choice")
        b.clicked.connect(lambda: self.pick(1))
        v.addWidget(b)

    def pick(self, c):
        self.choice = c
        self.accept()


class ShotSettingsDialog(QDialog):
    """The shot meter's main settings, edited in its settings file (the
    script picks changes up within a second)."""

    def __init__(self, parent, script_stem):
        super().__init__(parent)
        self.setWindowTitle("Shot settings")
        self.setMinimumWidth(460)
        d = data_root() / "ScriptData" / script_stem
        files = sorted(d.glob("settings_v*.json"), key=lambda p: p.stat().st_mtime) if d.exists() else []
        self.path = files[-1] if files else None
        self.data = {}
        if self.path:
            try:
                self.data = json.loads(self.path.read_text(encoding="utf-8"))
            except Exception:
                self.data = {}
        v = QVBoxLayout(self)
        v.setContentsMargins(24, 20, 24, 20)
        if not self.path:
            v.addWidget(QLabel("Start the shot meter once, then its settings appear here."))
            return
        t = QLabel("Release timing")
        t.setStyleSheet("font-size: 17px; font-weight: 600;")
        v.addWidget(t)
        h = QLabel("Shots EARLY? press -   Shots LATE? press +")
        h.setObjectName("hint")
        v.addWidget(h)
        row = QHBoxLayout()
        for txt, d_ in (("-5", -5), ("-1", -1)):
            b = QPushButton(txt)
            b.setObjectName("big")
            b.clicked.connect(lambda _=False, d_=d_: self.bump(d_))
            row.addWidget(b)
        self.lead = QLabel()
        self.lead.setAlignment(Qt.AlignCenter)
        self.lead.setStyleSheet("font-size: 30px; font-weight: 600; min-width: 120px;")
        row.addWidget(self.lead)
        for txt, d_ in (("+1", 1), ("+5", 5)):
            b = QPushButton(txt)
            b.setObjectName("big")
            b.clicked.connect(lambda _=False, d_=d_: self.bump(d_))
            row.addWidget(b)
        v.addLayout(row)
        self.verdict = QCheckBox("Change my timing automatically after each shot")
        self.verdict.setChecked(bool(self.data.get("use_2k_verdict", False) or self.data.get("auto_calibrate", False)))
        self.verdict.toggled.connect(self.set_auto)
        v.addWidget(self.verdict)
        self.enabled = QCheckBox("Shot meter on when it starts")
        self.enabled.setChecked(bool(self.data.get("enabled_on_start", True)))
        self.enabled.toggled.connect(lambda c: self.set("enabled_on_start", bool(c)))
        v.addWidget(self.enabled)
        self.box = QCheckBox("Show the search box on the video")
        self.box.setChecked(bool(self.data.get("show_search_box", True)))
        self.box.toggled.connect(lambda c: self.set("show_search_box", bool(c)))
        v.addWidget(self.box)
        stick = QCheckBox("I shoot with the shot stick (right stick) instead of a button")
        stick.setChecked(self.data.get("shoot_mode") == "stick")
        stick.toggled.connect(lambda c: self.set("shoot_mode", "stick" if c else "button"))
        v.addWidget(stick)
        self.last = QLabel(self.last_verdict())
        self.last.setObjectName("hint")
        v.addWidget(self.last)
        self.show_lead()

    def last_verdict(self):
        try:
            lines = (self.path.parent / "shots_log.txt").read_text(encoding="utf-8").splitlines()
            for ln in reversed(lines[-50:]):
                rec = json.loads(ln)
                if "verdict" in rec:
                    return "Last shot: 2K said %s" % rec["verdict"]
        except Exception:
            pass
        return ""

    def set_auto(self, on):
        # one switch for both ways the script can adjust the timing
        self.set("use_2k_verdict", bool(on))
        self.set("auto_calibrate", bool(on))

    def show_lead(self):
        self.lead.setText("%d ms" % int(self.data.get("lead_ms", 40)))

    def bump(self, d):
        self.set("lead_ms", max(0, min(400, int(self.data.get("lead_ms", 40)) + d)))
        self.show_lead()

    def set(self, k, val):
        try:
            cur = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            cur = dict(self.data)
        cur[k] = val
        self.data = cur
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(cur, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)


# ----------------------------------------------------------------------------
# Main window
# ----------------------------------------------------------------------------
class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1360, 860)
        self.cfg = load_config()
        self.log = Log()
        self.engine = None
        self.built = False
        self.relock_reason = None
        lic.set_data_root(data_root())
        threading.Thread(target=self._watch_revocations, daemon=True).start()
        ok, info = lic.saved_key_ok(data_root())
        if ok:
            self.unlock(info)
        else:
            msg = None
            if lic.key_file(data_root()).exists():
                k = lic.key_file(data_root()).read_text(encoding="utf-8").strip()
                r = lic.check_key(k)[1]
                msg = r if isinstance(r, str) else None
            self.setCentralWidget(LockPage(self.unlock, msg))

    # ------------------------------------------------------------- licence
    def _watch_revocations(self):
        """Fetch the owner's cancelled-keys list now and every 30 minutes; if
        this PC's key is on it, go back to the lock screen."""
        while True:
            try:
                lic.refresh_revocations()
                if lic.key_file(data_root()).exists():
                    k = lic.key_file(data_root()).read_text(encoding="utf-8").strip()
                    ok, info = lic.check_key(k)
                    if ok and info.get("activate"):
                        r = lic.activate_online(k)      # offline: keep working
                        if r in ("taken", "cancelled"):
                            self.relock_reason = lic.ACTIVATION_MESSAGES[r]
                            lic.clear_activation(data_root())
                    ok, info = lic.saved_key_ok(data_root())
                    if not ok:
                        k = lic.key_file(data_root()).read_text(encoding="utf-8").strip()
                        reason = lic.check_key(k)[1]
                        if isinstance(reason, str) and "cancelled" in reason:
                            self.relock_reason = reason
            except Exception:
                pass
            time.sleep(1800)

    def relock(self, reason):
        self.relock_reason = None
        try:
            lic.key_file(data_root()).unlink()
        except Exception:
            pass
        if self.engine is not None:
            self.engine.shutdown()
            self.engine = None
        for t in ("t_video", "t_ui"):
            if hasattr(self, t):
                getattr(self, t).stop()
        for d in getattr(self, "docks", []):
            self.removeDockWidget(d)
            d.deleteLater()
        self.docks = []
        self.built = False
        self.setCentralWidget(LockPage(self.unlock, reason))

    # ------------------------------------------------------------- unlock
    def unlock(self, info):
        self.user = info
        self.engine = Engine(self.log, None)
        self.log_seq = 0
        self.disp_seq = -1
        self.disp_n, self.disp_t, self.disp_fps = 0, time.perf_counter(), 0.0
        self.next_cam_try = 0.0
        self.no_frame_since = None
        self.meter_on = bool(self.cfg.get("meter_on", True))
        self.selected = Path(self.cfg["script"]) if self.cfg.get("script") and Path(self.cfg["script"]).exists() \
            else (DEFAULT_SCRIPT if DEFAULT_SCRIPT.exists() else None)
        self.build_main()
        self.log.write("%s %s - licensed to %s (%s)" % (APP_NAME, VERSION, info.get("name"), info.get("role")))
        if "mode" not in self.cfg:
            QTimer.singleShot(300, self.controller_setup)
        else:
            self.apply_output()

    def build_main(self):
        self.built = True
        centre = QWidget()
        cl = QVBoxLayout(centre)
        cl.setContentsMargins(14, 12, 14, 12)
        cl.setSpacing(12)

        # status cards
        cards = QHBoxLayout()
        cards.setSpacing(12)
        self.card_video = self.make_card("VIDEO")
        self.card_ctrl = self.make_card("CONTROLLER")
        self.card_meter = self.make_card("SHOT METER")
        for c in (self.card_video, self.card_ctrl, self.card_meter):
            cards.addWidget(c[0], 1)
        cl.addLayout(cards)

        # buttons
        row = QHBoxLayout()
        self.meter_btn = QPushButton()
        self.meter_btn.clicked.connect(self.toggle_meter)
        row.addWidget(self.meter_btn)
        b = QPushButton("Shot settings")
        b.setObjectName("big")
        b.clicked.connect(self.shot_settings)
        row.addWidget(b)
        b = QPushButton("Controller setup")
        b.setObjectName("big")
        b.clicked.connect(self.controller_setup)
        row.addWidget(b)
        row.addStretch(1)
        self.adv_btn = QPushButton("Advanced view")
        self.adv_btn.setCheckable(True)
        self.adv_btn.toggled.connect(self.set_advanced)
        row.addWidget(self.adv_btn)
        cl.addLayout(row)

        self.video = VideoWidget()
        cl.addWidget(self.video, 1)
        foot = QLabel("%s %s  -  licensed to %s" % (APP_NAME, VERSION, self.user.get("name") or "-"))
        foot.setObjectName("hint")
        cl.addWidget(foot)
        self.setCentralWidget(centre)
        self.build_advanced()
        self.paint_meter_btn()

        self.t_video = QTimer(self)
        self.t_video.timeout.connect(self.update_video)
        self.t_video.start(8)
        self.t_ui = QTimer(self)
        self.t_ui.timeout.connect(self.update_ui)
        self.t_ui.start(250)

    def make_card(self, title):
        f = QFrame()
        f.setObjectName("card")
        v = QVBoxLayout(f)
        v.setContentsMargins(16, 12, 16, 14)
        t = QLabel(title)
        t.setObjectName("cardTitle")
        v.addWidget(t)
        txt = QLabel("...")
        txt.setObjectName("cardText")
        txt.setWordWrap(True)
        txt.setTextFormat(Qt.RichText)
        v.addWidget(txt)
        return f, txt

    # ------------------------------------------------------------- advanced
    def build_advanced(self):
        self.docks = []
        # capture
        cap = QWidget()
        cg = QFormLayout(cap)
        self.cam = QComboBox()
        cg.addRow("Capture device", self.cam)
        self.backend = QComboBox()
        self.backend.addItems(["DirectShow", "Media Foundation"])
        self.backend.setCurrentIndex(int(self.cfg.get("backend", 0)))
        cg.addRow("Capture method", self.backend)
        self.res = QComboBox()
        self.res.addItems(["1920x1080", "1280x720", "2560x1440", "3840x2160"])
        i = self.res.findText(self.cfg.get("res", "1920x1080"))
        self.res.setCurrentIndex(max(0, i))
        cg.addRow("Resolution", self.res)
        self.fps = QSpinBox()
        self.fps.setRange(30, 360)
        self.fps.setValue(int(self.cfg.get("fps", 240)))
        cg.addRow("Frame rate", self.fps)
        self.auto_cam = QCheckBox("Find OBS Virtual Camera automatically")
        self.auto_cam.setChecked(bool(self.cfg.get("auto_cam", True)))
        cg.addRow(self.auto_cam)
        r = QHBoxLayout()
        b = QPushButton("Use this device")
        b.clicked.connect(self.manual_capture)
        r.addWidget(b)
        b = QPushButton("Refresh")
        b.clicked.connect(self.refresh_cameras)
        r.addWidget(b)
        b = QPushButton("Play a recording...")
        b.clicked.connect(self.open_video)
        r.addWidget(b)
        cg.addRow(r)
        self.refresh_cameras()

        # scripts
        left = QWidget()
        ll = QVBoxLayout(left)
        SCRIPTS_DIR.mkdir(exist_ok=True)
        self.fs = QFileSystemModel()
        self.fs.setRootPath(str(SCRIPTS_DIR))
        self.fs.setNameFilters(["*.py"])
        self.fs.setNameFilterDisables(False)
        self.fs.setFilter(QDir.AllDirs | QDir.Files | QDir.NoDotAndDotDot)
        self.tree = QTreeView()
        self.tree.setModel(self.fs)
        self.tree.setRootIndex(self.fs.index(str(SCRIPTS_DIR)))
        for c in (1, 2, 3):
            self.tree.hideColumn(c)
        self.tree.setHeaderHidden(True)
        self.tree.doubleClicked.connect(self.tree_pick)
        ll.addWidget(self.tree, 1)
        self.script_lbl = QLabel(self.selected.name if self.selected else "No script selected")
        ll.addWidget(self.script_lbl)
        self.stats_lbl = QLabel("")
        self.stats_lbl.setFont(QFont("Consolas", 9))
        ll.addWidget(self.stats_lbl)
        r = QHBoxLayout()
        b = QPushButton("Run selected")
        b.clicked.connect(self.run_selected)
        r.addWidget(b)
        b = QPushButton("Scripts folder")
        b.clicked.connect(lambda: self.open_path(SCRIPTS_DIR))
        r.addWidget(b)
        b = QPushButton("Data folder")
        b.clicked.connect(lambda: self.open_path(data_root() / "ScriptData"))
        r.addWidget(b)
        ll.addLayout(r)

        # output
        right = QWidget()
        rl = QVBoxLayout(right)
        g = QGroupBox("Output")
        gl = QVBoxLayout(g)
        self.mode_group = QButtonGroup(self)
        self.rb_vpad = QRadioButton("Virtual controller (ViGEm)")
        self.rb_titan = QRadioButton("Titan Two (Gtuner IV bridge)")
        self.rb_prev = QRadioButton("Preview only (send nothing)")
        for i, rb in enumerate((self.rb_vpad, self.rb_titan, self.rb_prev)):
            self.mode_group.addButton(rb, i)
            gl.addWidget(rb)
        {0: self.rb_vpad, 1: self.rb_titan}.get(int(self.cfg.get("mode", 0)), self.rb_prev).setChecked(True)
        form = QFormLayout()
        self.slot = QComboBox()
        self.slot.addItem("Automatic", -1)
        for s in range(4):
            self.slot.addItem("XInput slot %d" % (s + 1), s)
        want = int(self.cfg.get("slot", -1))
        self.slot.setCurrentIndex(want + 1 if -1 <= want <= 3 else 0)
        form.addRow("Controller input", self.slot)
        self.port = QSpinBox()
        self.port.setRange(1024, 65000)
        self.port.setValue(int(self.cfg.get("titan_port", 47654)))
        form.addRow("Titan bridge port", self.port)
        gl.addLayout(form)
        self.latch = QCheckBox("Titan: hold a release until the button is let go")
        self.latch.setChecked(bool(self.cfg.get("titan_latch", True)))
        gl.addWidget(self.latch)
        b = QPushButton("Apply output")
        b.clicked.connect(self.apply_output_adv)
        gl.addWidget(b)
        rl.addWidget(g)
        g = QGroupBox("Device monitor  (input / output)")
        grid = QGridLayout(g)
        self.mon = {}
        rows = [(16, "X / Square"), (15, "A / Cross"), (14, "B / Circle"), (13, "Y / Triangle"),
                (6, "LB / L1"), (3, "RB / R1"), (7, "LT / L2"), (4, "RT / R2"),
                (23, "Left X"), (24, "Left Y"), (21, "Right X"), (22, "Right Y")]
        for r_, (idx, name) in enumerate(rows):
            grid.addWidget(QLabel(name), r_, 0)
            a, o = QLabel("0"), QLabel("0")
            a.setFont(QFont("Consolas", 9))
            o.setFont(QFont("Consolas", 9))
            grid.addWidget(a, r_, 1)
            grid.addWidget(o, r_, 2)
            self.mon[idx] = (a, o)
        rl.addWidget(g)
        rl.addStretch(1)

        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setFont(QFont("Consolas", 9))
        self.console.setMaximumBlockCount(3000)

        for title, w, area in (("Capture", cap, Qt.LeftDockWidgetArea), ("Scripts", left, Qt.LeftDockWidgetArea),
                               ("Output", right, Qt.RightDockWidgetArea),
                               ("Console", self.console, Qt.BottomDockWidgetArea)):
            d = QDockWidget(title, self)
            d.setWidget(w)
            d.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable)
            self.addDockWidget(area, d)
            d.hide()
            self.docks.append(d)

    def set_advanced(self, on):
        for d in self.docks:
            d.setVisible(on)

    # ------------------------------------------------------------- helpers
    def open_path(self, p):
        p = Path(p)
        p.mkdir(parents=True, exist_ok=True)
        if sys.platform == "win32":
            os.startfile(str(p))
        else:
            subprocess.Popen(["xdg-open", str(p)])

    def save(self):
        if not self.built:
            return
        self.cfg.update({
            "backend": self.backend.currentIndex(), "res": self.res.currentText(),
            "fps": self.fps.value(), "auto_cam": self.auto_cam.isChecked(),
            "slot": self.slot.currentData(), "titan_port": self.port.value(),
            "titan_latch": self.latch.isChecked(), "meter_on": self.meter_on,
            "script": str(self.selected) if self.selected else "",
        })
        save_config(self.cfg)

    # ------------------------------------------------------------- capture
    def refresh_cameras(self):
        self.cam.clear()
        for idx, name in list_cameras():
            self.cam.addItem(name, idx)
        i = int(self.cfg.get("camera", 0))
        self.cam.setCurrentIndex(min(max(0, i), max(0, self.cam.count() - 1)))

    def _open_capture(self, index):
        w, h = (int(v) for v in self.res.currentText().split("x"))
        return self.engine.source.open(index, w, h, self.fps.value(),
                                       "dshow" if self.backend.currentIndex() == 0 else "msmf")

    def manual_capture(self):
        self.auto_cam.setChecked(False)
        self.cfg["camera"] = self.cam.currentIndex()
        self._open_capture(self.cam.currentData())
        self.save()

    def open_video(self):
        p, _ = QFileDialog.getOpenFileName(self, "Play a recording", str(Path.home()),
                                           "Video (*.mp4 *.mkv *.avi *.mov)")
        if p:
            self.auto_cam.setChecked(False)
            self.engine.source.open(p)

    def auto_capture(self):
        """Keep video running: find OBS Virtual Camera, reopen if frames stop."""
        src = self.engine.source
        now = time.monotonic()
        if src.running:
            age = (time.perf_counter_ns() - src.ts_ns) / 1e9 if src.ts_ns else 0.0
            if age > 3.0 and not src.is_file:
                self.log.write("Video stopped arriving - reconnecting")
                src.close()
            return
        if not self.auto_cam.isChecked() or now < self.next_cam_try:
            return
        self.next_cam_try = now + 3.0
        idx = find_obs_camera()
        if idx is not None:
            self._open_capture(idx)

    # ------------------------------------------------------------- script
    def tree_pick(self, index):
        p = Path(self.fs.filePath(index))
        if p.is_file() and p.suffix == ".py":
            self.selected = p
            self.script_lbl.setText(p.name)
            self.save()

    def run_selected(self):
        idx = self.tree.currentIndex()
        if idx.isValid():
            self.tree_pick(idx)
        if self.selected:
            self.meter_on = True
            self.engine.load_script(self.selected)
            self.paint_meter_btn()
            self.save()

    def toggle_meter(self):
        self.meter_on = not self.meter_on
        self.engine.error = None
        if not self.meter_on:
            self.engine.stop_script()
        self.paint_meter_btn()
        self.save()

    def paint_meter_btn(self):
        self.meter_btn.setText("Shot meter: ON" if self.meter_on else "Shot meter: OFF")
        self.meter_btn.setObjectName("on" if self.meter_on else "off")
        repolish(self.meter_btn)

    def auto_script(self):
        if self.meter_on and not self.engine.running and self.selected and self.engine.source.running \
                and self.engine.error is None:
            self.engine.load_script(self.selected)

    def shot_settings(self):
        stem = self.selected.stem if self.selected else "NBA2K21_Meter"
        ShotSettingsDialog(self, stem).exec()

    # ------------------------------------------------------------- output
    def controller_setup(self):
        d = SetupDialog(self)
        if d.exec() and d.choice is not None:
            self.cfg["mode"] = d.choice
            (self.rb_vpad if d.choice == 0 else self.rb_titan).setChecked(True)
            self.apply_output()
            if d.choice == 1:
                QMessageBox.information(
                    self, "Titan Two setup",
                    "1. In Gtuner IV, put GLCRY_METER_Bridge.gpc on your Titan Two and run it.\n"
                    "2. In Gtuner IV's Computer Vision tab, open GLCRY_METER_GtunerBridge.py and press Start.\n\n"
                    "Both files are in GLCRY METER's 'titan' folder (Advanced view > Scripts folder, one level up).\n"
                    "The Controller card turns green when it's linked.")

    def apply_output_adv(self):
        self.cfg["mode"] = self.mode_group.checkedId()
        self.apply_output()

    def apply_output(self):
        mode = int(self.cfg.get("mode", 0))
        want = self.slot.currentData()
        slot = want if want is not None and want >= 0 else (pick_input_slot(int(self.cfg.get("last_slot", 0))) or 0)
        old = self.engine.output
        if old is not None:
            # close the old output first: its virtual pad must be gone before
            # the new one hides controllers, or it would get hidden too
            try:
                old.close()
            except Exception:
                pass
        if mode == 0:
            out = VirtualPadOutput(self.log, slot)
        elif mode == 1:
            out = TitanOutput(self.log, slot, self.port.value(), self.latch.isChecked())
        else:
            out = PreviewOutput(self.log, slot)
        self.engine.set_output(out)
        self.log.write("Output: %s, controller on slot %d" % (out.name, slot + 1))
        self.save()

    def auto_slot(self):
        out = self.engine.output
        if out is None or self.slot.currentData() not in (None, -1):
            return
        if not out.reader.connected:
            s = pick_input_slot(out.reader.slot, exclude=out.virtual_slot)
            if s is not None and s != out.reader.slot:
                out.reader.slot = s
                self.cfg["last_slot"] = s
                self.log.write("Controller found on slot %d" % (s + 1))

    # ------------------------------------------------------------- timers
    def update_video(self):
        if self.engine.running:
            with self.engine.lock:
                frame, cmds, seq = self.engine.display
        else:
            frame, cmds, seq = self.engine.preview_display()
        if frame is None:
            if self.video.img is not None and not self.engine.source.running:
                self.video.set_image(None)
            return
        if seq == self.disp_seq:
            return
        self.disp_seq = seq
        img = render.compose(frame, cmds, self.video.width(), self.video.height())
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        self.video.set_image(QImage(rgb.data, w, h, 3 * w, QImage.Format_RGB888).copy())
        self.disp_n += 1
        now = time.perf_counter()
        if now - self.disp_t >= 1.0:
            self.disp_fps = self.disp_n / (now - self.disp_t)
            self.disp_n, self.disp_t = 0, now

    def update_ui(self):
        if self.relock_reason:
            self.relock(self.relock_reason)
            return
        self.auto_capture()
        self.auto_slot()
        self.auto_script()
        src, st, out = self.engine.source, self.engine.stats, self.engine.output

        # video card
        if src.running:
            self.card_video[1].setText("%s Connected  -  %dx%d at %.0f fps" % (
                dot(GREEN if src.fps_measured >= 100 or src.is_file else AMBER),
                src.size[0], src.size[1], src.fps_measured))
            self.video.empty_text = "Waiting for video..."
        elif self.auto_cam.isChecked():
            self.card_video[1].setText("%s Waiting for OBS<br><small>Open OBS and press "
                                       "<b>Start Virtual Camera</b>.</small>" % dot(AMBER))
            self.video.empty_text = "Open OBS and press Start Virtual Camera - the video will appear here."
        else:
            self.card_video[1].setText("%s No video<br><small>Pick a device in Advanced view.</small>" % dot(RED))

        # controller card
        if out is not None:
            pad = out.reader.connected
            if isinstance(out, VirtualPadOutput):
                if out.pad is None:
                    txt = "%s Virtual controller driver missing<br><small>Run the GLCRY METER installer again.</small>" % dot(RED)
                elif not pad:
                    txt = "%s Plug in your controller<br><small>USB or Bluetooth.</small>" % dot(AMBER)
                elif not out.hidden:
                    txt = ("%s The game can still see your real controller<br><small>%s Press <b>Controller setup</b> "
                           "and pick the virtual controller again to retry.</small>" % (dot(RED), out.hide_error))
                else:
                    txt = "%s Ready  -  your controller is passed to the game" % dot(GREEN)
            elif isinstance(out, TitanOutput):
                linked = "connected" in out.status
                if not linked:
                    txt = "%s Titan Two: open Gtuner IV<br><small>Run GLCRY_METER_Bridge.gpc and start "\
                          "GLCRY_METER_GtunerBridge.py in Computer Vision.</small>" % dot(AMBER)
                elif not pad:
                    txt = "%s Titan Two linked - waiting for its controller output" % dot(AMBER)
                else:
                    txt = "%s Titan Two linked  -  %.0f fps" % (dot(GREEN), out.bridge_fps)
            else:
                txt = "%s Preview only - nothing is sent to the game" % dot(GREY)
            self.card_ctrl[1].setText(txt)

        # meter card
        if not self.meter_on:
            self.card_meter[1].setText("%s Off" % dot(GREY))
        elif self.engine.error:
            self.card_meter[1].setText("%s Stopped - %s<br><small>See Advanced view > Console.</small>" % (
                dot(RED), self.engine.error))
        elif self.engine.running:
            self.card_meter[1].setText("%s Running  -  %.0f fps, %.1f ms" % (
                dot(GREEN), st["script_fps"], st["process_ms"]))
        else:
            self.card_meter[1].setText("%s Starts when video arrives" % dot(AMBER))

        self.video.info = "Capture %.0f fps   Processing %.0f fps   Display %.0f fps" % (
            src.fps_measured, st["script_fps"] if self.engine.running else 0, self.disp_fps) if src.running else ""

        if self.adv_btn.isChecked():
            self.stats_lbl.setText("Script FPS: %.0f   Process: %.2f ms   Jitter: %.2f ms" % (
                st["script_fps"], st["process_ms"], st["jitter_ms"]) if self.engine.running else "Not running")
            if out is not None:
                ov, iv = out.output_values(), out.reader.values
                for idx, (a, o) in self.mon.items():
                    a.setText("%4.0f" % iv[idx])
                    o.setText("%4.0f" % ov[idx])
        seq, lines = self.log.snapshot()
        if seq != self.log_seq:
            new = seq - self.log_seq
            self.log_seq = seq
            for ln in lines[-min(new, len(lines)):]:
                self.console.appendPlainText(ln)

    def closeEvent(self, e):
        if self.engine is not None and self.built:
            self.save()
            self.engine.shutdown()
        e.accept()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyleSheet(STYLE)
    app.setWindowIcon(QIcon(str(APP_DIR / "novacv" / "icon.ico")))
    w = Main()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
