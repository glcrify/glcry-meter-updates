"""NBA 2K21 Shot Meter - Helios CV Python script (Titan Two output).  v4.4

Built and tested against footage of the real 2K21 meter: a small curved bar
with a light-grey outline that rises above the shooter's head, a khaki target
zone near its right end, and a gold line sweeping left -> right.

What's new in v4.4
------------------
* Aims at the middle of the khaki zone. On your footage 2K said EXCELLENT
  when the line stopped ~0.45-0.6 of the way across the zone (SLIGHTLY EARLY
  ~0.35, SLIGHTLY LATE ~0.7). The old 'perfect slit' target could be read off
  the zone's stripes (or the line's own
  gap) instead of the centre on some shots. Your lead carries over
  (settings_v6.json).
* Helios's TIME/DISTANCE/SPEED/ETA readout is off by default: its own
  estimate jumps around (that's the "bugging out"); timing never used it.

What's new in v4.3
------------------
* Ante-Up / busy courts: the fast search also looks for the bar's dark inside
  (not just its outline, which merges with court lines and light paint) and
  ranks candidates by an outline-dark-outline test instead of size, so the
  meter isn't lost among crowd, banners and court lines.
* Something bar-shaped that never gives a reading (backboard edge, banner)
  is dropped after 120 ms and the search moves on.
* Search box: only the band of the screen where the meter appears (10-80% of
  the height) is searched. It's drawn on the overlay: grey when idle, lit
  while you hold shoot (yellow searching, blue locked, green timing).
* Online modes: repeated VERY EARLY/LATE verdicts double the correction each
  time (Ante-Up needed 100+ ms more lead than offline), lead limit 400 ms.

What's new in v4.2
------------------
* Steadier release timing: the line's speed is now fitted over ~320 ms of its
  path instead of the last ~10 frames (only ~50 ms at 240 fps). In testing the
  release spread roughly halved and an early bias of ~5-10 ms went away.
* Helios's meter ETA is no longer averaged into the release (it swung by
  20-30 ms between frames in your recordings); it's still shown on screen.
* 2K-verdict tuning is back on, with smaller steps once verdicts start
  flipping between EARLY and LATE so the lead settles instead of hunting.
* First run moves your lead 10 ms lower (settings_v5.json): in the v4.1
  recording the line stopped ~20 ms early on average.

What's new in v4.1: 240 fps performance (no frame drops while holding the
button) and the TIMING verdict read at 16:9 as well as ultrawide.

What's new in v4
----------------
* Finds the meter anywhere on the court: over the purple wall, in the dark
  corners and far baseline, not just over the wood. The bar's inside is
  semi-transparent, so besides "charcoal" it is also found as "whatever sits
  between a light top edge and a light bottom edge one bar-thickness apart".
* Locks onto the right thing: a new meter must arch upward with the meter's
  curvature, have a dark inside, a sensible length and the khaki zone in its
  right part. The player's floor badge, court lines and the HUD boxes are
  rejected (the top-right TIMING box used to be mistaken for a meter).
* If it ever locks onto the wrong thing it re-searches the whole screen and
  switches to the real meter as soon as it appears.
* Timing uses Helios's built-in meter the way 2K Vision does: each frame it is
  given the line and the target and returns a fitted ETA (shown as the
  TIME / DISTANCE / SPEED PX/MS / ETA MS readout). Both fits must agree.
* Calibrates from 2K's own TIMING verdict (top-right box): after each script
  release it reads EXCELLENT / SLIGHTLY EARLY|LATE / VERY EARLY|LATE and
  corrects the lead. If no verdict can be read, it falls back to measuring
  where the line stopped.

How it works
------------
1. While you hold shoot (Square / X, or the right stick in shot-stick mode)
   it finds the meter, then follows it at full resolution.
2. Each frame it measures the pixel distance from the line to the target,
   anchored on the zone's far edge (backups: the zone's other edge, the bar's
   left end), timed by Helios's capture timestamps.
3. Every line candidate is kept; only a set forming one steady approach is
   believed (4 agreeing readings minimum), so glints can't trigger a release.
4. It releases ``lead_ms`` before the line is predicted to reach the target.
5. Nothing else is touched. No meter found -> your own release goes through.

Setup
-----
* Capture: OBS Virtual Camera in DS Capture, highest FPS available.
* Output: Titan Bridge with the Helios Creative GPC slot (same 48-byte
  Creative packet as Helios's CVTest example).
* Load this file in the CV Python tab.

In game
-------
* Toggle on/off: hold L1/LB and press D-pad Up.
* Overlay: green tick above the bar = target, magenta tick below = line,
  cyan underline = zone, plus Helios's meter readout. Top-left: lead in use,
  the script's own measurement of the last shot, and what 2K said.

Settings live in
%LOCALAPPDATA%\\HeliosProject\\Helios\\ScriptData\\NBA2K21_Meter\\settings_v4.json
(written on first run, keeping your lead etc. from v3; the settings app edits
it and the script reloads it live). Each shot is logged to shots_log.txt.
"""

import json
import struct
import time

import numpy as np

from helios import overlay
from helios.controls import (
    BUTTON_7,
    BUTTON_10,
    BUTTON_17,
    STICK_1_X,
    STICK_1_Y,
    get_actual,
    send_cvdata,
)

try:
    from helios import storage
except ImportError:  # older Helios builds
    storage = None


# --------------------------------------------------------------------------
# Settings
# --------------------------------------------------------------------------
SETTINGS = {
    "enabled_on_start": True,

    # "button" = hold Square/X to shoot.  "stick" = right-stick shot stick.
    "shoot_mode": "button",
    "shoot_button": BUTTON_17,            # Square (PS) / X (Xbox)
    "button_threshold": 50,
    "stick_threshold": 60,
    "stick_neutral": 25,

    # Timing
    "lead_ms": 40,            # release this long before the line hits target
    "auto_calibrate": False,  # fallback tuning from where the line stopped (when no 2K verdict is seen)
    "auto_gain": 0.35,        # fraction of each shot's error to correct
    "target_offset": 0.0,     # fine trim as a fraction of bar length (+ = later)
    # Where in the khaki zone to aim. Measured on 2K21 footage: EXCELLENT when
    # the line stopped 0.48-0.61 of the way across the zone, SLIGHTLY EARLY at
    # ~0.35, SLIGHTLY LATE at 0.62+. So: the zone's centre.
    "target_mode": "center",  # "center" (recommended), "start", or "slit" (old, unreliable)
    "zone_point": 0.52,       # 'center' mode: fraction of the way across the zone
    "speed_samples": 10,      # frames used to fit the line's speed
    "min_samples": 4,         # consistent readings needed before a release
    "fit_window_ms": 320,     # after the robust fit, refine the speed over this much
                              # of the line's path (it moves at a steady speed)
    "blend_native_eta": False,  # average Helios's meter ETA into the release (noisy - off)

    # Search area as fractions of the frame (left, top, right, bottom).
    # The meter only ever appeared between ~20% and ~75% of the screen height
    # in all recordings (16:9, ultrawide, Ante-Up); outside that band are the
    # crowd / arena and the near court lines + HUD, which only cause false
    # locks and cost time. Shown as a box that lights up while shooting.
    "search_area": [0.02, 0.10, 0.98, 0.80],
    "show_search_box": True,
    "search_step": 2,          # pixel stride while searching (1 = slowest)
    "max_candidates": 6,       # coarse hits per search frame (numpy fallback)
    "max_refine": 2,           # full-resolution checks per search frame (1, 2nd if time allows)
    "budget_ms": 2.5,          # stop extra checks once a frame has used this long
    "search_bands": 3,         # numpy fallback searches 1 of N screen bands per frame
    "use_native_search": True, # Helios's C++ ContourFinder for the coarse search
    "skip_far_ms": 140,        # until the line is this close to the target, analyse
                               # every other frame (only when capture > 150 fps)
    # HUD areas that are never the meter: top-right TIMING / score box and the
    # bottom-right score/clock. (from right edge, top, to right edge, bottom)
    # in frame heights - the HUD is anchored right, so this works at 16:9 and
    # ultrawide alike.
    "hud_exclude": [[0.60, 0.0, 0.0, 0.20], [0.52, 0.76, 0.0, 1.0]],

    # Meter appearance (capture pixels at 1080 lines; scaled automatically)
    "bar_min_width": 40,
    "bar_max_width": 420,
    "bar_min_height": 4,
    "bar_max_height": 24,
    "max_bend_ratio": 110,    # meter arch: bend radius / thickness must be below this

    # Colours
    "dark_max": 95, "dark_min": 26, "dark_spread": 24,   # charcoal interior (over court)
    "interior_max": 135,      # max brightness inside the bar, any tint (wall / corners)
    "interior_dark": 110,     # typical interior column brightness (meter check)
    "outline_min": 140, "outline_spread": 40,            # light-grey outline
    "zone_min_r": 140,                                   # khaki target zone
    "line_min_r": 200,                                   # gold line core

    # Toggle combo: hold toggle_hold and tap toggle_press
    "toggle_hold": BUTTON_7,              # L1 / LB
    "toggle_press": BUTTON_10,            # D-pad Up

    "debug_overlay": True,
    "meter_overlay": False,   # Helios meter readout (TIME/DISTANCE/SPEED/ETA) - its own
                              # estimate is jumpy, so off by default (timing doesn't use it)
    "use_native_meter": False, # feed Helios's built-in meter (only needed for that readout)
    "log_shots": True,        # one line per shot in shots_log.txt (script data folder)

    # 2K's own TIMING verdict (top-right box) is the final judge. After each
    # script release it's read and the lead corrected: LATE -> more lead,
    # EARLY -> less.
    "use_2k_verdict": False,      # tune the lead from 2K's verdict (independent of auto_calibrate)
    # (from right edge, top, from right edge, bottom) in frame heights - works
    # at any aspect ratio (16:9 or ultrawide)
    "verdict_area": [0.407, 0.108, 0.120, 0.142],
    "verdict_word_x": 0.368,      # where the verdict word starts, from the right edge
    "verdict_step_slight": 8,     # ms correction for SLIGHTLY EARLY/LATE
    "verdict_step_very": 20,      # ms correction for VERY EARLY/LATE
    "verdict_gain": 0.7,
}

SETTINGS_FILE = "settings_v6.json"
OLD_SETTINGS_FILE = "settings_v5.json"
# personal choices carried over from v4 on first run (detection tuning is not).
# Lead comes over 10 ms lower (v4.1 recordings: the line stopped ~20 ms early
# on average) and 2K-verdict tuning is switched back on.
LEAD_SHIFT_ON_UPGRADE = 0     # v4.4: lead carries over unchanged
CARRY_OVER = ("lead_ms", "auto_calibrate", "target_offset", "shoot_mode",
              "enabled_on_start", "debug_overlay", "toggle_hold", "toggle_press")

# Helios Creative packet (same layout as Helios's CVTest example)
PACKET_SIZE = 48
BUTTON_OFFSET = 11
LEGACY_STICK_OFFSET = 28
PRECISION_STICK_OFFSET = 32
RIGHT_STICK_X_INDEX = 0
RIGHT_STICK_Y_INDEX = 1


def _now_ms():
    return time.perf_counter() * 1000.0


# --------------------------------------------------------------------------
# Detection helpers (pure numpy, BGR crops)
# --------------------------------------------------------------------------
def _runs1d(mask, max_gap=0):
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        return []
    br = np.flatnonzero(np.diff(idx) > max_gap + 1)
    s = np.concatenate(([idx[0]], idx[br + 1]))
    e = np.concatenate((idx[br], [idx[-1]]))
    return list(zip(s.tolist(), e.tolist()))


def _channels(img):
    b = img[..., 0].astype(np.int16)
    g = img[..., 1].astype(np.int16)
    r = img[..., 2].astype(np.int16)
    mx = np.maximum(np.maximum(r, g), b)
    mn = np.minimum(np.minimum(r, g), b)
    return r, g, b, mx, mn


def find_bars(img, cfg, step, scale, max_candidates=4, paths="both"):
    """Find meter-bar candidates in a BGR crop (the caller scores them).

    Two independent ways of finding the bar's inside are tried:
      * charcoal: neutral dark pixels - right over the court and paint;
      * outline pair: whatever lies between a light-grey top AND bottom edge
        one bar-thickness apart - right over the purple wall, dark corners
        and anything else the semi-transparent bar sits on.
    ``step`` is the crop's pixel stride, ``scale`` converts capture pixels to
    1080-line pixels. Returns a list of dicts in crop pixels."""
    # 8-bit maths only here (this runs over the whole search area)
    b8, g8, r8 = img[..., 0], img[..., 1], img[..., 2]
    mx = np.maximum(np.maximum(r8, g8), b8)
    mn = np.minimum(np.minimum(r8, g8), b8)
    spread = mx - mn                      # never negative, so uint8 is safe
    H, W = mx.shape
    outline = (mn >= cfg["outline_min"]) & (spread <= cfg["outline_spread"])
    k = 1.0 / (step * scale)  # 1080-line px -> crop px
    geo = (H, W, k, cfg["bar_min_width"] * k, cfg["bar_max_width"] * k,
           cfg["bar_min_height"] * k, cfg["bar_max_height"] * k)
    out = []
    if paths in ("both", "charcoal"):
        charcoal = (mx <= cfg["dark_max"]) & (mn >= cfg["dark_min"]) & (spread <= cfg["dark_spread"])
        for b in _bars_from_mask(charcoal, outline, img, geo, max_candidates, True):
            b["path"] = "charcoal"
            out.append(b)
    if paths in ("both", "pair"):
        pair = _pair_interior(r8, b8, mx, outline, cfg, geo)
        if pair is not None:
            for b in _bars_from_mask(pair, outline, img, geo, max_candidates, False):
                b["path"] = "pair"
                out.append(b)
    return out


def quick_prescore(frame, x, y, w, h, cfg):
    """Cheap 'could this be the meter?' check on a box around a seed: most
    columns should contain dark interior pixels, ideally a khaki zone.
    Used to rank seeds before the expensive full check."""
    H, W = frame.shape[:2]
    x0, y0 = max(0, int(x)), max(0, int(y))
    x1, y1 = min(W, int(x + w)), min(H, int(y + h))
    if x1 - x0 < 8 or y1 - y0 < 3 or (x1 - x0) < 2.0 * (y1 - y0) * 0.6:
        return 0.0
    reg = frame[y0:y1, x0:x1]
    b = reg[..., 0]
    g = reg[..., 1]
    r = reg[..., 2]
    mx = np.maximum(np.maximum(r, g), b)
    dark_cols = (mx <= cfg["interior_max"]).mean(axis=0) >= 0.2
    darkfrac = float(dark_cols.mean())
    if darkfrac < 0.35:
        return 0.0
    r16 = r.astype(np.int16)
    g16 = g.astype(np.int16)
    b16 = b.astype(np.int16)
    khaki = (r16 >= cfg["zone_min_r"]) & (g16 * 100 >= 80 * r16) & (b16 * 100 <= 88 * r16) & (b16 * 100 >= 35 * r16)
    kfrac = float(khaki.any(axis=0).mean())
    return darkfrac + (0.8 if 0.04 <= kfrac <= 0.40 else 0.0)


def sandwich_score(frame, x, y, w, h, cfg, scale=1.0):
    """Fraction of columns in a seed box that look like a slice of the meter:
    a light-grey outline pixel above, dark inside, light outline below, one
    bar-thickness apart. Crowd, wood, shadows and HUD text rarely do this, so
    it picks the meter out of busy courts (Ante-Up) where dozens of dark and
    light shapes are found. Wide boxes are sampled every few columns."""
    H, W = frame.shape[:2]
    ext = int(max(4, h) + 6.0 / scale)
    x0, x1 = max(0, int(x)), min(W, int(x + w))
    y0, y1 = max(0, int(y) - ext), min(H, int(y + h) + ext)
    if x1 - x0 < 6 or y1 - y0 < 5:
        return 0.0
    cs = max(1, (x1 - x0) // 40)
    reg = frame[y0:y1, x0:x1:cs]
    mx = reg.max(axis=2)
    mn = reg.min(axis=2)
    light = (mn >= cfg["outline_min"]) & ((mx.astype(np.int16) - mn) <= cfg["outline_spread"])
    has = light.any(axis=0)
    if not has.any():
        return 0.0
    dark = mx <= cfg["interior_max"]
    n = light.shape[0]
    idx = np.arange(n)[:, None]
    first = np.where(has, np.argmax(light, axis=0), n)
    last = np.where(has, n - 1 - np.argmax(light[::-1], axis=0), -1)
    cnt = (dark & (idx > first) & (idx < last)).sum(axis=0)
    gap = last - first
    ok = has & (gap >= 3) & (gap <= 2.6 * max(h, 6) + 8.0 / scale) & (cnt >= 1) & (cnt >= 0.5 * (gap - 1))
    return float(ok.mean())


def _pair_interior(r8, b8, mx, outline, cfg, geo):
    """Pixels between a top outline edge and a bottom outline edge that are
    one bar-thickness apart, and that look like bar interior (dark of any
    tint, or the warm zone / line / glow)."""
    H, W, k, min_w, max_w, min_h, max_h = geo
    warm = (r8 >= 140) & (r8 > b8) & ((r8 - b8) >= 20)
    inner_ok = (mx <= cfg["interior_max"]) | warm
    top_edge = outline.copy()
    top_edge[:-1] &= ~outline[1:]          # last outline row of a top border
    bot_start = outline.copy()
    bot_start[1:] &= ~outline[:-1]         # first outline row of a bottom border
    rows_idx = np.arange(H, dtype=np.int32)[:, None]
    nb = np.where(bot_start, rows_idx, np.int32(H)).astype(np.int32)
    nb = np.minimum.accumulate(nb[::-1], axis=0)[::-1]   # next bottom edge at row >= y
    nxt = np.full((H, W), H, np.int32)
    nxt[:-1] = nb[1:]                                    # strictly below y
    gap = nxt - rows_idx - 1
    gmin = max(2, int(np.floor(0.6 * min_h)))
    gmax = max(gmin + 1, int(np.ceil(max_h)))
    ys, xs = np.nonzero(top_edge & (gap >= gmin) & (gap <= gmax))
    if ys.size == 0:
        return None
    yb = nxt[ys, xs]
    g = yb - ys - 1                                       # interior rows per column
    # count / paint interior rows directly at the candidate columns (the
    # interior is only a few rows tall, so this beats full-frame cumsums)
    inside = np.zeros(ys.size, np.int16)
    for o in range(1, gmax + 1):
        sel = o <= g
        if not sel.any():
            break
        inside[sel] += inner_ok[ys[sel] + o, xs[sel]]
    ok = inside >= 0.7 * g
    ys, xs, g = ys[ok], xs[ok], g[ok]
    if ys.size == 0:
        return None
    out = np.zeros((H, W), bool)
    for o in range(1, gmax + 1):
        sel = o <= g
        if not sel.any():
            break
        out[ys[sel] + o, xs[sel]] = True
    return out & inner_ok


def _bars_from_mask(dark, outline, img, geo, max_candidates, near_outline):
    H, W, k, min_w, max_w, min_h, max_h = geo
    # Horizontal interior runs (bridging 1-2 px holes), then group into blobs.
    dk = dark.copy()
    dk[:, 1:-1] |= dark[:, :-2] & dark[:, 2:]
    dk[:, 2:-2] |= dark[:, :-4] & dark[:, 4:]
    p = np.zeros((H, W + 2), np.int8)
    p[:, 1:-1] = dk
    d = np.diff(p, axis=1)
    rows, s = np.nonzero(d == 1)
    _, e = np.nonzero(d == -1)
    keep = (e - s) >= max(3, 0.3 * min_w)
    rows, s, e = rows[keep], s[keep], e[keep]
    if rows.size == 0:
        return []
    if near_outline:
        # Quick reject: the bar's dark rows have the light outline within
        # about one bar-thickness above or below. Dark walls/shadows don't.
        kk = max(2, int(np.ceil(0.6 * max_h)))
        near = outline.copy()                     # outline within +-kk rows
        for o in range(1, kk + 1):
            near[o:] |= outline[:-o]
            near[:-o] |= outline[o:]
        nc = np.zeros((H, W + 1), np.int32)
        np.cumsum(near, axis=1, dtype=np.int32, out=nc[:, 1:])
        keep = (nc[rows, e] - nc[rows, s]) >= 0.2 * (e - s)
        rows, s, e = rows[keep], s[keep], e[keep]
        if rows.size == 0:
            return []

    blobs = []          # [first_row, last_row, x_start, x_end, area]
    open_blobs = []
    for i in range(rows.size):
        y, a, z = rows[i], s[i], e[i]
        hit = None
        for bl in open_blobs:
            if y - bl[1] <= 1 and a < bl[3] and z > bl[2]:
                hit = bl
                break
        if hit is None:
            bl = [y, y, a, z, z - a]
            blobs.append(bl)
            open_blobs.append(bl)
        else:
            hit[1] = y
            hit[2] = min(hit[2], a)
            hit[3] = max(hit[3], z)
            hit[4] += z - a
        if i % 64 == 0:
            open_blobs = [bl for bl in open_blobs if y - bl[1] <= 1]

    # The line + glow (and the zone) cut the interior into pieces that can
    # each be too short to look like a bar. Re-join pieces at the same height
    # with only a short horizontal gap between them.
    blobs = sorted(blobs, key=lambda bl: bl[2])
    merged = []
    for bl in blobs:
        joined = False
        for mb in merged:
            h = max(bl[1] - bl[0], mb[1] - mb[0]) + 1
            overlap = min(bl[1], mb[1]) - max(bl[0], mb[0]) + 1
            gap = bl[2] - mb[3]
            th = max(bl[4] / max(1, bl[3] - bl[2]), mb[4] / max(1, mb[3] - mb[2]))
            if overlap >= 0.3 * h and -2 <= gap <= 2.5 * th + 2 and th <= max_h:
                mb[0], mb[1] = min(mb[0], bl[0]), max(mb[1], bl[1])
                mb[3] = max(mb[3], bl[3])
                mb[4] += bl[4]
                joined = True
                break
        if not joined:
            merged.append(list(bl))

    scored = []
    for top, bot, xs0, xs1, area in merged:
        h = bot - top + 1
        w = xs1 - xs0
        thick = area / max(1, w)          # true thickness (curvature-proof)
        if not (0.6 * min_h <= thick <= max_h) or w < 0.3 * min_w or w > max_w \
                or w < 2.5 * thick or h > 3.5 * thick + 4:
            continue
        # Outline check per column, just above/below that column's own
        # interior pixels (the bar is an arc, so edges aren't on fixed rows).
        sub = dk[top:bot + 1, xs0:xs1]
        has = sub.any(axis=0)
        if has.sum() < 3:
            continue
        cols = np.flatnonzero(has)
        first = top + np.argmax(sub[:, cols], axis=0)
        last = bot - np.argmax(sub[::-1, cols], axis=0)
        cx = cols + xs0
        kk = max(2, int(round(4 * k)))
        up_hit = np.zeros(cols.size, bool)
        dn_hit = np.zeros(cols.size, bool)
        for o in range(1, kk + 1):
            up_hit |= outline[np.clip(first - o, 0, H - 1), cx] & (first - o >= 0)
            dn_hit |= outline[np.clip(last + o, 0, H - 1), cx] & (last + o < H)
        up, dn = up_hit.mean(), dn_hit.mean()
        if min(up, dn) < 0.3:
            continue
        scored.append((min(up, dn) * w, top, bot, xs0, xs1))
    scored.sort(reverse=True)

    out = []
    for _, top, bot, xs0, xs1 in scored[:max_candidates]:
        h = bot - top + 1
        w = xs1 - xs0
        # Fit the arc's centre-line on every bar-thick column near the seed.
        wa, wb = max(0, xs0 - int(1.5 * w)), min(W, xs1 + int(1.5 * w))
        ra, rb = max(0, top - h), min(H, bot + h + 1)
        sub = dark[ra:rb, wa:wb]
        cnt = sub.sum(axis=0)
        cen = (sub * np.arange(ra, rb)[:, None]).sum(axis=0) / np.maximum(cnt, 1)
        colx = np.arange(wa, wb)
        seed_cnt = cnt[(colx >= xs0) & (colx < xs1)]
        seed_cnt = seed_cnt[seed_cnt > 0]
        hc = float(np.median(seed_cnt)) if seed_cnt.size else float(h)   # per-column thickness
        ok = (cnt >= 0.6 * hc) & (cnt <= 1.6 * hc)
        xs = colx[ok]
        cy = cen[ok]
        if xs.size < 5:
            continue
        seed = (xs >= xs0) & (xs < xs1)
        if seed.sum() < 3:
            continue
        coef = np.polyfit(xs[seed], cy[seed], 1 if seed.sum() < 20 else 2)
        tol = max(1.0, 0.35 * hc)
        for _ in range(2):
            good = np.abs(np.polyval(coef, xs) - cy) <= tol
            if good.sum() < 5:
                break
            deg = 2 if (xs[good].max() - xs[good].min()) > 20 else 1
            coef = np.polyfit(xs[good], cy[good], deg)
        good = np.abs(np.polyval(coef, xs) - cy) <= tol
        if good.sum() < 5:
            continue
        out.append({"coef": coef, "half": float(np.median(cnt[ok][good])) / 2.0,
                    "x0": int(xs[good].min()), "x1": int(xs[good].max()),
                    "img": img, "dark": dark})
    return out


def analyse_bar(bar, cfg):
    """Bar extent, zone and line candidates (crop px). None if implausible."""
    r, g, b, mx, mn = _channels(bar["img"])
    dark = bar["dark"]
    H, W = r.shape
    half = bar["half"]
    hb = max(1, int(round(half)))
    span = bar["x1"] - bar["x0"] + 1
    xs = np.arange(max(0, int(bar["x0"] - 0.8 * span)), min(W, int(bar["x1"] + 0.8 * span) + 1))
    cy = np.polyval(bar["coef"], xs)
    offs = np.arange(-hb + 1, hb) if hb > 1 else np.array([0])
    Y = np.clip(np.round(cy[None, :] + offs[:, None]).astype(int), 0, H - 1)
    X = np.broadcast_to(xs[None, :], Y.shape)
    R, G, B, MX, MN = r[Y, X], g[Y, X], b[Y, X], mx[Y, X], mn[Y, X]

    core = (R >= cfg["line_min_r"]) & (G * 100 >= 78 * R) & (R - B >= 25)
    zone = ((R >= cfg["zone_min_r"]) & (G * 100 >= 80 * R) & (B * 100 <= 88 * R)
            & (B * 100 >= 35 * R) & ~core)
    dfrac = dark[Y, X].mean(axis=0)
    zfrac = zone.mean(axis=0)
    lfrac = core.mean(axis=0)
    ofrac = ((MN >= cfg["outline_min"]) & (MX - MN <= cfg["outline_spread"])).mean(axis=0)

    # Walk outward along the arc from the dark core through zone / line /
    # grey end caps, tolerating short seams. The line's warm glow tints the
    # dark interior brown for several px either side; treat that as bar too,
    # otherwise the bar gets cut in two at the line.
    body = (dfrac >= 0.5) | (zfrac >= 0.3) | (lfrac >= 0.3) | (ofrac >= 0.3)
    warm = ((R - B >= 25) & (R >= 60) & (MX <= 235)).mean(axis=0) >= 0.4
    glow_r = max(4, int(round(3.0 * half)))
    for a, z in _runs1d(lfrac >= 0.3, max_gap=1):
        lo, hi = max(0, a - glow_r), min(xs.size, z + glow_r + 1)
        body[lo:hi] |= warm[lo:hi]
    core_idx = np.flatnonzero((xs >= bar["x0"]) & (xs <= bar["x1"]) & (dfrac >= 0.5))
    if core_idx.size == 0:
        return None
    seam = max(3, int(round(0.6 * half)))

    def walk(i, step):
        last, miss = i, 0
        while 0 <= i + step < xs.size:
            i += step
            if body[i]:
                last, miss = i, 0
            else:
                miss += 1
                if miss > seam:
                    break
        return last

    ia, ib = walk(int(core_idx[0]), -1), walk(int(core_idx[-1]), 1)
    # left end of the charcoal interior (crisp edge against the grey outline)
    i = int(core_idx[0])
    while i - 1 >= 0 and (dfrac[i - 1] >= 0.5 or (i - 2 >= 0 and dfrac[i - 2] >= 0.5)):
        i -= 1
    dark_left = float(xs[i])
    left, right = float(xs[ia]), float(xs[ib])
    if right - left < 4 * half:
        return None
    inside = np.zeros(xs.size, bool)
    inside[ia:ib + 1] = True

    # Line candidates: narrow runs of bright gold core inside the bar.
    lines = []
    edge = max(1.5 * half, 0.035 * (right - left))   # end caps catch glints
    for a, z in _runs1d((lfrac >= 0.3) & inside, max_gap=1):
        if (xs[z] - xs[a] + 1) > max(4.0, 0.12 * (right - left)):
            continue
        wts = lfrac[a:z + 1]
        x = float((xs[a:z + 1] * wts).sum() / wts.sum())
        if x - left < edge or right - x < edge:
            continue
        lines.append((x, float(wts.max())))

    # Zone: khaki columns, ignoring anything next to a line candidate.
    zmask = (zfrac >= 0.4) & inside
    for x, _ in lines:
        zmask &= np.abs(xs - x) > max(2.0, half)
    zone_out = None
    zr = _runs1d(zmask, max_gap=max(3, int(half)))
    # re-join zone pieces split by the line sitting inside the zone
    merged = []
    for run in zr:
        if merged:
            gap_lo, gap_hi = xs[merged[-1][1]], xs[run[0]]
            if (gap_hi - gap_lo) <= 3 * half + 6 and any(gap_lo <= x <= gap_hi for x, _ in lines):
                merged[-1] = (merged[-1][0], run[1])
                continue
        merged.append(run)
    zr = merged
    if zr:
        a, z = max(zr, key=lambda t: zfrac[t[0]:t[1] + 1].sum())
        if xs[z] - xs[a] + 1 >= max(3.0, 0.04 * (right - left)):
            seg = zfrac[a:z + 1]
            slit = None
            gaps = [(ga, gb) for ga, gb in _runs1d(seg < 0.25) if ga > 0 and gb < seg.size - 1]
            if gaps:
                ga, gb = max(gaps, key=lambda t: t[1] - t[0])
                slit = float(xs[a + ga] + xs[a + gb]) / 2.0
            zone_out = (float(xs[a]), float(xs[z]), slit)

    # How much does this look like THE meter? Court-line pairs, HUD panels
    # etc. score low. Used to pick a new meter among candidates.
    L = right - left
    thick = max(1.0, 2.0 * half)
    sel = inside.copy()
    for x, _ in lines:
        sel &= np.abs(xs - x) > max(4.0, 5.0 * half)       # the line's flare is wide
    if zone_out is not None:
        sel &= (xs < zone_out[0] - 1) | (xs > zone_out[1] + 1)
    darkfrac = 0.0
    if sel.sum() >= 3:
        c0 = MX.shape[0] // 2
        cr = max(0, int(0.25 * MX.shape[0]))              # central rows only
        col_med = np.median(MX[c0 - cr:c0 + cr + 1][:, sel], axis=0)
        darkfrac = float((col_med <= cfg["interior_dark"]).mean())
    aspect = L / thick
    zone_ok = False
    if zone_out is not None and L > 0:
        zw_frac = (zone_out[1] - zone_out[0]) / L
        zpos = (0.5 * (zone_out[0] + zone_out[1]) - left) / L
        zone_ok = 0.05 <= zw_frac <= 0.32 and 0.35 <= zpos <= 0.97
    score = 0.0
    if 4.5 <= aspect <= 22 and darkfrac >= 0.45 and len(lines) <= 3:
        score = darkfrac + (1.0 if zone_ok else 0.0) + (0.3 if lines else 0.0)
    # The meter always arches upward (ends lower than the middle) with a
    # bend radius of roughly 25-70x its thickness. The player's floor badge
    # and court lines bow the other way or are nearly straight.
    coef = bar["coef"]
    c2 = float(coef[0]) if len(coef) == 3 else 0.0
    arch_ok = c2 > 0 and (1.0 / (2.0 * c2)) / thick <= cfg["max_bend_ratio"]
    mid = (left + right) / 2.0
    return {"left": left, "right": right, "lines": lines, "zone": zone_out,
            "dleft": dark_left, "cy": float(np.polyval(bar["coef"], mid)), "half": half,
            "score": score, "zone_ok": zone_ok, "darkfrac": darkfrac, "aspect": aspect,
            "arch_ok": arch_ok}


class VerdictReader:
    """Reads 2K's 'TIMING: ...' verdict from the HUD box (top right).

    The grade is the word's colour: EXCELLENT green, SLIGHTLY yellow-green,
    VERY dark red. EARLY vs LATE is the ratio of the second word's width to
    the first ('LATE' is as wide as 'VERY'; 'EARLY' is about 25% wider) -
    a ratio, so it works at any capture size or aspect ratio."""

    @staticmethod
    def read(frame, area, word_x=None):
        """``area`` = (left, top, right, bottom). The HUD is anchored to the
        right edge and sized by the frame height, so left/right are distances
        from the RIGHT edge in frame heights, top/bottom are frame heights.
        ``word_x`` is where the word starts, also from the right edge."""
        H, W = frame.shape[:2]
        x0, x1 = int(W - area[0] * H), int(W - area[2] * H)
        y0, y1 = int(area[1] * H), int(area[3] * H)
        if word_x is not None:
            word_x = (W - word_x * H) / float(W)
        if x1 - x0 < 10 or y1 - y0 < 4:
            return None
        reg = frame[y0:y1, x0:x1]
        b = reg[..., 0].astype(np.int16)
        g = reg[..., 1].astype(np.int16)
        r = reg[..., 2].astype(np.int16)
        masks = (("VERY", (r >= 100) & (g <= 45) & (b <= 50) & (r - g >= 70)),
                 ("SLIGHTLY", (r >= 120) & (g >= 135) & (b <= 80) & (np.abs(r - g) <= 45)),
                 ("EXCELLENT", (g >= 110) & (r <= 100) & (b <= 80) & (g - r >= 50)))
        best = None
        for name, mk in masks:
            n = int(mk.sum())
            if n < max(15, 0.004 * mk.size):
                continue
            rows = np.flatnonzero(mk.any(axis=1))
            text_h = rows[-1] - rows[0] + 1
            if text_h > 0.85 * mk.shape[0] or text_h < 3:
                continue                          # not a line of text
            cols = mk.any(axis=0)
            pieces = _runs1d(cols, max_gap=0)
            if not pieces or pieces[-1][1] - pieces[0][0] + 1 < 2 * text_h:
                continue
            # two words: split at the single widest gap (letter gaps vary)
            words = [(pieces[0][0], pieces[-1][1])]
            if len(pieces) >= 2:
                gaps = [pieces[j + 1][0] - pieces[j][1] for j in range(len(pieces) - 1)]
                j = int(np.argmax(gaps))
                if gaps[j] >= max(3, 0.35 * text_h):
                    words = [(pieces[0][0], pieces[j][1]), (pieces[j + 1][0], pieces[-1][1])]
            if word_x is not None and abs((x0 + words[0][0]) / float(W) - word_x) > 0.012:
                continue                          # verdict starts right after "TIMING:"
            if best is None or n > best[1]:
                best = (name, n, words)
        if best is None:
            return None
        name, _, words = best
        if name == "EXCELLENT":
            return "EXCELLENT", 0
        if len(words) < 2:
            return None
        w1 = words[0][1] - words[0][0] + 1
        w2 = words[1][1] - words[1][0] + 1
        ratio = w2 / float(w1)
        if name == "VERY":
            return ("VERY EARLY", -2) if ratio > 1.12 else ("VERY LATE", 2)
        return ("SLIGHTLY EARLY", -1) if ratio > 0.60 else ("SLIGHTLY LATE", 1)


class NativeSeeds:
    """Fast coarse search with Helios's native ContourFinder (C++/AVX):
    finds the meter's light-grey outline - one connected shape boxing the
    bar on any background - in well under a millisecond. Python then checks
    only small windows around the best few. Falls back to the numpy search
    if the API isn't available or misbehaves."""

    def __init__(self, cfg):
        self.ok = False
        self.fails = 0
        try:
            from helios import vision as _vision
            fa = cfg["search_area"]
            roi = (int(fa[0] * 1920), int(fa[1] * 1080),
                   int((fa[2] - fa[0]) * 1920), int((fa[3] - fa[1]) * 1080))
            lo = int(cfg["outline_min"])
            # 1) the light-grey outline (one shape boxing the bar)
            self.f = _vision.ContourFinder(
                colors=[_vision.BgrRange((lo, lo, lo), (255, 255, 255))],
                roi=roi,
                width=(int(cfg["bar_min_width"] * 0.6), int(cfg["bar_max_width"] + 40)),
                height=(3, int(cfg["bar_max_height"] * 2 + 24)),
                max_results=128,
            )
            try:
                self.f.set_maximum_channel_spread(int(cfg["outline_spread"]))
            except Exception:
                pass
            self.f.set_visuals(enabled=False)
            # 2) the bar's dark grey inside. Needed on courts with light paint
            #    and busy lines (Ante-Up): there the outline merges with court
            #    lines / paint touching it and is lost among bigger shapes.
            self.f2 = None
            try:
                dlo, dhi = int(cfg["dark_min"]), int(cfg["dark_max"])
                self.f2 = _vision.ContourFinder(
                    colors=[_vision.BgrRange((dlo, dlo, dlo), (dhi, dhi, dhi))],
                    roi=roi,
                    width=(12, int(cfg["bar_max_width"])),
                    height=(3, int(cfg["bar_max_height"] + 6)),
                    max_results=128,
                )
                try:
                    self.f2.set_maximum_channel_spread(int(cfg["dark_spread"]))
                except Exception:
                    pass
                self.f2.set_visuals(enabled=False)
            except Exception:
                self.f2 = None
            self.ok = True
        except Exception:
            self.ok = False

    @staticmethod
    def _boxes(res):
        out = []
        n = len(res)
        for i in range(n):
            bx, by, bw, bh = res[i].bounds
            out.append((int(bx), int(by), int(bw), int(bh)))
        return out

    def find(self):
        if not self.ok:
            return []
        try:
            out = self._boxes(self.f.find())
            self.n_outline = len(out)
            if self.f2 is not None:
                try:
                    out += self._boxes(self.f2.find())
                except Exception:
                    self.f2 = None
            self.fails = 0
            return out
        except Exception:
            self.fails += 1
            if self.fails > 10:
                self.ok = False
            return []


class NativeMeter:
    """Helios's built-in helios.meter, used the way 2K Vision uses it: each
    frame it gets the line's position and the release target, and returns a
    fitted closing speed and ETA stamped with the frame's capture time. Its
    visuals draw the same TIME / DISTANCE / SPEED PX/MS / ETA MS readout and
    path line you see in 2K Vision. If the API is missing or rejects input,
    the script's own fit is used alone."""

    def __init__(self, samples, visuals):
        self.ok = False
        try:
            from helios import meter as _meter
            self._mod = _meter
            self.m = _meter.Meter()
            self.m.set_motion(model="average", samples=int(max(3, min(32, samples))))
            self.set_visuals(visuals)
            self.ok = True
        except Exception:
            self.ok = False
        self.eta = None
        self.t = None

    def set_visuals(self, on):
        try:
            self.m.set_visuals(enabled=bool(on), show_elapsed_time=True,
                               bbox_thickness=1, path_thickness=2, text_scale=2)
        except Exception:
            try:
                self.m.set_visuals(enabled=bool(on))
            except Exception:
                pass

    def reset(self):
        self.eta = None
        self.t = None
        if self.ok:
            try:
                self.m.reset()
            except Exception:
                pass

    def update(self, t_cap, point, release_point, box, frame_w, frame_h):
        self.eta = None
        if not self.ok:
            return None
        x, y, w, h = box
        x, y = max(0, int(x)), max(0, int(y))
        w = int(min(frame_w - 1 - x, w))
        h = int(min(frame_h - 1 - y, h))
        px = min(frame_w - 1.0, max(0.0, point[0]))
        rx = min(frame_w - 1.0, max(0.0, release_point[0]))
        if w < 4 or h < 2:
            return None
        try:
            self.m.update(point=(px, point[1]), release_point=(rx, release_point[1]),
                          bounding_box=(x, y, w, h), padding=(10, 14, 10, 14))
            eta = self.m.time_to_release_ms
            self.eta = None if eta is None else float(eta)
            self.t = t_cap
        except Exception:
            self.fails = getattr(self, "fails", 0) + 1
            if self.fails > 20:
                self.ok = False
        return self.eta


# --------------------------------------------------------------------------
# Frame clock: Helios capture timestamps
# --------------------------------------------------------------------------
class FrameClock:
    """Capture time of the current frame and 'now', in ms, same clock.

    helios.meter stamps each update with the current frame's producer
    timestamp, and vision.latency_timestamp_ns() reads the same steady clock.
    Using capture time (not the moment Python got round to the frame) removes
    processing jitter and counts the frame's age correctly. Falls back to
    process time if the API isn't available."""

    def __init__(self):
        self.ok = False
        self.fails = 0
        try:
            from helios import meter as _meter, vision as _vision
            self._m = _meter.Meter()
            try:
                self._m.set_visuals(enabled=False)
            except Exception:
                pass
            self._now = _vision.latency_timestamp_ns
            self.ok = True
        except Exception:
            self.ok = False

    def stamp(self):
        if self.ok:
            try:
                # dummy points; only the frame timestamp is used
                self._m.update(point=(20.0, 20.0), release_point=(30.0, 20.0),
                               bounding_box=(10, 10, 40, 40))
                ts = int(self._m.timestamp_ns)
                now = int(self._now())
                age = (now - ts) / 1e6
                if ts > 0 and -1.0 <= age <= 1000.0:
                    self.fails = 0
                    return ts / 1e6, now / 1e6
            except Exception:
                pass
            self.fails += 1
            if self.fails > 30:
                self.ok = False
        t = _now_ms()
        return t, t

    def now(self):
        if self.ok:
            try:
                return int(self._now()) / 1e6
            except Exception:
                pass
        return _now_ms()


# --------------------------------------------------------------------------
# Worker
# --------------------------------------------------------------------------
IDLE, TRACKING, RELEASED, OBSERVE = 0, 1, 2, 3


class CVWorker:
    def __init__(self, width, height):
        self.cfg = dict(SETTINGS)
        self._load_settings()
        self.width, self.height = width, height
        self.scale = 1080.0 / height          # capture px -> 1080-line px
        self.seed_rot = 0                     # where native seed scoring resumes
        self.packet = bytearray(PACKET_SIZE)
        self.frame_no = 0
        self.enabled = bool(self.cfg["enabled_on_start"])
        self.toggle_latch = False
        self.last_result = ""
        self.speed_history = []    # closing speeds from earlier shots (bar heights / ms)
        self.off_ratio_hist = []   # target offset from zone right edge / bar height
        self.zw_ratio_hist = []    # zone width / bar height
        self.err_history = []      # recent measured release errors (ms)
        self.v_last_sign = None    # side of the last non-EXCELLENT verdict
        self.v_scale = 1.0         # verdict step size multiplier
        self.v_last_very = None    # side of the last VERY verdict (None if the last wasn't VERY)
        self.v_very_mult = 1.0     # VERY step multiplier (doubles on repeats)
        self.last_err = None
        self.clock = FrameClock()
        self.watch = None          # pending 2K verdict after a script release
        self.verdict_msg = ""
        self._frame = None
        self.seeder = NativeSeeds(self.cfg) if self.cfg["use_native_search"] else None
        self.frame_dt = 8.0
        self.last_tcap = None
        self.bands = max(1, int(self.cfg["search_bands"]))
        self.rejected = []         # recently checked seeds that weren't the meter
        self.native = NativeMeter(self.cfg["speed_samples"],
                                  self.cfg["meter_overlay"] and self.cfg["debug_overlay"])
        self._reset_shot()

    def _load_settings(self):
        """Read settings_v6.json (written on first run). The settings app
        edits this file; _poll_settings() picks changes up while running."""
        self.settings_path = None
        self.settings_mtime = None
        self.settings_note_until = 0.0
        if storage is None:
            return
        try:
            path = storage.data_directory() / SETTINGS_FILE
            self.settings_path = path
            if not path.exists():
                old = path.parent / OLD_SETTINGS_FILE
                if old.exists():
                    try:
                        with open(old, "r", encoding="utf-8") as f:
                            prev = json.load(f)
                        for k in CARRY_OVER:
                            if k in prev and isinstance(prev[k], type(SETTINGS[k])):
                                self.cfg[k] = prev[k]
                        if isinstance(prev.get("lead_ms"), int) and prev["lead_ms"] <= 60:
                            # offline-range lead only (online modes need far more)
                            self.cfg["lead_ms"] = max(0, prev["lead_ms"] + LEAD_SHIFT_ON_UPGRADE)
                    except Exception:
                        pass
                tmp = path.with_suffix(".tmp")
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self.cfg, f, indent=2)
                tmp.replace(path)
            self._auto_off_once(path)
            self._apply_settings_file()
        except Exception as exc:  # never let settings break the script
            print("NBA2K21_Meter: settings not loaded:", exc)

    def _auto_off_once(self, path):
        """Automatic timing changes are now off unless you switch them on
        (Shot settings). Turn both kinds off once for existing settings."""
        try:
            with open(path, "r", encoding="utf-8") as f:
                cur = json.load(f)
            if cur.get("auto_off_v1"):
                return
            cur.update({"auto_calibrate": False, "use_2k_verdict": False, "auto_off_v1": True})
            tmp = path.with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(cur, f, indent=2)
            tmp.replace(path)
        except Exception:
            pass

    def _apply_settings_file(self):
        path = self.settings_path
        mtime = path.stat().st_mtime
        with open(path, "r", encoding="utf-8") as f:
            user = json.load(f)
        for k, v in user.items():
            if k in SETTINGS and isinstance(v, type(SETTINGS[k])) or (
                    k in SETTINGS and isinstance(SETTINGS[k], float) and isinstance(v, int)):
                self.cfg[k] = v
        self.settings_mtime = mtime

    def _poll_settings(self):
        """Hot-reload: check the settings file about twice a second."""
        if self.settings_path is None or self.frame_no % 60:
            return
        try:
            mtime = self.settings_path.stat().st_mtime
            if mtime != self.settings_mtime:
                self._apply_settings_file()
                if hasattr(self, "native"):
                    self.native.set_visuals(self.cfg["meter_overlay"] and self.cfg["debug_overlay"])
                self.settings_note_until = _now_ms() + 2000
        except Exception:
            pass  # file mid-write or missing; try again next poll

    # ----- shot state -------------------------------------------------------
    # ----- shot state -------------------------------------------------------
    def _reset_shot(self):
        self.state = IDLE
        self.track_roi = None
        self.track_miss = 0
        self.stale = 0             # tracked frames without a usable reading
        self.track_path = "both"   # which finder found the bar last frame
        self.bar_len0 = None       # longest bar length seen this shot
        self.last_bar = None
        self.blank_frames = 0
        self.excluded = []         # areas that looked like a bar but weren't
        self.stale_since = None    # capture ms when the locked bar stopped giving readings
        # target geometry, anchored on the zone's far (right) edge
        self.lock_hist = []        # (zone width, right edge - target) from clean frames
        self.tx_rel = []           # target position relative to the bar's ends, this shot
        self.tx_rejects = 0        # consecutive target readings that disagreed with it
        self.bar_hs = []           # bar thickness per frame (px) - the scale unit
        self.left_gaps = []        # target - left end of dark interior, from clean frames
        self.bar_h = None
        self.geom_learned = False
        self.zone_w0 = None
        self.off_r = None
        self.target_frozen = False
        self.release_bar = None    # (x, y, width) of the meter at release
        self.cand_frames = []      # (capture ms, [distance px for each line candidate])
        if hasattr(self, "native"):
            self.native.reset()
        self.eta_source = "own"
        self.samples = []          # (capture ms, fitted line distance) for display
        self.fit = None            # (t ms, distance px, closing speed px/ms)
        self.fit_streak = 0        # frames in a row with a fit
        self.eta = None
        self.release_t = None
        self.release_speed = None
        self.release_fit = None
        self.release_cap = None
        self.release_used_prior = False
        self.after = []            # (t, distance) after release, for calibration
        self.last_seen = None      # (analysis, target_x, line_x) for drawing
        self.t_cap = self.t_now = 0.0

    def _trigger_held(self):
        if self.cfg["shoot_mode"] == "stick":
            return self._stick_mag() >= self.cfg["stick_threshold"]
        return get_actual(self.cfg["shoot_button"]) >= self.cfg["button_threshold"]

    def _trigger_let_go(self):
        if self.cfg["shoot_mode"] == "stick":
            return self._stick_mag() <= self.cfg["stick_neutral"]
        return get_actual(self.cfg["shoot_button"]) < self.cfg["button_threshold"]

    def _stick_mag(self):
        x, y = get_actual(STICK_1_X), get_actual(STICK_1_Y)
        return (x * x + y * y) ** 0.5

    def _handle_toggle(self):
        hold = get_actual(self.cfg["toggle_hold"]) >= 50
        press = get_actual(self.cfg["toggle_press"]) >= 50
        if hold and press and not self.toggle_latch:
            self.enabled = not self.enabled
            self.toggle_latch = True
            self._reset_shot()
        elif not press:
            self.toggle_latch = False

    # ----- packet -----------------------------------------------------------
    def _write_button(self, button, value):
        self.packet[BUTTON_OFFSET + button] = max(0, min(100, int(value))) | 1

    def _write_stick(self, index, value):
        v = max(-100.0, min(100.0, float(value)))
        self.packet[LEGACY_STICK_OFFSET + index] = (int(v) + 100) | 1
        struct.pack_into(">i", self.packet, PRECISION_STICK_OFFSET + index * 4,
                         int(v * 0x10000))

    def _send(self, force_release):
        self.packet[:] = bytes(PACKET_SIZE)  # zero = pass everything through
        self.packet[0] = self.frame_no & 0xFF
        if force_release:
            if self.cfg["shoot_mode"] == "stick":
                self._write_stick(RIGHT_STICK_X_INDEX, 0)
                self._write_stick(RIGHT_STICK_Y_INDEX, 0)
            else:
                self._write_button(self.cfg["shoot_button"], 0)
        send_cvdata(self.packet)

    def close(self):
        send_cvdata(bytearray(PACKET_SIZE))

    # ----- detection --------------------------------------------------------
    def _detect(self, frame):
        """Analyse the meter. While locked onto something that isn't giving
        usable readings, keep re-running the full-screen search every few
        frames so a wrong lock can't hide the real meter."""
        tracking = self.track_roi is not None
        a = self._detect_once(frame)
        weak = a is None or self.stale >= 3
        if tracking and weak and self.state == TRACKING and self.frame_no % 4 == 0:
            saved = (self.track_roi, self.track_miss, self.last_bar, self.blank_frames)
            self.track_roi = None
            b = self._detect_once(frame)
            if b is not None:
                if a is None or abs(b["cy"] - a["cy"]) > 2 * max(4.0, 2 * a["half"]) \
                        or abs(0.5 * (b["left"] + b["right"]) - 0.5 * (a["left"] + a["right"])) > (a["right"] - a["left"]):
                    self.stale = 0
                return b
            self.track_roi, self.track_miss, self.last_bar, self.blank_frames = saved
        return a

    def _detect_once(self, frame):
        """Analyse the meter. Returns dict in frame px or None."""
        cfg = self.cfg
        if self.track_roi is not None:
            x0, y0, x1, y1 = self.track_roi
            step = 1
        else:
            fa = cfg["search_area"]
            x0, y0 = int(fa[0] * self.width), int(fa[1] * self.height)
            x1, y1 = int(fa[2] * self.width), int(fa[3] * self.height)
            step = max(1, int(cfg["search_step"]))
            if step > 1:
                # The outline is only 1-2 px thick, so a strided search can
                # miss it on one sampling phase. Rotate the phase each frame.
                ph = (self.frame_no // 2) % (step * step)
                x0 += ph % step
                y0 += ph // step
        x0, y0 = max(0, x0), max(0, y0)
        x1, y1 = min(self.width, x1), min(self.height, y1)
        if x1 - x0 < 16 or y1 - y0 < 8:
            self.track_roi = None
            return None
        tracking = self.track_roi is not None
        t_start = time.perf_counter()
        cands = []
        if tracking:
            # Fast path: the finder that found the bar last frame, at most two
            # candidates; the other finder only if that finds nothing.
            crop = frame[y0:y1, x0:x1]
            first = self.track_path if self.track_path in ("charcoal", "pair") else "both"
            bars = find_bars(crop, cfg, 1, self.scale, 2, first)
            if not bars and first != "both":
                bars = find_bars(crop, cfg, 1, self.scale, 2,
                                 "pair" if first == "charcoal" else "charcoal")
            for bar in bars[:3]:
                c = analyse_bar(bar, cfg)
                if c is not None:
                    c["path"] = bar["path"]
                    cands.append((c, x0, y0))
                    # clearly the same bar as last frame: no need to look further
                    if self.last_bar is not None and (c["zone"] is not None or c["lines"]):
                        px, py, pw = self.last_bar
                        if abs(x0 + 0.5 * (c["left"] + c["right"]) - px) < 0.25 * pw and \
                                abs(y0 + c["cy"] - py) < max(6.0, 3.0 * c["half"]):
                            break
        else:
            budget = self._budget_ms() / 1000.0
            refined = 0
            seeds = self._seeds(frame, x0, y0, x1, y1, step)
            t_ref = time.perf_counter()            # budget covers the full checks
            # one full check per frame (a second only if there's time left);
            # seeds that turned out not to be the meter are skipped for a
            # moment so the next-best one gets its turn on the next frame
            self.rejected = [r for r in self.rejected if self.t_now - r[2] < 150.0]
            for pre, (ox, oy, x1r, y1r) in seeds:
                if refined >= int(cfg["max_refine"]):
                    break
                if refined >= 1 and time.perf_counter() - t_ref > 0.4 * budget:
                    break
                cxs, cys = 0.5 * (ox + x1r), 0.5 * (oy + y1r)
                if self._excluded(ox, oy, x1r, y1r) or any(
                        abs(cxs - rx) < 30 and abs(cys - ry) < 30 for rx, ry, _ in self.rejected):
                    continue
                refined += 1
                n_before = len(cands)
                for fb in find_bars(frame[oy:y1r, ox:x1r], cfg, 1, self.scale, 2):
                    c = analyse_bar(fb, cfg)
                    if c is not None:
                        c["path"] = fb["path"]
                        cands.append((c, ox, oy))
                if not any(c["zone_ok"] and c["score"] >= 1.5 and c["arch_ok"] for c, _, _ in cands[n_before:]):
                    self.rejected.append((cxs, cys, self.t_now))
        a = None
        best_key = None
        for cand, ox, oy in cands:
            if self._in_hud(ox + 0.5 * (cand["left"] + cand["right"]), oy + cand["cy"]):
                continue
            if tracking:
                if cand["zone"] is None and not cand["lines"]:
                    continue
                key = cand["score"] + (1.0 if cand["zone"] is not None else 0.0)
                if self.last_bar is not None:
                    px, py, pw = self.last_bar
                    cxx = ox + 0.5 * (cand["left"] + cand["right"])
                    key -= (abs(cxx - px) + abs(oy + cand["cy"] - py)) / max(20.0, pw)
            else:
                if not cand["zone_ok"] or cand["score"] < 1.5 or not cand["arch_ok"]:
                    continue
                key = cand["score"]
            if best_key is None or key > best_key:
                a, best_key, best_xy = cand, key, (ox, oy)
        if a is not None:
            x0, y0 = best_xy
        if a is None:
            # keep looking in (a slightly wider) tracking window for a few
            # frames before falling back to the slow full-screen search
            if tracking and self.track_miss < 8:
                self.track_miss += 1
                x0, y0, x1, y1 = self.track_roi
                gx, gy = 0.1 * (x1 - x0), 0.1 * (y1 - y0)
                self.track_roi = (int(x0 - gx), int(y0 - gy), int(x1 + gx), int(y1 + gy))
            else:
                self.track_roi = None
                self.track_miss = 0
            return None
        self.track_miss = 0
        if a["zone"] is None and not a["lines"]:
            self.blank_frames += 1
            if self.blank_frames > 8:   # tracked something that isn't the meter
                w = a["right"] - a["left"]
                self.excluded.append((x0 + a["left"] - w, y0 + a["cy"] - 40,
                                      x0 + a["right"] + w, y0 + a["cy"] + 40))
                self.track_roi = None
                self.blank_frames = 0
                return None
        else:
            self.blank_frames = 0
        # back to frame coordinates
        a["left"] += x0
        a["right"] += x0
        a["dleft"] += x0
        a["cy"] += y0
        a["lines"] = [(x + x0, s) for x, s in a["lines"]]
        if a["zone"] is not None:
            zl, zr, zs = a["zone"]
            a["zone"] = (zl + x0, zr + x0, None if zs is None else zs + x0)
        self.last_bar = (0.5 * (a["left"] + a["right"]), a["cy"], a["right"] - a["left"])
        self.track_path = a.get("path", "both")
        # track a window around the bar on the next frame (meter rises fast)
        w = a["right"] - a["left"]
        # The meter rises fast while the player jumps, so the window allows
        # for that vertically; sideways it barely moves. When the bar was only
        # partly found, allow for the rest of it.
        L0 = max(w, self.bar_len0 or 0.0)
        pad = max(0.25 * L0 + (L0 - w), 36.0 / self.scale)
        h = max(4.0, a["half"] * 2)
        self.track_roi = (int(a["left"] - pad), int(a["cy"] - 3 * h - 14),
                          int(a["right"] + pad), int(a["cy"] + 3 * h + 14))
        if a["zone"] is not None:
            self.bar_len0 = max(self.bar_len0 or 0.0, w)
        return a

    def _budget_ms(self):
        """Time a frame may spend: the setting, or half the frame interval on
        slower capture (at 60 fps there are 16 ms per frame to use)."""
        return max(self.cfg["budget_ms"], 0.5 * self.frame_dt)

    def _seeds(self, frame, x0, y0, x1, y1, step):
        """Coarse candidates as (prescore, refine window), best first."""
        cfg = self.cfg
        W, H = self.width, self.height
        raw = []                                   # (x, y, w, h) boxes in frame px
        if self.seeder is not None and self.seeder.ok:
            raw = self.seeder.find()
        if self.seeder is None or not self.seeder.ok:
            # numpy fallback: one band of the search area per frame, the two
            # finders on alternate frames - a full sweep every 2N frames
            nb = self.bands
            band = (self.frame_no // 2) % nb
            span = (x1 - x0) / float(nb)
            ov = 0.12 * (x1 - x0)
            bx0 = int(max(x0, x0 + band * span - ov))
            bx1 = int(min(x1, x0 + (band + 1) * span + ov))
            path = "charcoal" if self.frame_no % 2 == 0 else "pair"
            crop = frame[y0:y1:step, bx0:bx1:step]
            tc = time.perf_counter()
            coarse = find_bars(crop, cfg, step, self.scale, int(cfg["max_candidates"]), path)
            # keep the coarse pass inside the frame budget: slice the screen
            # finer on a slow PC, coarser on a fast one
            el = (time.perf_counter() - tc) * 1000.0
            budget = self._budget_ms()
            max_bands = max(1, min(8, int(70.0 / (2.0 * self.frame_dt))))   # full sweep <= ~70 ms
            if el > 0.6 * budget and self.bands < max_bands:
                self.bands += 1
            elif (el < 0.25 * budget and self.bands > 1) or self.bands > max_bands:
                self.bands -= 1
            for bar in coarse:
                xs = np.array([bar["x0"], 0.5 * (bar["x0"] + bar["x1"]), bar["x1"]])
                ys = np.polyval(bar["coef"], xs)
                hh = (bar["half"] + 2) * step
                raw.append((bx0 + bar["x0"] * step, y0 + ys.min() * step - hh,
                            (bar["x1"] - bar["x0"]) * step + 1, (ys.max() - ys.min()) * step + 2 * hh))
        seeds = []
        native = self.seeder is not None and self.seeder.ok
        if native:
            # Native boxes: dozens on a busy court, the meter often only in
            # pieces (court lines and the gold line split it). Rank by the
            # outline-dark-outline 'sandwich' test, within a time limit.
            sc = self.scale
            maxh = (2 * cfg["bar_max_height"] + 24) / sc
            maxw = (cfg["bar_max_width"] + 40) / sc
            cand = []
            for b in raw:
                bx, by, bw, bh = b
                if bh < 3 or bw < 1.5 * bh or bh > maxh or bw > maxw:
                    continue
                if self._in_hud(bx + 0.5 * bw, by + 0.5 * bh):
                    continue
                pri = 0.0
                if self.last_bar is not None:      # near where the meter just was first
                    px, py, pw = self.last_bar
                    pri = abs(bx + 0.5 * bw - px) + abs(by + 0.5 * bh - py)
                cand.append((pri, b))
            cand.sort(key=lambda t: t[0])
            rot = self.seed_rot if (self.last_bar is None and self.seed_rot < len(cand)) else 0
            cand = cand[rot:] + cand[:rot]
            t_sc = time.perf_counter()
            lim = 0.35 * self._budget_ms()
            scored = []
            for k, (_, (bx, by, bw, bh)) in enumerate(cand):
                if k >= 6 and (time.perf_counter() - t_sc) * 1000.0 > lim:
                    # out of time: carry on from here next frame
                    self.seed_rot = (rot + k) % max(1, len(cand))
                    break
                sw = sandwich_score(frame, bx, by, bw, bh, cfg, sc)
                if sw >= 0.5:
                    scored.append((sw, (bx, by, bw, bh)))
            else:
                self.seed_rot = 0
            raw_ranked = [(sw + quick_prescore(frame, *b, cfg) * 0.25, b)
                          for sw, b in sorted(scored, key=lambda t: -t[0])[:12]]
        else:
            raw_ranked = []
            for b in raw[:12]:
                if self._in_hud(b[0] + 0.5 * b[2], b[1] + 0.5 * b[3]):
                    continue
                pre = quick_prescore(frame, *b, cfg)
                if pre > 0:
                    raw_ranked.append((pre, b))
        for pre, (bx, by, bw, bh) in raw_ranked:
            # a seed may be only a piece of the bar: look well around it
            padx = max(1.0 * bw, (110.0 if native else 60.0) / self.scale)
            pady = max(1.5 * bh, 16.0 / self.scale)
            win = (int(max(0, bx - padx)), int(max(0, by - pady)),
                   int(min(W, bx + bw + padx)), int(min(H, by + bh + pady)))
            seeds.append((pre, win))
        seeds.sort(key=lambda t: -t[0])
        kept = []                                  # drop windows mostly inside a better one
        for pre, w in seeds:
            cx, cy = 0.5 * (w[0] + w[2]), 0.5 * (w[1] + w[3])
            if any(k[0] <= cx <= k[2] and k[1] <= cy <= k[3] for _, k in kept):
                continue
            kept.append((pre, w))
        return kept

    def _forget_meter(self):
        """Drop everything learned about this shot's meter (after a jump)."""
        keep_roi, keep_bar = self.track_roi, self.last_bar
        held = self.state
        self._reset_shot()
        self.state = held
        self.track_roi, self.last_bar = keep_roi, keep_bar

    def _in_hud(self, x, y):
        fr = (self.width - x) / float(self.height)       # distance from right edge, in heights
        fy = y / float(self.height)
        return any(rr <= fr <= rl and t <= fy <= b for rl, t, rr, b in self.cfg["hud_exclude"])

    def _excluded(self, x0, y0, x1, y1):
        cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
        return any(ex0 <= cx <= ex1 and ey0 <= cy <= ey1 for ex0, ey0, ex1, ey1 in self.excluded)

    def _excluded(self, x0, y0, x1, y1):
        cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
        return any(ex0 <= cx <= ex1 and ey0 <= cy <= ey1 for ex0, ey0, ex1, ey1 in self.excluded)

    # ----- measurement ------------------------------------------------------
    def _target_x(self, a):
        """Target x, checked against where it has been on the bar this shot.

        The target never moves along the bar. On busy courts (light wood
        showing through the semi-transparent bar) a patch of floor can look
        like the zone for a frame or two and make the target jump; once the
        target's place on the bar is known, a reading that jumps away from it
        is replaced by that steady place (or skipped if the bar itself looks
        wrong this frame)."""
        tx = self._target_x_raw(a)
        left, right = float(a["left"]), float(a["right"])
        hist = self.tx_rel
        u = self.bar_h or 10.0
        tol = max(4.0, 0.6 * u)
        if len(hist) >= 4:
            rl = float(np.median([h[0] for h in hist[-8:]]))     # target - bar left
            rr = float(np.median([h[1] for h in hist[-8:]]))     # bar right - target
            from_l, from_r = left + rl, right - rr
            ends_ok = abs(from_l - from_r) <= tol                # bar width as usual
            if tx is not None and abs(tx - from_l) > tol and abs(tx - from_r) > tol:
                self.tx_rejects += 1
                if self.tx_rejects >= 12:          # consistently somewhere else: we were wrong
                    hist.clear()
                    self.tx_rejects = 0
                    hist.append((tx - left, right - tx))
                    return tx
            if tx is None or (abs(tx - from_l) > tol and abs(tx - from_r) > tol):
                if ends_ok:
                    tx = 0.5 * (from_l + from_r)
                else:
                    return None
                return tx
        if tx is not None:
            self.tx_rejects = 0
            hist.append((tx - left, right - tx))
            del hist[:-16]
        return tx

    def _target_x_raw(self, a):
        """Target x in this frame. Primary anchor: the zone's right edge (the
        edge the line reaches last). Backups when the line is sitting on that
        edge: the zone's left edge (with the learned zone width) or the bar's
        right end cap. None if nothing trustworthy is visible."""
        self.bar_hs.append(2.0 * a["half"])
        bar_h = float(np.median(self.bar_hs[-10:]))
        self.bar_h = bar_h
        lines = [x for x, _ in a["lines"]]
        edge_r = max(2.0, 0.6 * bar_h)        # glow distance that corrupts an edge
        glow = max(3.0, 1.5 * bar_h)
        zone = a["zone"]
        if zone is not None:
            zl, zr, zs = zone
            zw = zr - zl
            clean = not any(zl - glow <= x <= zr + glow for x in lines)
            plausible = zw >= max(3.0, 0.9 * bar_h)

            # Meter appeared with the line already over the zone: no clean
            # frame will come, so use the zone shape learned on earlier shots.
            if self.off_r is None and any(zl - glow <= x < zr - edge_r for x in lines):
                ratio = float(np.median(self.off_ratio_hist)) if self.off_ratio_hist else 0.85
                wratio = float(np.median(self.zw_ratio_hist)) if self.zw_ratio_hist else 1.7
                self.zone_w0 = wratio * bar_h
                self.off_r = ratio * bar_h
                self.target_frozen = True

            # (re)learn geometry from clean frames until the line gets close
            if clean and plausible and not self.target_frozen:
                mode = self.cfg["target_mode"]
                if mode == "slit" and zs is not None:
                    t = zs
                elif mode == "start":
                    t = zl
                else:
                    t = zl + float(self.cfg.get("zone_point", 0.5)) * zw
                self.lock_hist.append((zw, zr - t))
                if not any(abs(x - a["dleft"]) <= 1.5 * bar_h for x in lines) and a["dleft"] < zl:
                    self.left_gaps.append(t - a["dleft"])
                hist = self.lock_hist[-6:]
                med = float(np.median([h[0] for h in hist]))
                good = [h for h in hist if abs(h[0] - med) <= max(2.0, 0.15 * med)]
                if len(good) >= 2 or (len(good) == 1 and len(self.lock_hist) == 1):
                    self.zone_w0 = float(np.median([h[0] for h in good]))
                    self.off_r = float(np.median([h[1] for h in good]))
                    self.geom_learned = len(good) >= 2
        if self.off_r is None:
            return None
        trim = self.cfg["target_offset"] * bar_h * 9.0   # % of bar; bar ~9 thicknesses long

        def clear_of(x0):
            return not any(abs(x - x0) <= edge_r for x in lines)

        if zone is not None:
            zl, zr, _ = zone
            zw = zr - zl
            size_ok = abs(zw - self.zone_w0) <= max(2.0, 0.25 * self.zone_w0)
            # 1) right edge: fine if the line isn't on it (left edge may be hidden)
            if clear_of(zr) and (size_ok or any(zl - glow <= x <= zr for x in lines)):
                return zr - self.off_r + trim
            # 2) left edge + learned width, while the line sits on the right edge
            if clear_of(zl) and not any(x < zl for x in lines if abs(x - zl) <= glow) \
                    and any(x > zl + edge_r for x in lines):
                return zl + self.zone_w0 - self.off_r + trim
        # 3) left end of the charcoal interior, once its distance to the
        #    target is known consistently (late in the shot the line is far
        #    from it, so it stays crisp)
        if len(self.left_gaps) >= 2 and clear_of(a["dleft"]) and \
                not any(abs(x - a["dleft"]) <= 1.5 * bar_h for x in lines):
            gaps = np.array(self.left_gaps[-6:])
            gmed = float(np.median(gaps))
            if float(np.median(np.abs(gaps - gmed))) <= max(1.0, 0.1 * bar_h):
                return a["dleft"] + gmed + trim
        return None

    def _candidates(self, a, tx):
        """Distances (px) from every line candidate to the target."""
        u = self.bar_h or 10.0
        return [tx - x for x, _ in a["lines"] if tx - x > -1.4 * u]

    def _fit(self):
        """Multi-hypothesis robust fit. Each frame may hold several line
        candidates (the real line, glints on the end caps, light on the ball);
        find the set that forms one steady approach to the target.
        Returns (t_last, distance at t_last, closing speed px/ms) or None."""
        n_min = int(self.cfg["min_samples"])
        frames = self.cand_frames[-max(int(self.cfg["speed_samples"]), n_min):]
        frames = [f for f in frames if f[1]]
        if len(frames) < n_min or frames[-1][0] != self.cand_frames[-1][0]:
            return None   # newest frame must contain a candidate
        t_last = frames[-1][0]
        ts = np.array([f[0] for f in frames]) - t_last
        if -ts[0] < 12.0:
            return None
        u = self.bar_h or 10.0
        tol = max(1.5, 0.15 * u)
        lo, hi = 0.004 * u, 0.1 * u          # plausible closing speeds (px/ms)
        n = len(frames)
        best = None
        # Stick with the line we've been following: once a steady fit exists,
        # a hypothesis that continues it beats one with more matches that is
        # something else (a glint or end cap moving at a different speed).
        prev = self.fit if (self.fit is not None and self.fit_streak >= 6
                            and t_last - self.fit[0] <= 80.0) else None
        if prev is not None:
            prev_d = prev[1] - prev[2] * (t_last - prev[0])
        for i in range(n):
            for j in range(i + 1, n):
                dt = ts[j] - ts[i]
                if dt <= 0:
                    continue
                for di in frames[i][1]:
                    for dj in frames[j][1]:
                        sp = (di - dj) / dt
                        if not (lo <= sp <= hi):
                            continue
                        pred = di - sp * (ts - ts[i])
                        hits = 0
                        for k in range(n):
                            if min(abs(c - pred[k]) for c in frames[k][1]) <= tol:
                                hits += 1
                        last_ok = min(abs(c - pred[-1]) for c in frames[-1][1]) <= tol
                        cont = 1 if (prev is None or (abs(pred[-1] - prev_d) <= max(3.0, 2.0 * tol)
                                                      and 0.6 * prev[2] <= sp <= 1.6 * prev[2])) else 0
                        key = (cont, hits, last_ok, j)
                        if best is None or key > best[0]:
                            best = (key, pred)
        if best is None or best[0][1] < n_min or not best[0][2]:
            return None
        if prev is not None and not best[0][0]:
            return None          # nothing continues the line we're following: coast on it
        pred = best[1]
        pt, pd = [], []
        for k in range(n):
            c = min(frames[k][1], key=lambda c: abs(c - pred[k]))
            if abs(c - pred[k]) <= tol:
                pt.append(ts[k])
                pd.append(c)
        slope, d0 = np.polyfit(np.array(pt), np.array(pd), 1)
        sp = -float(slope)
        if not (lo <= sp <= hi):
            return None
        sp, d0 = self._refine_long(frames, pt, sp, float(d0), t_last, tol, lo, hi)
        self.samples.append((t_last, float(pd[-1])))
        return float(t_last), float(d0), sp

    def _refine_long(self, frames, pt, sp, d0, t_last, tol, lo, hi):
        """The line moves at a steady speed, so fitting a longer stretch of its
        path gives a much steadier speed and position than the last few
        frames alone (at 240 fps those span only ~50 ms). Starts from the
        robust short fit and keeps only readings that agree with it."""
        win = float(self.cfg.get("fit_window_ms", 0))
        if win <= pt[-1] - pt[0] + 1.0:
            return sp, d0
        longf = [f for f in self.cand_frames[-160:] if f[1] and t_last - f[0] <= win]
        if len(longf) <= len(pt):
            return sp, d0
        lt = [f[0] - t_last for f in longf]
        l_sp, l_d0 = sp, d0
        for _ in range(2):
            qt, qd = [], []
            for f, tt in zip(longf, lt):
                p_ = l_d0 - l_sp * tt
                c = min(f[1], key=lambda c: abs(c - p_))
                if abs(c - p_) <= tol:
                    qt.append(tt)
                    qd.append(c)
            if len(qt) < len(pt) or (qt[-1] - qt[0]) < (pt[-1] - pt[0]):
                break
            s2, d2 = np.polyfit(np.array(qt), np.array(qd), 1)
            if not (lo <= -s2 <= hi) or abs(-s2 - sp) > 0.3 * sp:
                break
            l_sp, l_d0 = -float(s2), float(d2)
        # the newest reading must still agree with the long fit
        if abs(min(frames[-1][1], key=lambda c: abs(c - l_d0)) - l_d0) > tol:
            return sp, d0
        return l_sp, l_d0

    def _prior_fit(self):
        """Meter appeared late: two frames whose candidates agree with the
        speed learned on earlier shots are enough."""
        if not self.speed_history or self.bar_h is None:
            return None
        frames = [f for f in self.cand_frames if f[1]]
        if len(frames) < 2 or frames[-1][0] != self.cand_frames[-1][0]:
            return None
        prior = float(np.median(self.speed_history)) * self.bar_h
        (t1, c1), (t2, c2) = frames[-2:]
        if t2 - t1 < 4.0:
            return None
        best = None
        for d1 in c1:
            for d2 in c2:
                obs = (d1 - d2) / (t2 - t1)
                if 0.6 * prior <= obs <= 1.6 * prior:
                    err = abs(obs - prior)
                    if best is None or err < best[0]:
                        best = (err, d2)
        if best is None:
            return None
        return t2, best[1], prior

    def _frame_ms(self):
        pts = self.cand_frames[-8:]
        if len(pts) < 2:
            return 8.0
        return float(np.median(np.diff([p[0] for p in pts])))

    def _feed_native(self, a, tx):
        """Give Helios's meter this frame's line and target (the candidate
        that agrees with the fit), as 2K Vision does."""
        want = self.cfg["use_native_meter"] or (self.cfg["meter_overlay"] and self.cfg["debug_overlay"])
        if not want or not self.native.ok or not self.cand_frames:
            return
        t0, d0, sp = self.fit
        cands = self.cand_frames[-1][1]
        if not cands:
            return
        d = min(cands, key=lambda c: abs(c - d0))
        if abs(d - d0) > max(2.0, 0.25 * (self.bar_h or 10.0)):
            return
        cy = a["cy"]
        h = max(4.0, 2.0 * a["half"])
        box = (a["left"], cy - h, a["right"] - a["left"], 2.0 * h)
        self.native.update(self.t_cap, (tx - d, cy), (tx, cy), box, self.width, self.height)

    def _check_release(self):
        fit = self.fit if self.fit is not None else self._prior_fit()
        if fit is None:
            return
        t0, d0, sp = fit
        now = self.t_now
        if now - t0 > 120:
            return  # lost the meter; leave the user's input alone
        d_now = d0 - sp * (now - t0)
        eta = d_now / sp
        self.eta_source = "own"
        nat = self.native
        if self.cfg["blend_native_eta"] and self.cfg["use_native_meter"] and \
                nat.eta is not None and nat.t == t0 and nat.eta > 0:
            eta_nat = nat.eta - (now - nat.t)          # its ETA is from capture time
            if abs(eta_nat - eta) <= max(20.0, 0.25 * eta):
                eta = 0.5 * (eta + eta_nat)            # both agree: average them
                self.eta_source = "both"
        self.eta = eta
        if self.eta <= self.cfg["lead_ms"] + 0.5 * self._frame_ms():
            self.state = RELEASED
            self.release_t = now
            self.release_speed = sp
            self.release_used_prior = self.fit is None
            if self.cfg["use_2k_verdict"]:
                self.watch = {"t": now, "pre": self._verdict_now(), "gone": False,
                              "seen": None, "count": 0, "lead": self.cfg["lead_ms"]}
            self.release_fit = fit
            self.release_cap = self.t_cap
            self.release_zw = self.bar_h
            self.release_bar = self.last_bar
            self.after = []
            if self.fit is not None and self.bar_h:
                self.speed_history = (self.speed_history + [sp / self.bar_h])[-8:]
            if self.geom_learned and self.bar_h:
                self.off_ratio_hist = (self.off_ratio_hist + [self.off_r / self.bar_h])[-8:]
                self.zw_ratio_hist = (self.zw_ratio_hist + [self.zone_w0 / self.bar_h])[-8:]

    # ----- main -------------------------------------------------------------
    def process(self, frame):
        self.frame_no += 1
        self._poll_settings()
        self._handle_toggle()
        self.t_cap, self.t_now = self.clock.stamp()
        self._watch_verdict(frame)
        force_release = False

        if not self.enabled:
            self._reset_shot()
            self._send(False)
            self._draw_status()
            return None

        if self.state == IDLE and self._trigger_held():
            self._reset_shot()
            self.state = TRACKING

        if self.last_tcap is not None and self.t_cap > self.last_tcap:
            self.frame_dt = 0.9 * self.frame_dt + 0.1 * min(50.0, self.t_cap - self.last_tcap)
        self.last_tcap = self.t_cap

        if self.state == TRACKING:
            if not self._trigger_held():
                self._reset_shot()          # player released first
            elif (self.track_roi is not None and self.frame_dt < 6.7 and self.frame_no % 2 == 1
                  and (self.eta is None or self.eta > self.cfg["skip_far_ms"])):
                # high frame rate and the line is still far away: skip this
                # frame's analysis (timing uses capture timestamps, so fewer
                # samples are fine); release check still runs every frame
                self._draw_meter()
                self._check_release()
            else:
                prev_bar = self.last_bar
                a = self._detect(frame)
                if a is not None and prev_bar is not None and self.last_bar is not None:
                    px, py, pw = prev_bar
                    nx, ny, nw = self.last_bar
                    if abs(nx - px) > 2.0 * max(pw, nw) or abs(ny - py) > max(3.0 * pw, 0.15 * self.height):
                        self._forget_meter()       # locked onto something else: start over
                if a is None:
                    self.stale += 1
                if a is not None:
                    tx = self._target_x(a)
                    lx = None
                    useful = tx is not None and self._candidates(a, tx)
                    self.stale = 0 if useful else self.stale + 1
                    # Something bar-shaped but never readable (backboard edge,
                    # banner, floor decal): after 120 ms of that, blacklist it
                    # for this shot and search again.
                    if useful or self.stale_since is None:
                        self.stale_since = None if useful else self.t_cap
                    elif self.t_cap - self.stale_since > 120.0 and self.fit is None and \
                            self.last_bar is not None and \
                            not any(f[1] for f in self.cand_frames[-12:]):
                        bx_, by_, bw_ = self.last_bar
                        bad = (bx_ - 0.6 * bw_, by_ - 30.0 / self.scale,
                               bx_ + 0.6 * bw_, by_ + 30.0 / self.scale)
                        keep = self.excluded + [bad]
                        self._forget_meter()
                        self.excluded = keep
                        self.track_roi = None
                        self.last_bar = None
                    if tx is not None:
                        self.cand_frames.append((self.t_cap, self._candidates(a, tx)))
                        fit = self._fit()
                        if fit is not None:
                            self.fit = fit
                            self.fit_streak += 1
                            lx = tx - fit[1]
                            self._feed_native(a, tx)
                            if self.bar_h and fit[1] <= 2.5 * self.bar_h:
                                self.target_frozen = True
                        elif self.fit is not None and \
                                self.t_cap - self.fit[0] > (120 if self.fit_streak >= 6 else 60):
                            self.fit = None
                            self.fit_streak = 0
                    self.last_seen = (a, tx, lx)
                self._draw_meter()
                self._check_release()

        if self.state == RELEASED:
            force_release = True
            self._observe_after(frame)
            if self._trigger_let_go():
                # stop overriding at once, but keep watching where the line
                # stops (for the report / auto-calibration)
                self.state = OBSERVE
                force_release = False

        if self.state == OBSERVE:
            if self.t_now - self.release_t < 450.0 and not self._trigger_held():
                self._observe_after(frame)
            else:
                self._finish_shot()
                held = self._trigger_held()
                self._reset_shot()
                if held:                       # next shot already started
                    self.state = TRACKING

        self._send(force_release)
        self._draw_status()
        return None

    def _observe_after(self, frame):
        """After release the line keeps moving along its fitted path until the
        game applies the release, then stops. Record where it is (lightly:
        tracking window only, every third frame at high frame rates)."""
        if self.t_now - self.release_t >= 700:
            return
        if self.frame_dt < 6.7 and self.frame_no % 3:
            return
        rb = self.release_bar
        if self.track_roi is None:
            # The camera pans and the meter jumps up with the shot, so the
            # tracking window loses it. Look again around where it last was,
            # mostly above (the meter rises).
            if rb is None:
                return
            bx, by, bw = rb
            self.track_roi = (int(bx - 1.6 * bw), int(by - 0.22 * self.height),
                              int(bx + 1.6 * bw), int(by + 0.08 * self.height))
            self.track_miss = 0
        a = self._detect_once(frame)
        if a is None or self.off_r is None or self.release_fit is None:
            return
        if rb is not None:
            aw = a["right"] - a["left"]
            if not (0.6 * rb[2] <= aw <= 1.6 * rb[2]):
                return                       # something else, not our meter
            self.release_bar = (0.5 * (a["left"] + a["right"]), a["cy"], rb[2])   # follow the pan
        tx = self._target_x(a)
        if tx is not None:
            # it must lie between "where it was at release" and "where the
            # fit says it would be now"
            t0, d0, sp = self.release_fit
            u = self.bar_h or 10.0
            tol = max(2.0, 0.25 * u)
            d_rel = d0 - sp * (self.release_cap - t0)
            d_fit = d0 - sp * (self.t_cap - t0)
            ok = [tx - x for x, _ in a["lines"] if d_fit - tol <= tx - x <= d_rel + tol]
            if ok:
                ref = self.after[-1][1] if self.after else d_fit
                d = min(ok, key=lambda c: abs(c - ref))
                self.after.append((self.t_cap, d))
                self.last_seen = (a, tx, tx - d)
        self._draw_meter()

    # ----- 2K verdict ---------------------------------------------------------
    def _verdict_now(self):
        if self._frame is None:
            return None
        try:
            return VerdictReader.read(self._frame, self.cfg["verdict_area"], self.cfg["verdict_word_x"])
        except Exception:
            return None

    def _watch_verdict(self, frame):
        """After a script release, wait for 2K's TIMING box to (re)appear and
        settle, read it, and correct the lead."""
        self._frame = frame
        w = self.watch
        if w is None or (self.frame_no % 2):
            return
        dt = self.t_now - w["t"]
        if dt > 6000:                          # 2K shows it when the ball reaches the rim
            # no verdict seen (HUD hidden / moved): fall back to where the
            # line stopped
            fb = w.get("fallback_err")
            if fb is not None:
                self.last_result += self._tune_from_error(fb) + "  (no 2K verdict seen)"
            self.watch = None
            return
        v = self._verdict_now()
        if v is None:
            w["gone"] = True
            w["seen"], w["count"] = None, 0
            return
        if w["pre"] is not None and v == w["pre"] and not w["gone"]:
            return                             # still the previous shot's box
        if dt < 150:
            return
        if v == w["seen"]:
            w["count"] += 1
        else:
            w["seen"], w["count"], w["since"] = v, 1, self.t_now
        # the box slides in for ~130 ms and can misread meanwhile: only trust
        # a reading that has stayed the same for 300 ms
        if w["count"] >= 3 and self.t_now - w["since"] >= 300:
            self._apply_verdict(v, w["lead"])
            self.watch = None

    def _apply_verdict(self, v, lead_at_release):
        name, grade = v
        msg = "2K says: %s" % name
        if grade != 0:
            size = self.cfg["verdict_step_very"] if abs(grade) == 2 else self.cfg["verdict_step_slight"]
            sign = 1 if grade > 0 else -1                       # late -> more lead
            # Smaller steps once verdicts flip between early and late (the
            # lead is near the middle of the window); back to full size while
            # they keep coming from the same side.
            if self.v_last_sign is not None:
                if sign != self.v_last_sign:
                    self.v_scale = max(0.4, self.v_scale * 0.6)
                else:
                    self.v_scale = min(1.0, self.v_scale * 1.4)
            # VERY EARLY/LATE in a row (e.g. after switching from offline to
            # online Ante-Up, where server delay needs 100+ ms more lead):
            # double the step each time so the lead catches up in a few shots.
            if abs(grade) == 2:
                self.v_very_mult = min(4.0, self.v_very_mult * 2.0) \
                    if (self.v_last_very == sign) else 1.0
                self.v_last_very = sign
                self.v_scale = 1.0
            else:
                self.v_last_very = None
                self.v_very_mult = 1.0
            self.v_last_sign = sign
            mult = self.v_scale if abs(grade) == 1 else self.v_very_mult
            step = self.cfg["verdict_gain"] * size * sign * mult
            new_lead = int(round(max(0.0, min(400.0, lead_at_release + step))))
            if new_lead != self.cfg["lead_ms"]:
                self.cfg["lead_ms"] = new_lead
                self._save_lead(new_lead)
                msg += "  -> lead %d ms (auto)" % new_lead
        self.verdict_msg = msg
        if self.cfg.get("log_shots") and self.settings_path is not None:
            try:
                rec = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "verdict": name,
                       "lead_at_release": lead_at_release, "lead_now": self.cfg["lead_ms"]}
                with open(self.settings_path.parent / "shots_log.txt", "a", encoding="utf-8") as f:
                    f.write(json.dumps(rec) + "\n")
            except Exception:
                pass

    # ----- calibration ------------------------------------------------------
    def _tune_from_error(self, err_ms):
        """Line-stop calibration: median of recent errors, max 10 ms a step."""
        if not self.cfg["auto_calibrate"]:
            return ""
        self.err_history = (self.err_history + [err_ms])[-3:]
        basis = float(np.median(self.err_history))
        step = max(-10.0, min(10.0, self.cfg["auto_gain"] * basis))
        new_lead = int(round(max(0.0, min(200.0, self.cfg["lead_ms"] + step))))
        if new_lead == self.cfg["lead_ms"]:
            return ""
        change = new_lead - self.cfg["lead_ms"]
        self.err_history = [e - change for e in self.err_history]   # taken with the old lead
        self.cfg["lead_ms"] = new_lead
        self._save_lead(new_lead)
        return "  -> lead %d ms (auto)" % new_lead

    def _finish_shot(self):
        self.last_err = None
        self._finish_shot_inner()
        self._log_shot()

    def _finish_shot_inner(self):
        """Where did the line actually stop? Use it to report and auto-tune."""
        if self.release_t is None or not self.release_speed:
            return
        u = self.release_zw or 10.0
        pts = [p for p in self.after if p[0] - self.release_t >= 30.0]
        # The line is frozen by now, so every reading is the same stop seen
        # through ~1-2 px of noise (the meter moves and rescales as the camera
        # pans). Take the median, drop readings far from it, and keep the
        # answer if enough agree.
        stop = None
        if len(pts) >= 3:
            ds = np.array([p[1] for p in pts])
            med = float(np.median(ds))
            keep = ds[np.abs(ds - med) <= max(2.0, 0.3 * u)]
            if keep.size >= 3 and keep.size >= 0.5 * ds.size:
                stop = float(np.median(keep))
        if stop is None:
            self.last_result = "Last shot: released (couldn't see where it stopped)"
            return
        err_ms = -stop / self.release_speed      # + = late, - = early
        self.last_err = err_ms
        word = "LATE" if err_ms > 0 else "EARLY"
        msg = "Last shot: %.0f ms %s" % (abs(err_ms), word)
        if abs(err_ms) > 60:
            # a real error this big is unlikely once tuned; more likely the
            # stop was misread (flash, occlusion) - don't let it move the lead
            msg += "  (not used for tuning)"
        elif self.cfg["use_2k_verdict"] and self.watch is not None:
            # 2K's verdict, read a moment later, does the tuning; this
            # measurement is the fallback if no verdict can be read
            self.watch["fallback_err"] = err_ms
        else:
            msg += self._tune_from_error(err_ms)
        self.last_result = msg

    def _log_shot(self):
        if not self.cfg.get("log_shots") or self.settings_path is None or self.release_t is None:
            return
        try:
            rec = {
                "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                "lead_ms": self.cfg["lead_ms"],
                "error_ms": None if self.last_err is None else round(self.last_err, 1),
                "speed_px_ms": round(self.release_speed or 0.0, 4),
                "bar_h": None if self.bar_h is None else round(self.bar_h, 1),
                "zone_w": None if self.zone_w0 is None else round(self.zone_w0, 1),
                "readings": len(self.cand_frames),
                "after": len(self.after),
                "prior_used": self.release_used_prior,
                "clock": "capture" if self.clock.ok else "process",
                "result": self.last_result,
            }
            with open(self.settings_path.parent / "shots_log.txt", "a", encoding="utf-8") as f:
                f.write(json.dumps(rec) + "\n")
        except Exception:
            pass

    def _save_lead(self, lead):
        if self.settings_path is None:
            return
        try:
            with open(self.settings_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            data["lead_ms"] = int(lead)
            tmp = self.settings_path.with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            tmp.replace(self.settings_path)
            self.settings_mtime = self.settings_path.stat().st_mtime
        except Exception as exc:
            print("NBA2K21_Meter: could not save lead:", exc)

    # ----- drawing ----------------------------------------------------------
    def _draw_meter(self):
        """Marks are drawn just above/below the bar, never on top of it, so
        recordings of the Helios view still show the real meter."""
        if not self.cfg["debug_overlay"] or self.last_seen is None:
            return
        a, tx, lx = self.last_seen
        cy, h = a["cy"], max(4.0, 2 * a["half"])
        top, bot = int(cy - h), int(cy + h)
        if a["zone"] is not None:
            zl, zr, _ = a["zone"]
            overlay.line(int(zl), bot + 6, int(zr), bot + 6, color=(104, 244, 255), thickness=1)
        if tx is not None:
            overlay.line(int(tx), top - 10, int(tx), top - 3, color=(0, 255, 0), thickness=2)
        if lx is not None:
            overlay.line(int(lx), bot + 3, int(lx), bot + 11, color=(255, 0, 255), thickness=2)

    def _draw_status(self):
        if not self.cfg["debug_overlay"]:
            return
        status = "2K21 Meter v4.4: %s  lead %d ms" % ("ON" if self.enabled else "OFF", self.cfg["lead_ms"])
        if self.cfg["auto_calibrate"] or self.cfg["use_2k_verdict"]:
            status += " (auto)"
        if not self.clock.ok:
            status += "  [no capture clock]"
        if self.state == TRACKING:
            status += "  | zone %s  line %d  fit %s" % (
                "Y" if self.off_r is not None else "-", len(self.cand_frames),
                "Y" if self.fit else "-")
        if _now_ms() < self.settings_note_until:
            status += "  (settings updated)"
        if self.cfg.get("show_search_box", True) and self.enabled:
            fa = self.cfg["search_area"]
            x0, y0 = int(fa[0] * self.width), int(fa[1] * self.height)
            x1, y1 = int(fa[2] * self.width), int(fa[3] * self.height)
            if self.state == TRACKING:
                # lit while the shoot button is held: green once the meter is locked
                col = (0, 255, 120) if self.fit else ((0, 200, 255) if self.track_roi is not None else (255, 200, 0))
                overlay.rect(x0, y0, x1, y1, color=col, thickness=3)
            else:
                overlay.rect(x0, y0, x1, y1, color=(90, 90, 90), thickness=1)
        overlay.text(status, 20, 20, color=(255, 255, 255), scale=2,
                     space=overlay.DESIGN_1080P)
        if self.last_result:
            overlay.text(self.last_result, 20, 60, color=(255, 255, 0), scale=2,
                         space=overlay.DESIGN_1080P)
        if self.verdict_msg:
            overlay.text(self.verdict_msg, 20, 100, color=(120, 255, 120), scale=2,
                         space=overlay.DESIGN_1080P)
