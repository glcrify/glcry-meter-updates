"""Controller input and the two outputs (virtual controller, Titan Two).

Values use the Helios / Titan Two identifiers (see compat/helios/controls.py).
The CV packet is the Helios 'Creative' layout scripts already write:
  byte 11+i  button i:  low bit set = override, value = byte & 0xFE (0..100)
  byte 28+k  stick k (0 right X, 1 right Y, 2 left X, 3 left Y):
             low bit set = override, value = (byte & 0xFE) - 100
  byte 32+4k same stick as big-endian 16.16 fixed point (finer)
Byte 1 (GLCRY METER): bit0 = Titan Two holds an override-to-0 until the button is
physically let go (needed because in Titan mode the PC reads the Titan's output).
"""

import ctypes
import socket
import struct
import sys
import threading
import time

BUTTON_OFFSET = 11
LEGACY_STICK_OFFSET = 28
PRECISION_STICK_OFFSET = 32
PACKET_SIZE = 48
N_BUTTONS = 21
STICK_IDS = (21, 22, 23, 24)          # STICK_1_X, STICK_1_Y, STICK_2_X, STICK_2_Y
FLAG_LATCH = 0x01

BUTTON_NAMES = ["Guide", "View", "Menu", "RB", "RT", "RS", "LB", "LT", "LS",
                "Up", "Down", "Left", "Right", "Y", "B", "A", "X", "B18", "B19", "B20", "B21"]


def decode_packet(pkt):
    """-> (button overrides {id: 0..100}, stick overrides {id: -100..100})."""
    b_ov, s_ov = {}, {}
    if not pkt or len(pkt) < PACKET_SIZE:
        return b_ov, s_ov
    for i in range(N_BUTTONS):
        v = pkt[BUTTON_OFFSET + i]
        if v & 1:
            b_ov[i] = float(min(100, v & 0xFE))
    for k in range(4):
        v = pkt[LEGACY_STICK_OFFSET + k]
        if v & 1:
            fine = struct.unpack_from(">i", pkt, PRECISION_STICK_OFFSET + 4 * k)[0] / 65536.0
            coarse = float((v & 0xFE) - 100)
            s_ov[STICK_IDS[k]] = fine if abs(fine - coarse) <= 2.0 else coarse
    return b_ov, s_ov


# ----------------------------------------------------------------------------
# XInput (Xbox-style controllers, and the Titan Two's output as Windows sees it)
# ----------------------------------------------------------------------------
class _GAMEPAD(ctypes.Structure):
    _fields_ = [("wButtons", ctypes.c_ushort), ("bLeftTrigger", ctypes.c_ubyte),
                ("bRightTrigger", ctypes.c_ubyte), ("sThumbLX", ctypes.c_short),
                ("sThumbLY", ctypes.c_short), ("sThumbRX", ctypes.c_short),
                ("sThumbRY", ctypes.c_short)]


class _STATE(ctypes.Structure):
    # XInputGetStateEx (ordinal 100) can write a 4-byte reserved field after
    # the gamepad block; the padding keeps that from overwriting memory.
    _fields_ = [("dwPacketNumber", ctypes.c_uint), ("Gamepad", _GAMEPAD), ("_reserved", ctypes.c_uint * 4)]


# XInput bit -> Titan button id
_XI_BITS = [(0x0400, 0), (0x0020, 1), (0x0010, 2), (0x0200, 3), (0x0080, 5), (0x0100, 6),
            (0x0040, 8), (0x0001, 9), (0x0002, 10), (0x0004, 11), (0x0008, 12),
            (0x8000, 13), (0x2000, 14), (0x1000, 15), (0x4000, 16)]


class XInputReader:
    def __init__(self, slot=0):
        self.slot = int(slot)
        self.ok = False
        self.connected = False
        self.values = [0.0] * 40
        self._get = None
        if sys.platform != "win32":
            return
        for dll in ("xinput1_4", "xinput1_3", "xinput9_1_0"):
            try:
                lib = ctypes.WinDLL(dll)
            except OSError:
                continue
            fn = None
            try:
                fn = lib[100]            # XInputGetStateEx: includes the Guide button
            except Exception:
                fn = None
            if fn is None:
                fn = lib.XInputGetState
            fn.argtypes = [ctypes.c_uint, ctypes.POINTER(_STATE)]
            fn.restype = ctypes.c_uint
            self._get = fn
            self.ok = True
            break
        self._st = _STATE()

    def poll(self):
        if not self.ok:
            self.connected = False
            return self.values
        r = self._get(self.slot, ctypes.byref(self._st))
        if r != 0:
            if self.connected:
                self.values = [0.0] * 40
            self.connected = False
            return self.values
        self.connected = True
        g = self._st.Gamepad
        v = [0.0] * 40
        for bit, idx in _XI_BITS:
            if g.wButtons & bit:
                v[idx] = 100.0
        v[4] = g.bRightTrigger * 100.0 / 255.0
        v[7] = g.bLeftTrigger * 100.0 / 255.0
        v[21] = max(-100.0, g.sThumbRX / 327.67)
        v[22] = max(-100.0, -g.sThumbRY / 327.67)       # Titan: +Y = down
        v[23] = max(-100.0, g.sThumbLX / 327.67)
        v[24] = max(-100.0, -g.sThumbLY / 327.67)
        self.values = v
        return v


def xinput_slots_status():
    """[(slot, connected)] for the 4 XInput slots."""
    out = []
    for s in range(4):
        r = XInputReader(s)
        r.poll()
        out.append((s, r.connected))
    return out


# ----------------------------------------------------------------------------
# Outputs
# ----------------------------------------------------------------------------
def pick_input_slot(current, exclude=None):
    """Keep the current slot if a controller is on it, else the first connected
    one (skipping our own virtual pad). None if nothing is connected."""
    st = dict(xinput_slots_status())
    if st.get(current) and current != exclude:
        return current
    for sl in range(4):
        if st.get(sl) and sl != exclude:
            return sl
    return None


class PreviewOutput:
    """No controller output: read a pad so scripts see input, send nothing."""

    name = "Preview only"
    virtual_slot = None

    def __init__(self, log, slot=0):
        self.log = log
        self.reader = XInputReader(slot)
        self.lock = threading.Lock()
        self.packet = bytes(PACKET_SIZE)
        self.status = "Preview: script runs, nothing is sent to the game"

    def get_actual(self, identifier):
        v = self.reader.poll()
        return v[identifier] if 0 <= identifier < len(v) else 0.0

    def send_cvdata(self, data):
        self.packet = data

    def output_values(self):
        v = list(self.reader.values)
        b, s = decode_packet(self.packet)
        for k, x in b.items():
            v[k] = x
        for k, x in s.items():
            v[k] = x
        return v

    def close(self):
        pass


class VirtualPadOutput(PreviewOutput):
    """Your real controller -> GLCRY METER -> a virtual Xbox 360 controller (ViGEm).

    Passthrough runs at ~1000 Hz on its own thread; script overrides are
    applied the moment the script sends them. Hide the real controller from
    the game with HidHide so it only sees the virtual one."""

    name = "Virtual controller"

    def __init__(self, log, slot=0):
        super().__init__(log, slot)
        self.pad = None
        self.vg = None
        self.virtual_slot = None
        before = {sl for sl, c in xinput_slots_status() if c}
        self.status = "Virtual controller: starting"
        try:
            import vgamepad as vg
            self.vg = vg
            self.pad = vg.VX360Gamepad()
            self.status = "Virtual controller: running (Xbox 360 pad via ViGEm)"
        except Exception as exc:
            self.status = "Virtual controller unavailable: %s (install ViGEmBus + 'pip install vgamepad')" % exc
            log.write(self.status)
        self._b_ov, self._s_ov = {}, {}
        self.running = self.pad is not None
        self.rate_hz = 0.0
        if self.running:
            self.thread = threading.Thread(target=self._loop, name="vpad", daemon=True)
            self.thread.start()
            threading.Thread(target=self._find_virtual_slot, args=(before,), daemon=True).start()

    def _find_virtual_slot(self, before):
        """The XInput slot that appeared with our virtual pad (never use it as input)."""
        for _ in range(20):
            time.sleep(0.1)
            new = [sl for sl, c in xinput_slots_status() if c and sl not in before]
            if new:
                self.virtual_slot = new[0]
                if self.reader.slot == self.virtual_slot:
                    others = [sl for sl in before]
                    if others:
                        self.reader.slot = others[0]
                return

    def send_cvdata(self, data):
        self.packet = data
        b, s = decode_packet(data)
        changed = (b != self._b_ov) or (s != self._s_ov)
        self._b_ov, self._s_ov = b, s
        if changed and self.running:
            self._push(self.reader.values)       # apply overrides immediately

    def _push(self, phys):
        with self.lock:
            v = list(phys)
            for k, x in self._b_ov.items():
                v[k] = x
            for k, x in self._s_ov.items():
                v[k] = x
            self._write(v)

    def _write(self, v):
        rep = self.pad.report
        bits = 0
        for bit, idx in _XI_BITS:
            if v[idx] >= 50.0:
                bits |= bit
        rep.wButtons = bits
        rep.bLeftTrigger = int(max(0, min(255, round(v[7] * 2.55))))
        rep.bRightTrigger = int(max(0, min(255, round(v[4] * 2.55))))

        def ax(x, invert=False):
            x = max(-100.0, min(100.0, -x if invert else x))
            return int(max(-32768, min(32767, round(x * 327.67))))
        rep.sThumbLX, rep.sThumbLY = ax(v[23]), ax(v[24], True)
        rep.sThumbRX, rep.sThumbRY = ax(v[21]), ax(v[22], True)
        self.pad.update()

    def _loop(self):
        n, t_win = 0, time.perf_counter()
        period = 0.001
        nxt = time.perf_counter()
        while self.running:
            phys = self.reader.poll()
            try:
                self._push(phys)
            except Exception as exc:
                self.log.write("Virtual controller error: %s" % exc)
                time.sleep(0.05)
            n += 1
            now = time.perf_counter()
            if now - t_win >= 1.0:
                self.rate_hz = n / (now - t_win)
                n, t_win = 0, now
            nxt += period
            d = nxt - time.perf_counter()
            if d > 0:
                time.sleep(d)
            else:
                nxt = time.perf_counter()

    def close(self):
        self.running = False
        try:
            if self.pad is not None:
                self.pad.reset()
                self.pad.update()
        except Exception:
            pass
        self.pad = None


class TitanOutput(PreviewOutput):
    """Sends the packet to GLCRY METER's Gtuner IV bridge (GLCRY_METER_GtunerBridge.py)
    over localhost UDP; the bridge hands it to the Titan Two each Gtuner
    frame and GLCRY_METER_Bridge.gpc applies it.

    Controller input is read from the Titan Two's output as Windows sees it
    (its XInput slot), so the Titan holds a forced release until you let go of
    the button (latch flag) - otherwise the script would see the release as
    you letting go and the game would get a second press."""

    name = "Titan Two (Gtuner IV)"

    def __init__(self, log, slot=0, port=47654, latch=True):
        super().__init__(log, slot)
        self.port = int(port)
        self.latch = bool(latch)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.ack = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.bridge_fps = 0.0
        self.bridge_seen = 0.0
        try:
            self.ack.bind(("127.0.0.1", self.port + 1))
            self.ack.setblocking(False)
        except OSError:
            self.ack = None
        self.running = True
        self.status = "Titan Two: waiting for the Gtuner IV bridge script"
        self.thread = threading.Thread(target=self._loop, name="titan", daemon=True)
        self.thread.start()

    def send_cvdata(self, data):
        pkt = bytearray(data[:PACKET_SIZE].ljust(PACKET_SIZE, b"\0"))
        if self.latch:
            pkt[1] |= FLAG_LATCH
        self.packet = bytes(pkt)
        try:
            self.sock.sendto(self.packet, ("127.0.0.1", self.port))
        except OSError:
            pass

    def _loop(self):
        # keep the bridge fed when the script isn't sending (e.g. no video),
        # and read the bridge's heartbeat for the status line
        while self.running:
            try:
                self.sock.sendto(self.packet, ("127.0.0.1", self.port))
            except OSError:
                pass
            if self.ack is not None:
                try:
                    while True:
                        msg, _ = self.ack.recvfrom(64)
                        if msg.startswith(b"NOVA"):
                            try:
                                self.bridge_fps = float(msg[4:].decode() or 0)
                            except ValueError:
                                self.bridge_fps = 0.0
                            self.bridge_seen = time.perf_counter()
                except (BlockingIOError, OSError):
                    pass
            age = time.perf_counter() - self.bridge_seen
            if self.bridge_seen and age < 2.0:
                self.status = "Titan Two: bridge connected (Gtuner %.0f fps)" % self.bridge_fps
            else:
                self.status = "Titan Two: waiting for the Gtuner IV bridge script"
            time.sleep(0.01)

    def close(self):
        self.running = False
        try:
            self.sock.sendto(bytes(PACKET_SIZE), ("127.0.0.1", self.port))
        except OSError:
            pass
        for s in (self.sock, self.ack):
            try:
                if s is not None:
                    s.close()
            except OSError:
                pass
