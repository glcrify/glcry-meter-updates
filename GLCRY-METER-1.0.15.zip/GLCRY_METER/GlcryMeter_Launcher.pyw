"""GLCRY METER launcher: installs any new update, then opens GLCRY METER.

The desktop shortcut runs this file.
"""

import subprocess
import sys
import threading
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

import os  # noqa: E402
from glcry import crash  # noqa: E402
crash.install(Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "GLCRY METER", APP_DIR)


def _wants_virtual_pad():
    import json
    try:
        cfg = json.loads((Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "GLCRY METER" / "app.json")
                         .read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    return int(cfg.get("mode", 0)) == 0


def start_app():
    """Virtual controller users get GLCRY METER with admin rights (Windows asks
    once), which it needs to hide the real controller from the game. If they
    say No it still opens normally."""
    app_file = str(APP_DIR / "GlcryMeter.pyw")
    if sys.platform == "win32" and _wants_virtual_pad():
        try:
            from glcry import hidhide
            if not hidhide.is_admin() and hidhide.run_elevated(sys.executable, '"%s"' % app_file,
                                                                wait_s=0, cwd=str(APP_DIR)):
                return
        except Exception:
            pass
    subprocess.Popen([sys.executable, app_file], cwd=str(APP_DIR))


def main():
    from glcry import updater

    try:
        from PySide6.QtCore import Qt, QTimer
        from PySide6.QtWidgets import QApplication, QLabel, QProgressBar, QVBoxLayout, QWidget
    except Exception:
        start_app()            # UI library missing: let the app report it
        return

    app = QApplication(sys.argv)
    w = QWidget()
    w.setWindowTitle("GLCRY METER")
    w.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
    w.setStyleSheet("QWidget{background:#0b0f15;color:#eef1f6;font-family:'Segoe UI';}"
                    "QWidget#frame{border:1px solid #2d3b50;border-radius:0px;}"
                    "QLabel{background:transparent;}"
                    "QLabel#t{font-size:24px;font-weight:800;letter-spacing:2px;} QLabel#s{color:#98a2b3;font-size:13px;}"
                    "QProgressBar{background:#141b26;border:0;border-radius:3px;max-height:6px;}"
                    "QProgressBar::chunk{background:#f2b93b;border-radius:3px;}")
    w.setObjectName("frame")
    w.setAttribute(Qt.WA_StyledBackground, True)
    v = QVBoxLayout(w)
    v.setContentsMargins(30, 26, 30, 26)
    v.setSpacing(10)
    t = QLabel("GLCRY <span style='color:#f2b93b'>METER</span>")
    t.setTextFormat(Qt.RichText)
    t.setObjectName("t")
    v.addWidget(t)
    s = QLabel("Checking for updates...")
    s.setObjectName("s")
    v.addWidget(s)
    bar = QProgressBar()
    bar.setTextVisible(False)
    bar.setRange(0, 0)
    v.addWidget(bar)
    w.resize(440, 140)
    w.show()

    state = {"text": "Checking for updates...", "p": None, "done": False}

    def work():
        try:
            m, zurl = updater.check()
            if m:
                state["text"] = "Downloading update %s..." % m["version"]
                data = updater.download(m, zurl, progress=lambda f: state.__setitem__("p", f))
                state["text"] = "Installing update %s..." % m["version"]
                state["p"] = None
                if updater.install(data):
                    state["text"] = "Installing new components..."
                    updater.install_requirements()
                state["text"] = "Updated to %s" % m["version"]
        except Exception as exc:
            state["text"] = "Update skipped: %s" % exc
        state["done"] = True

    threading.Thread(target=work, daemon=True).start()

    def tick():
        s.setText(state["text"])
        if state["p"] is None:
            bar.setRange(0, 0)
        else:
            bar.setRange(0, 1000)
            bar.setValue(int(state["p"] * 1000))
        if state["done"]:
            timer.stop()
            start_app()
            QTimer.singleShot(400, app.quit)

    timer = QTimer()
    timer.timeout.connect(tick)
    timer.start(80)
    app.exec()


if __name__ == "__main__":
    main()
