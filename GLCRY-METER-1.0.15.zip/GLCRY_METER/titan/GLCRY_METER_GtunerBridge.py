"""GLCRY METER -> Titan Two bridge for Gtuner IV (Computer Vision tab).

Load this file as the Computer Vision script in Gtuner IV and run it, with
GLCRY_METER_Bridge.gpc running on the Titan Two. GLCRY METER sends its 48-byte output
packet to this script over localhost UDP; every Gtuner frame the newest packet
is handed to the Titan Two as GCV data.

Gtuner calls process() once per captured frame, so give Gtuner the highest
frame-rate video source you have (it doesn't analyse the picture - a small,
fast source is ideal). If GLCRY METER stops sending for 150 ms the packet is
cleared, so the Titan passes your controller straight through.
"""

import socket
import time

import cv2

PORT = 47654          # must match GLCRY METER's Titan port
PACKET_SIZE = 48


class GCVWorker:
    def __init__(self, width, height):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("127.0.0.1", PORT))
        self.sock.setblocking(False)
        self.ack = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.gcvdata = bytearray(PACKET_SIZE)
        self.last_rx = 0.0
        self.frames = 0
        self.t_win = time.monotonic()
        self.fps = 0.0

    def __del__(self):
        try:
            self.sock.close()
            self.ack.close()
        except Exception:
            pass

    def process(self, frame):
        latest = None
        while True:
            try:
                pkt, _ = self.sock.recvfrom(256)
                latest = pkt
            except (BlockingIOError, OSError):
                break
        now = time.monotonic()
        if latest is not None and len(latest) >= PACKET_SIZE:
            self.gcvdata = bytearray(latest[:PACKET_SIZE])
            self.last_rx = now
        elif now - self.last_rx > 0.15:
            self.gcvdata = bytearray(PACKET_SIZE)

        self.frames += 1
        if now - self.t_win >= 0.5:
            self.fps = self.frames / (now - self.t_win)
            self.frames, self.t_win = 0, now
            try:
                self.ack.sendto(b"GLCR%.0f" % self.fps, ("127.0.0.1", PORT + 1))
            except OSError:
                pass

        linked = now - self.last_rx <= 0.15
        cv2.putText(frame, "GLCRY METER bridge: %s  %.0f fps" % ("linked" if linked else "waiting", self.fps),
                    (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.0,
                    (0, 255, 0) if linked else (0, 200, 255), 2)
        return (frame, self.gcvdata)
