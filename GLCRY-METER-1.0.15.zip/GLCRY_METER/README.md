# GLCRY METER

## Using GLCRY METER

1. Open **OBS** and press **Start Virtual Camera**.
2. Double-click **GLCRY METER** on your desktop.
3. The first time, send the **PC ID** on screen to an admin and paste the key they send back.
4. Choose how your controller is connected. That's it: video, controller and the
   shot meter set themselves up. The three cards at the top tell you if anything
   needs doing.

* **Shots early or late?** Press **Shot settings** and use **-** / **+**. With
  "Let 2K's TIMING result fine-tune this" ticked, it adjusts itself.
* **Updates** install automatically when GLCRY METER starts.
* **Game shows your controller twice?** Restart your PC once after installing.

## For advanced users

**Advanced view** shows the Helios-style panels: capture device, scripts list,
output mode, device monitor and console. GLCRY METER runs Helios-style CV Python
scripts unchanged. Put them in the `scripts` folder.

Titan Two: in Gtuner IV, run `titan/GLCRY_METER_Bridge.gpc` on the Titan and start
`titan/GLCRY_METER_GtunerBridge.py` in the Computer Vision tab. Then choose
**Controller setup > I use a Titan Two**.
