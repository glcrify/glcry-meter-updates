"""helios.storage stand-in: per-script data folder.

GLCRY METER sets HELIOS_SCRIPT_DATA_DIR to
%LOCALAPPDATA%\\GLCRY METER\\ScriptData\\<script name> before loading a script.
"""

import os
from pathlib import Path


def data_directory():
    p = os.environ.get("HELIOS_SCRIPT_DATA_DIR")
    if not p:
        raise RuntimeError("script data directory not set by host")
    path = Path(p)
    path.mkdir(parents=True, exist_ok=True)
    return path
