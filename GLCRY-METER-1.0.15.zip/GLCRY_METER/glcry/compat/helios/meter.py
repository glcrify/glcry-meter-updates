"""helios.meter stand-in: fits a meter point's approach to a release point.

update() takes the current frame's meter point, release point and bounding box;
distance is in pixels, speed in px/ms (closing), time_to_release_ms from a
straight-line fit over the last `samples` updates stamped with the frame's
capture time (timestamp_ns).
"""

import numpy as np

from . import overlay, vision

PATH_STRAIGHT = 0
PATH_QUADRATIC_BEZIER = 1
DEFAULT_COLOR = (104, 244, 255, 255)


class Meter:
    def __init__(self):
        self.samples = 8
        self.model = "average"
        self._hist = []
        self.distance = None
        self.speed = None
        self.time_to_release_ms = None
        self.elapsed_ms = None
        self.timestamp_ns = 0
        self._t0 = None
        self.path_settings = {"algorithm": PATH_STRAIGHT, "curvature": 0.25, "segments": 16}
        self.visual_settings = {"enabled": True, "show_bbox": True, "show_path": True,
                                "show_distance": True, "show_speed": True,
                                "show_time_to_release": True, "show_elapsed_time": True,
                                "bbox_color": DEFAULT_COLOR, "path_color": DEFAULT_COLOR,
                                "metrics_color": DEFAULT_COLOR, "bbox_thickness": 1,
                                "path_thickness": 1, "text_scale": 2, "text_gap": 5}

    def set_motion(self, model="average", samples=8):
        self.model = model
        self.samples = max(2, int(samples))
        self.reset()

    def set_path(self, algorithm=PATH_STRAIGHT, curvature=0.25, segments=16):
        self.path_settings = {"algorithm": algorithm, "curvature": curvature, "segments": segments}
        self.reset()
        return self

    def set_visuals(self, enabled=True, **kw):
        self.visual_settings["enabled"] = bool(enabled)
        self.visual_settings.update({k: v for k, v in kw.items() if k in self.visual_settings})
        return self

    def reset(self):
        self._hist = []
        self.distance = self.speed = self.time_to_release_ms = self.elapsed_ms = None
        self._t0 = None

    def update(self, point, release_point, bounding_box, padding=0):
        ts = int(vision._frame_ts_ns) or vision.latency_timestamp_ns()
        self.timestamp_ns = ts
        px, py = float(point[0]), float(point[1])
        rx, ry = float(release_point[0]), float(release_point[1])
        d = float(np.hypot(rx - px, ry - py))
        if rx < px:
            d = -d
        self.distance = d
        if self._t0 is None:
            self._t0 = ts
        self.elapsed_ms = (ts - self._t0) / 1e6
        self._hist.append((ts / 1e6, d))
        self._hist = self._hist[-self.samples:]
        self.speed = self.time_to_release_ms = None
        if len(self._hist) >= 2:
            t = np.array([h[0] for h in self._hist])
            dd = np.array([h[1] for h in self._hist])
            if t[-1] - t[0] > 0.5:
                slope = np.polyfit(t - t[-1], dd, 1)[0]
                sp = -float(slope)
                self.speed = sp
                if sp > 1e-6:
                    self.time_to_release_ms = d / sp
        self._draw(point, release_point, bounding_box, padding)
        return self

    def _draw(self, point, release_point, box, padding):
        v = self.visual_settings
        if not v["enabled"]:
            return
        x, y, w, h = box
        if isinstance(padding, (int, float)):
            pl = pt = pr = pb = padding
        else:
            pl, pt, pr, pb = (list(padding) + [0, 0, 0, 0])[:4]
        if v["show_bbox"]:
            overlay.rect(x - pl, y - pt, x + w + pr, y + h + pb, color=v["bbox_color"],
                         thickness=v["bbox_thickness"])
        if v["show_path"]:
            overlay.line(point[0], point[1], release_point[0], release_point[1],
                         color=v["path_color"], thickness=v["path_thickness"])
        lines = []
        if v["show_elapsed_time"] and self.elapsed_ms is not None:
            lines.append("TIME:%.2f" % (self.elapsed_ms / 1000.0))
        if v["show_distance"] and self.distance is not None:
            lines.append("DISTANCE:%.1f" % self.distance)
        if v["show_speed"]:
            lines.append("SPEED PX/MS:%s" % ("--" if self.speed is None else "%.4f" % self.speed))
        if v["show_time_to_release"]:
            lines.append("ETA MS:%s" % ("--" if self.time_to_release_ms is None else "%.2f" % self.time_to_release_ms))
        ty = y - pt - 6 - len(lines) * (10 * v["text_scale"] + v["text_gap"])
        for s in lines:
            overlay.text(s, x - pl, ty, color=v["metrics_color"], scale=v["text_scale"],
                         background_color=None)
            ty += 10 * v["text_scale"] + v["text_gap"]
