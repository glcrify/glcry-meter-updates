"""helios.controls stand-in: controller state in, CV output packet out.

Identifiers follow the Titan Two / Helios numbering:
  BUTTON_1 Guide/PS, BUTTON_2 View/Share, BUTTON_3 Menu/Options, BUTTON_4 RB/R1,
  BUTTON_5 RT/R2, BUTTON_6 RS/R3, BUTTON_7 LB/L1, BUTTON_8 LT/L2, BUTTON_9 LS/L3,
  BUTTON_10-13 D-pad up/down/left/right, BUTTON_14 Y/Triangle, BUTTON_15 B/Circle,
  BUTTON_16 A/Cross, BUTTON_17 X/Square.
  STICK_1_X/Y right stick, STICK_2_X/Y left stick (-100..100, +Y = down).
Buttons and triggers read 0..100.
"""

for _i in range(21):
    globals()["BUTTON_%d" % (_i + 1)] = _i

STICK_1_X = 21
STICK_1_Y = 22
STICK_2_X = 23
STICK_2_Y = 24
POINT_1_X = 25
POINT_1_Y = 26
POINT_2_X = 27
POINT_2_Y = 28
ACCEL_1_X = 29
ACCEL_1_Y = 30
ACCEL_1_Z = 31
ACCEL_2_X = 32
ACCEL_2_Y = 33
ACCEL_2_Z = 34
GYRO_1_X = 35
GYRO_1_Y = 36
GYRO_1_Z = 37

# Set by the GLCRY METER host: an object with get_actual(identifier) -> float and
# send_cvdata(bytes) -> None.
_host = None


def get_actual(identifier):
    """Current value of a physical input (0..100, sticks -100..100)."""
    h = _host
    if h is None:
        return 0.0
    try:
        return float(h.get_actual(int(identifier)))
    except Exception:
        return 0.0


def send_cvdata(data):
    """Send this frame's CV output packet (Helios 'Creative' layout)."""
    h = _host
    if h is not None:
        h.send_cvdata(bytes(data))


__all__ = [n for n in list(globals()) if n.isupper()] + ["get_actual", "send_cvdata"]
