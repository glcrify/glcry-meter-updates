"""helios.vision stand-in: colour-range contour search on the current frame.

ContourFinder works on the host's current frame (no frame argument), like the
Helios API. ROI and size limits are given in 1920x1080 design units and scaled
to the real frame; results' .bounds are (x, y, w, h) in frame pixels, largest
first.
"""

import time

import cv2
import numpy as np

# Set by the host before each process() call.
_frame = None
_frame_ts_ns = 0


def latency_timestamp_ns():
    """'Now' on the same steady clock as frame capture timestamps."""
    return time.perf_counter_ns()


class BgrRange:
    def __init__(self, low, high):
        self.low = np.array([int(v) for v in low[:3]], dtype=np.uint8)
        self.high = np.array([int(v) for v in high[:3]], dtype=np.uint8)


class Contour:
    __slots__ = ("bounds", "area", "center")

    def __init__(self, bounds, area):
        self.bounds = bounds
        self.area = area
        x, y, w, h = bounds
        self.center = (x + w / 2.0, y + h / 2.0)


class ContourFinder:
    def __init__(self, colors, roi=None, width=(0, 100000), height=(0, 100000),
                 max_results=64, **_):
        self.colors = list(colors)
        self.roi = roi
        self.width = width
        self.height = height
        self.max_results = int(max_results)
        self.spread = 255
        self.visuals = False

    def set_maximum_channel_spread(self, spread):
        self.spread = int(spread)
        return self

    def set_visuals(self, enabled=True, **_):
        self.visuals = bool(enabled)
        return self

    def set_roi(self, roi):
        self.roi = roi
        return self

    def find(self):
        f = _frame
        if f is None:
            return []
        H, W = f.shape[:2]
        sx, sy = W / 1920.0, H / 1080.0
        if self.roi is not None:
            rx, ry, rw, rh = self.roi
            x0, y0 = max(0, int(rx * sx)), max(0, int(ry * sy))
            x1, y1 = min(W, int((rx + rw) * sx)), min(H, int((ry + rh) * sy))
        else:
            x0, y0, x1, y1 = 0, 0, W, H
        if x1 - x0 < 2 or y1 - y0 < 2:
            return []
        reg = f[y0:y1, x0:x1]
        mask = None
        for c in self.colors:
            m = cv2.inRange(reg, c.low, c.high)
            mask = m if mask is None else cv2.bitwise_or(mask, m)
        if mask is None:
            return []
        if self.spread < 255:
            b, g, r = cv2.split(reg)
            mx = cv2.max(cv2.max(b, g), r)
            mn = cv2.min(cv2.min(b, g), r)
            ok = cv2.compare(cv2.subtract(mx, mn), self.spread, cv2.CMP_LE)
            mask = cv2.bitwise_and(mask, ok)
        n, _, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        if n <= 1:
            return []
        st = stats[1:]
        wmin, wmax = self.width[0] * sx, self.width[1] * sx
        hmin, hmax = self.height[0] * sy, self.height[1] * sy
        bw, bh = st[:, cv2.CC_STAT_WIDTH], st[:, cv2.CC_STAT_HEIGHT]
        keep = (bw >= wmin) & (bw <= wmax) & (bh >= hmin) & (bh <= hmax)
        st = st[keep]
        if st.shape[0] == 0:
            return []
        order = np.argsort(-st[:, cv2.CC_STAT_AREA])[: self.max_results]
        out = []
        for i in order:
            x, y, w, h, a = (int(v) for v in st[i, :5])
            out.append(Contour((x + x0, y + y0, w, h), a))
        if self.visuals:
            from . import overlay
            for c in out:
                x, y, w, h = c.bounds
                overlay.rect(x, y, x + w, y + h, color=(0, 255, 0), thickness=1)
        return out
