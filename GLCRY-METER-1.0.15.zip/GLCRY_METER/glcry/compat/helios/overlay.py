"""helios.overlay stand-in.

Drawing calls are recorded during process() and drawn by GLCRY METER on the
displayed video afterwards, so the frame the script analyses is never altered.
Coordinates default to frame pixels; space=DESIGN_1080P scales x by width/1920,
y and lengths by height/1080. Colours are RGB.
"""

FRAME = 1
FUSER = 2
BOTH = 3

PIXELS = 0
DESIGN_1080P = 1

TOP_LEFT, TOP_CENTER, TOP_RIGHT = 0, 1, 2
MIDDLE_LEFT, CENTER, MIDDLE_RIGHT = 3, 4, 5
BOTTOM_LEFT, BOTTOM_CENTER, BOTTOM_RIGHT = 6, 7, 8
MIDDLE_CENTER = CENTER

# Set by the host before each process() call.
_size = (1920, 1080)
_cmds = []
MAX_COMMANDS = 4096


def _sx(space):
    if space == DESIGN_1080P:
        w, h = _size
        return w / 1920.0, h / 1080.0
    return 1.0, 1.0


def _col(color, alpha=255):
    c = tuple(int(v) for v in color) if color is not None else (255, 255, 255)
    if len(c) == 4:
        return c[:3], c[3]
    return c[:3], int(alpha)


def _add(cmd):
    if len(_cmds) < MAX_COMMANDS:
        _cmds.append(cmd)


def line(x1, y1, x2, y2, color=(255, 255, 255), thickness=1, alpha=255,
         target=BOTH, space=PIXELS, **_):
    sx, sy = _sx(space)
    rgb, a = _col(color, alpha)
    _add(("line", x1 * sx, y1 * sy, x2 * sx, y2 * sy, rgb, a, max(1, int(round(thickness * sy)))))


def rect(x1, y1, x2, y2, color=(255, 255, 255), thickness=1, filled=False, alpha=255,
         target=BOTH, space=PIXELS, **_):
    sx, sy = _sx(space)
    rgb, a = _col(color, alpha)
    fill = filled or thickness <= 0
    _add(("rect", x1 * sx, y1 * sy, x2 * sx, y2 * sy, rgb, a,
          -1 if fill else max(1, int(round(thickness * sy)))))


rectangle = rect


def circle(x, y, radius, color=(255, 255, 255), thickness=1, filled=False, alpha=255,
           target=BOTH, space=PIXELS, **_):
    sx, sy = _sx(space)
    rgb, a = _col(color, alpha)
    fill = filled or thickness <= 0
    _add(("circle", x * sx, y * sy, radius * sy, rgb, a,
          -1 if fill else max(1, int(round(thickness * sy)))))


def text(s, x, y, color=(255, 255, 255), alpha=255, scale=1, background_color=(0, 0, 0),
         background_alpha=128, padding=2, anchor=TOP_LEFT, target=BOTH, space=PIXELS, **_):
    sx, sy = _sx(space)
    rgb, a = _col(color, alpha)
    bg = None
    if background_color is not None:
        brgb, ba = _col(background_color, background_alpha)
        if ba > 0:
            bg = (brgb, ba)
    _add(("text", str(s), x * sx, y * sy, rgb, a, max(1, int(scale)) * sy, bg, padding * sy, int(anchor)))


def take():
    """Host: return this frame's commands and start a new list."""
    global _cmds
    out, _cmds = _cmds, []
    return out
