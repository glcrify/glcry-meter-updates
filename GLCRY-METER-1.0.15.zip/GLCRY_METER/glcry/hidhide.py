"""Hide the real controller from the game while the virtual one is in use.

Without this the game sees two controllers, keeps listening to your real one,
and GLCRY METER's early release never reaches it.

Changing HidHide needs admin rights. The launcher opens GLCRY METER with admin
rights (Windows asks "Yes" once per launch), so hiding is switched on and off
directly. If that prompt was refused, each switch asks Windows again.
"""

import ctypes
import json
import os
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "GLCRY METER"
REQ = ROOT / "hidhide_request.json"
RES = ROOT / "hidhide_result.json"
WORKER = Path(__file__).resolve().parent / "hidhide_task.py"


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _pythonw():
    p = Path(sys.executable)
    w = p.with_name("pythonw.exe")
    return str(w if w.exists() else p)


def run_elevated(exe, params, wait_s=60.0, cwd=None):
    """Start exe with admin rights (Windows shows its Yes/No prompt).
    -> True if it started. Waits up to wait_s for it to finish (0 = don't wait)."""
    from ctypes import wintypes

    class SEI(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("fMask", ctypes.c_ulong), ("hwnd", wintypes.HWND),
                    ("lpVerb", wintypes.LPCWSTR), ("lpFile", wintypes.LPCWSTR), ("lpParameters", wintypes.LPCWSTR),
                    ("lpDirectory", wintypes.LPCWSTR), ("nShow", ctypes.c_int), ("hInstApp", wintypes.HINSTANCE),
                    ("lpIDList", ctypes.c_void_p), ("lpClass", wintypes.LPCWSTR), ("hkeyClass", wintypes.HKEY),
                    ("dwHotKey", wintypes.DWORD), ("hIcon", wintypes.HANDLE), ("hProcess", wintypes.HANDLE)]
    sei = SEI()
    sei.cbSize = ctypes.sizeof(SEI)
    sei.fMask = 0x40                      # SEE_MASK_NOCLOSEPROCESS
    sei.lpVerb, sei.lpFile, sei.lpParameters, sei.lpDirectory, sei.nShow = "runas", exe, params, cwd, 1
    if not ctypes.windll.shell32.ShellExecuteExW(ctypes.byref(sei)):
        return False                      # "No" pressed
    if sei.hProcess:
        if wait_s:
            ctypes.windll.kernel32.WaitForSingleObject(sei.hProcess, int(wait_s * 1000))
        ctypes.windll.kernel32.CloseHandle(sei.hProcess)
    return True


def request(action, log=None, timeout=20.0):
    """action "on" or "off". -> result dict (always has "ok")."""
    if sys.platform != "win32":
        return {"ok": False, "error": "Windows only"}
    from . import hidhide_task
    if is_admin():
        try:
            return hidhide_task.handle({"action": action})
        except Exception as exc:
            return {"ok": False, "error": str(exc)}
    # not admin: run the worker once with a Windows prompt
    rid = uuid.uuid4().hex
    ROOT.mkdir(parents=True, exist_ok=True)
    try:
        RES.unlink()
    except Exception:
        pass
    REQ.write_text(json.dumps({"id": rid, "action": action, "time": time.time()}), encoding="utf-8")
    if log:
        log.write("Controller hiding: asking Windows for permission")
    if not run_elevated(_pythonw(), '"%s"' % WORKER, wait_s=timeout):
        return {"ok": False, "error": "Windows permission was refused, so your controller can't be hidden "
                                      "from the game."}
    t_end = time.time() + 3.0
    while time.time() < t_end:
        try:
            res = json.loads(RES.read_text(encoding="utf-8"))
            if res.get("id") == rid:
                return res
        except Exception:
            pass
        time.sleep(0.1)
    return {"ok": False, "error": "The controller hider didn't answer."}
