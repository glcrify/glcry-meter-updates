"""Hardware ID and licence keys.

A key is: version | hardware ID | issued day | expiry day | role | name, signed
with the owner's Ed25519 private key. The app holds only the public key (in
glcry/trust.json, written by the owner panel when it builds the installer),
so keys can't be forged, and a key only works on the PC whose hardware ID it
contains.
"""

import base64
import datetime as _dt
import hashlib
import json
import struct
import sys
import uuid
from pathlib import Path

from . import crypto

KEY_PREFIX = "GLCRY-"
SIG_DOMAIN = b"NOVACV-KEY1"
REV_DOMAIN = b"NOVACV-REV1"   # the next three are fixed identity: changing them
APP_ID = "GLCRYMETER"         # would invalidate keys already issued and activated
EPOCH = _dt.date(2024, 1, 1)
ROLES = {0: "Staff", 1: "Tester", 2: "User"}
TRUST_FILE = Path(__file__).resolve().parent / "trust.json"


def load_trust():
    try:
        return json.loads(TRUST_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _machine_guid():
    if sys.platform == "win32":
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
                               0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
            v, _ = winreg.QueryValueEx(k, "MachineGuid")
            return str(v)
        except Exception:
            pass
    try:
        return Path("/etc/machine-id").read_text().strip()
    except Exception:
        return "mac-%012x" % uuid.getnode()


def hwid_bytes():
    return hashlib.sha256(b"NovaCV-HWID|" + _machine_guid().encode()).digest()[:10]


def format_hwid(b):
    s = base64.b32encode(b).decode().rstrip("=")
    return "-".join(s[i:i + 4] for i in range(0, len(s), 4))


def parse_hwid(text):
    s = "".join(ch for ch in text.upper() if ch.isalnum())
    s += "=" * (-len(s) % 8)
    b = base64.b32decode(s)
    if len(b) != 10:
        raise ValueError("hardware ID should be 16 characters")
    return b


def this_hwid():
    return format_hwid(hwid_bytes())


def _strip_prefix(s):
    """Remove the GLCRY- (or older NOVA-) prefix. Key data always starts with
    'A', so neither word can be part of it."""
    for p in ("GLCRY", "NOVA"):
        if s.startswith(p):
            return s[len(p):]
    return s


def _days(d):
    return (d - EPOCH).days


ANY_PC = b"\0" * 10


def make_key(secret, hwid, name, role=1, expiry=None, issued=None):
    """hwid=None makes a key that locks to the first PC that activates it
    (online, see activate_online)."""
    issued = issued or _dt.date.today()
    nb = name.encode("utf-8")[:20]
    ver = 1 if hwid else 2
    payload = struct.pack(">B10sHHBB", ver, hwid or ANY_PC, _days(issued),
                          0 if expiry is None else _days(expiry), int(role), len(nb)) + nb
    sig = crypto.sign(secret, SIG_DOMAIN + payload)
    s = base64.b32encode(payload + sig).decode().rstrip("=")
    return KEY_PREFIX + "-".join(s[i:i + 5] for i in range(0, len(s), 5))


def check_key(text, public_key=None, hwid=None, today=None, check_cancelled=True):
    """-> (ok, info dict or reason string)."""
    if public_key is None:
        pk = load_trust().get("public_key")
        if not pk:
            return False, "This copy of GLCRY METER has no owner key set."
        public_key = bytes.fromhex(pk)
    s = "".join(ch for ch in text.upper() if ch.isalnum())
    s = _strip_prefix(s)
    if len(s) < 120:
        return False, "Key is too short - paste the whole key."
    try:
        raw = base64.b32decode(s + "=" * (-len(s) % 8))
    except Exception:
        return False, "That isn't a valid key."
    if len(raw) < 17 + 64:
        return False, "That isn't a valid key."
    payload, sig = raw[:-64], raw[-64:]
    if not crypto.verify(public_key, SIG_DOMAIN + payload, sig):
        return False, "That key isn't valid."
    ver, hw, iss, exp, role, nl = struct.unpack(">B10sHHBB", payload[:17])
    kid = key_id_from_payload(payload)
    rev = revoked_cache() if check_cancelled else {}
    here = hwid or hwid_bytes()
    if kid in rev.get("keys", []) or hw.hex() in rev.get("pcs", []) \
            or (ver == 2 and here.hex() in rev.get("pcs", [])):
        return False, "This key has been cancelled. Ask an admin for a new one."
    name = payload[17:17 + nl].decode("utf-8", "replace")
    if ver not in (1, 2):
        return False, "That key is for a different version."
    if ver == 1 and hw != here:
        return False, "That key belongs to a different PC."
    today = today or _dt.date.today()
    expiry = None if exp == 0 else EPOCH + _dt.timedelta(days=exp)
    if expiry is not None and today > expiry:
        return False, "That key expired on %s." % expiry.isoformat()
    return True, {"name": name, "role": ROLES.get(role, "User"), "expiry": expiry,
                  "issued": EPOCH + _dt.timedelta(days=iss), "hwid": format_hwid(here), "key_id": kid,
                  "activate": ver == 2}


def key_file(data_root):
    return Path(data_root) / "license.key"


def saved_key_ok(data_root):
    try:
        k = key_file(data_root).read_text(encoding="utf-8").strip()
    except Exception:
        return False, None
    ok, info = check_key(k)
    if ok and info.get("activate") and not is_activated_here(data_root, info["key_id"]):
        return False, None
    return ok, info if ok else None


# ----------------------------------------------------------------------------
# Activation (keys made without a PC ID)
# ----------------------------------------------------------------------------
# The first PC to use such a key claims it: the app sends the key and this PC's
# ID to the owner's activation server, which remembers the first PC per key and
# refuses any other. The app keeps a local record so it works offline, and
# re-checks at start-up and every 30 minutes.

def activation_file(data_root):
    return Path(data_root) / "activation.json"


def is_activated_here(data_root, kid):
    try:
        a = json.loads(activation_file(data_root).read_text(encoding="utf-8"))
        return a.get("key_id") == kid and a.get("hwid") == this_hwid()
    except Exception:
        return False


def mark_activated(data_root, kid):
    f = activation_file(data_root)
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps({"key_id": kid, "hwid": this_hwid()}), encoding="utf-8")


def clear_activation(data_root):
    try:
        activation_file(data_root).unlink()
    except Exception:
        pass


def activate_online(key_text, timeout=8.0):
    """-> "ok", "taken", "cancelled" or "offline"."""
    import urllib.error
    import urllib.request
    url = (load_trust().get("activation_url") or "").strip().rstrip("/")
    if not url:
        return "offline"
    body = json.dumps({"key": "".join(ch for ch in key_text if ch.isalnum() or ch == "-"),
                       "hwid": this_hwid()}).encode()
    try:
        req = urllib.request.Request(url + "/activate", data=body, method="POST",
                                     headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) GLCRY-METER/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            doc = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            doc = json.loads(e.read().decode("utf-8"))
        except Exception:
            return "offline"
    except Exception:
        return "offline"
    if doc.get("ok"):
        return "ok"
    return {"taken": "taken", "cancelled": "cancelled", "bad": "bad"}.get(doc.get("reason"), "offline")


ACTIVATION_MESSAGES = {
    "taken": "This key is already being used on another PC. Ask an admin to move it to this PC.",
    "cancelled": "This key has been cancelled. Ask an admin for a new one.",
    "bad": "That key isn't valid. Paste the whole key.",
    "offline": "Couldn't reach the activation server. Check your internet, then paste the key again.",
}


# ----------------------------------------------------------------------------
# Cancelled keys
# ----------------------------------------------------------------------------
# The owner publishes revoked.json next to manifest.json:
#   {"app": "GLCRYMETER", "seq": N, "keys": [key ids], "pcs": [hardware id hex], "sig": ...}
# signed with the owner key. Each PC keeps the newest valid list it has seen
# (higher seq wins, so an old list can't be replayed to un-cancel a key) and
# checks it offline too.

def key_id_from_payload(payload):
    return hashlib.sha256(payload).hexdigest()[:16]


def key_id(text):
    s = "".join(ch for ch in text.upper() if ch.isalnum())
    s = _strip_prefix(s)
    raw = base64.b32decode(s + "=" * (-len(s) % 8))
    return key_id_from_payload(raw[:-64])


def revocation_message(doc):
    body = {k: v for k, v in doc.items() if k != "sig"}
    return REV_DOMAIN + json.dumps(body, sort_keys=True, separators=(",", ":")).encode()


def sign_revocations(secret, keys, pcs, seq):
    doc = {"app": APP_ID, "seq": int(seq), "keys": sorted(set(keys)), "pcs": sorted(set(pcs))}
    doc["sig"] = crypto.sign(secret, revocation_message(doc)).hex()
    return doc


def revocations_valid(doc, public_key=None):
    try:
        if public_key is None:
            public_key = bytes.fromhex(load_trust()["public_key"])
        return doc.get("app") == APP_ID and crypto.verify(
            public_key, revocation_message(doc), bytes.fromhex(doc.get("sig", "")))
    except Exception:
        return False


_REV_PATH = None


def set_data_root(root):
    """Where the cached cancelled-keys list lives (the app's data folder)."""
    global _REV_PATH
    _REV_PATH = Path(root) / "revoked.json"


def revoked_cache():
    if _REV_PATH is None:
        return {}
    try:
        doc = json.loads(_REV_PATH.read_text(encoding="utf-8"))
        return doc if revocations_valid(doc) else {}
    except Exception:
        return {}


def store_revocations(doc):
    """Keep doc if it's validly signed and newer than what we have. -> True if stored."""
    if _REV_PATH is None or not revocations_valid(doc):
        return False
    if int(doc.get("seq", 0)) < int(revoked_cache().get("seq", -1)):
        return False
    _REV_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = _REV_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(doc), encoding="utf-8")
    tmp.replace(_REV_PATH)
    return True


def refresh_revocations(timeout=5.0):
    """Fetch revoked.json from the update address. -> True if a list was stored."""
    import urllib.request
    url = (load_trust().get("update_url") or "").strip()
    if not url:
        return False
    base = url if url.endswith("/") else url.rsplit("/", 1)[0] + "/"
    try:
        req = urllib.request.Request(base + "revoked.json",
                                     headers={"User-Agent": "GLCRYMETER", "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            doc = json.loads(r.read().decode("utf-8"))
    except Exception:
        return False
    return store_revocations(doc)
