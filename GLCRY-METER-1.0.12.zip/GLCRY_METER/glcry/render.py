"""Draws recorded overlay commands onto a (scaled) copy of the frame."""

import cv2
import numpy as np

_FONT = cv2.FONT_HERSHEY_SIMPLEX


def _bgr(rgb):
    return (int(rgb[2]), int(rgb[1]), int(rgb[0]))


def _blend(img, x0, y0, x1, y1, rgb, alpha):
    H, W = img.shape[:2]
    x0, y0 = max(0, int(x0)), max(0, int(y0))
    x1, y1 = min(W, int(x1)), min(H, int(y1))
    if x1 <= x0 or y1 <= y0:
        return
    roi = img[y0:y1, x0:x1]
    a = alpha / 255.0
    col = np.array(_bgr(rgb), dtype=np.float32)
    roi[:] = (roi.astype(np.float32) * (1 - a) + col * a).astype(np.uint8)


def draw(img, cmds, scale):
    """img: display image (already resized); scale: display px per frame px."""
    for c in cmds:
        k = c[0]
        try:
            if k == "line":
                _, x1, y1, x2, y2, rgb, a, th = c
                cv2.line(img, (int(x1 * scale), int(y1 * scale)), (int(x2 * scale), int(y2 * scale)),
                         _bgr(rgb), max(1, int(round(th * scale))), cv2.LINE_AA)
            elif k == "rect":
                _, x1, y1, x2, y2, rgb, a, th = c
                p1, p2 = (int(x1 * scale), int(y1 * scale)), (int(x2 * scale), int(y2 * scale))
                if th < 0 and a < 255:
                    _blend(img, p1[0], p1[1], p2[0], p2[1], rgb, a)
                else:
                    cv2.rectangle(img, p1, p2, _bgr(rgb), -1 if th < 0 else max(1, int(round(th * scale))))
            elif k == "circle":
                _, x, y, r, rgb, a, th = c
                cv2.circle(img, (int(x * scale), int(y * scale)), max(1, int(r * scale)), _bgr(rgb),
                           -1 if th < 0 else max(1, int(round(th * scale))), cv2.LINE_AA)
            elif k == "text":
                _, s, x, y, rgb, a, sc, bg, pad, anchor = c
                fs = 0.42 * sc * scale
                th = max(1, int(round(sc * scale * 0.9)))
                (tw, tht), base = cv2.getTextSize(s, _FONT, fs, th)
                pad = pad * scale
                X, Y = x * scale, y * scale
                col = anchor % 3
                row = anchor // 3
                X -= (0, tw / 2.0, tw)[col]
                Y -= (0, tht / 2.0, tht)[row]
                if bg is not None:
                    _blend(img, X - pad, Y - pad, X + tw + pad, Y + tht + base + pad, bg[0], bg[1])
                cv2.putText(img, s, (int(X), int(Y + tht)), _FONT, fs, _bgr(rgb), th, cv2.LINE_AA)
        except Exception:
            continue
    return img


def compose(frame, cmds, target_w, target_h):
    """Resize the frame to fit target size (keep aspect) and draw overlays."""
    h, w = frame.shape[:2]
    scale = min(target_w / float(w), target_h / float(h))
    scale = max(0.05, scale)
    dw, dh = max(1, int(w * scale)), max(1, int(h * scale))
    img = cv2.resize(frame, (dw, dh), interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR)
    draw(img, cmds, scale)
    return img
