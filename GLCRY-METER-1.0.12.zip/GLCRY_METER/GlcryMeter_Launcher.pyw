"""GLCRY METER launcher: installs any new update, then opens GLCRY METER.

The desktop shortcut runs this file.
"""

import subprocess
import sys
import threading
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

import os  # noqa: E402
from glcry import crash  # noqa: E402
crash.install(Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "GLCRY METER", APP_DIR)


def _wants_virtual_pad():
    import json
    try:
        cfg = json.loads((Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "GLCRY METER" / "app.json")
                         .read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    return int(cfg.get("mode", 0)) == 0


def start_app():
    """Virtual controller users get GLCRY METER with admin rights (Windows asks
    once), which it needs to hide the real controller from the game. If they
    say No it still opens normally."""
    app_file = str(APP_DIR / "GlcryMeter.pyw")
    if sys.platform == "win32" and _wants_virtual_pad():
        try:
            from glcry import hidhide
            if not hidhide.is_admin() and hidhide.run_elevated(sys.executable, '"%s"' % app_file,
                                                                wait_s=0, cwd=str(APP_DIR)):
                return
        except Exception:
            pass
    subprocess.Popen([sys.executable, app_file], cwd=str(APP_DIR))


def main():
    from glcry import updater

    try:
        from PySide6.QtCore import Qt, QTimer
        from PySide6.QtWidgets import QApplication, QLabel, QProgressBar, QVBoxLayout, QWidget
    except Exception:
        start_app()            # UI library missing: let the app report it
        return

    app = QApplication(sys.argv)
    w = QWidget()
    w.setWindowTitle("GLCRY METER")
    w.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
    w.setStyleSheet("QWidget{background:#15171c;color:#e4e7ee;font-family:'Segoe UI';}"
                    "QLabel#t{font-size:22px;font-weight:600;} QLabel#s{color:#9aa3b2;font-size:13px;}"
                    "QProgressBar{background:#0f1115;border:1px solid #30343c;border-radius:5px;height:10px;}"
                    "QProgressBar::chunk{background:#2f6fed;border-radius:5px;}")
    v = QVBoxLayout(w)
    v.setContentsMargins(30, 24, 30, 24)
    t = QLabel("GLCRY METER")
    t.setObjectName("t")
    v.addWidget(t)
    s = QLabel("Checking for updates...")
    s.setObjectName("s")
    v.addWidget(s)
    bar = QProgressBar()
    bar.setTextVisible(False)
    bar.setRange(0, 0)
    v.addWidget(bar)
    w.resize(420, 130)
    w.show()

    state = {"text": "Checking for updates...", "p": None, "done": False}

    def work():
        try:
            m, zurl = updater.check()
            if m:
                state["text"] = "Downloading update %s..." % m["version"]
                data = updater.download(m, zurl, progress=lambda f: state.__setitem__("p", f))
                state["text"] = "Installing update %s..." % m["version"]
                state["p"] = None
                if updater.install(data):
                    state["text"] = "Installing new components..."
                    updater.install_requirements()
                state["text"] = "Updated to %s" % m["version"]
        except Exception as exc:
            state["text"] = "Update skipped: %s" % exc
        state["done"] = True

    threading.Thread(target=work, daemon=True).start()

    def tick():
        s.setText(state["text"])
        if state["p"] is None:
            bar.setRange(0, 0)
        else:
            bar.setRange(0, 1000)
            bar.setValue(int(state["p"] * 1000))
        if state["done"]:
            timer.stop()
            start_app()
            QTimer.singleShot(400, app.quit)

    timer = QTimer()
    timer.timeout.connect(tick)
    timer.start(80)
    app.exec()


if __name__ == "__main__":
    main()
