"""GLCRY METER controller hider - needs admin rights.

Called directly by GLCRY METER when it runs as admin, or started on its own
with a Windows prompt when it doesn't.

Reads  %LOCALAPPDATA%\\GLCRY METER\\hidhide_request.json  {"id": ..., "action": "on"|"off"}
Writes %LOCALAPPDATA%\\GLCRY METER\\hidhide_result.json   {"id": ..., "ok": ..., ...}

on:  hide every game controller plugged in right now (GLCRY METER asks for
     this BEFORE it creates its virtual controller, so that one stays
     visible), let GLCRY METER's Python still see them, and switch hiding on.
off: switch hiding off, so the game sees your controller normally again.
"""

import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "GLCRY METER"
REQ = ROOT / "hidhide_request.json"
RES = ROOT / "hidhide_result.json"
NO_WINDOW = 0x08000000


def find_cli():
    for base in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramW6432", "")):
        if not base:
            continue
        root = Path(base) / "Nefarius Software Solutions"
        for p in (root / "HidHide" / "x64" / "HidHideCLI.exe", root / "HidHide" / "HidHideCLI.exe"):
            if p.exists():
                return str(p)
        if root.exists():
            for p in root.rglob("HidHideCLI.exe"):
                return str(p)
    return None


def run(cli, *args):
    r = subprocess.run([cli, *args], capture_output=True, text=True, timeout=20, creationflags=NO_WINDOW)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


VIRTUAL_IDS = ("VID_045E&PID_028E",)   # Xbox 360 pads - what ViGEm (GLCRY METER's virtual pad) creates
LAST = ROOT / "hidden_devices.json"


def _is_virtual(*texts):
    t = " ".join(x for x in texts if x).upper()
    return "VIGEM" in t or any(v in t for v in VIRTUAL_IDS)


def gaming_devices(cli):
    """-> [(name, [instance paths])] for real game controllers that are plugged in
    (never GLCRY METER's own virtual Xbox 360 pad)."""
    data, out = None, ""
    for _ in range(4):               # a controller that's mid-restart makes the list fail
        rc, out = run(cli, "--dev-gaming")
        try:
            data = json.loads(out[out.index("["):])
            break
        except Exception:
            time.sleep(1.0)
    if data is None:
        return [], out.strip()[:300]
    found = []

    def walk(node, name=""):
        if isinstance(node, list):
            for x in node:
                walk(x, name)
        elif isinstance(node, dict):
            name = node.get("friendlyName") or name
            if "deviceInstancePath" in node and node.get("present", True):
                paths = [node.get("deviceInstancePath"), node.get("baseContainerDeviceInstancePath")]
                if not _is_virtual(name, node.get("description", ""), *paths):
                    found.append((name or node.get("description") or "controller", [p for p in paths if p]))
            for v in node.values():
                if isinstance(v, (list, dict)):
                    walk(v, name)
    walk(data)
    return found, ""


def unhide_virtual(cli):
    """Older versions could hide GLCRY METER's own virtual pad by mistake - undo that."""
    rc, out = run(cli, "--dev-list")
    for p in set(re.findall(r'(?:HID|USB|BTHENUM|BTHLEDEVICE|ROOT)\\\\?[^\s"\],]+', out)):
        p = p.replace("\\\\", "\\")
        if _is_virtual(p):
            run(cli, "--dev-unhide", p)


def unhide_parents(cli):
    """1.0.3-1.0.6 also hid the parent USB/Bluetooth device; take those back off."""
    rc, out = run(cli, "--dev-list")
    for p in set(re.findall(r'(?:USB|BTHENUM|BTHLEDEVICE)\\\\?[^\s"\],]+', out)):
        run(cli, "--dev-unhide", p.replace("\\\\", "\\"))


def restart_devices(paths):
    """Re-plug the controller in software. A game that already had it open
    keeps reading it until the device restarts; after this it can't reopen it
    (or, when hiding is switched off, it notices the controller again)."""
    for p in paths:
        try:
            subprocess.run(["pnputil", "/restart-device", p], capture_output=True, timeout=20,
                           creationflags=NO_WINDOW)
        except Exception:
            pass


def handle(req):
    cli = find_cli()
    if not cli:
        return {"ok": False, "error": "HidHide isn't installed - run GLCRY METER Setup again."}
    if req.get("action") == "off":
        rc, out = run(cli, "--cloak-off")
        try:
            restart_devices(json.loads(LAST.read_text(encoding="utf-8")))
        except Exception:
            pass
        return {"ok": rc == 0, "error": out.strip()[:300] if rc else ""}
    exe_dir = Path(sys.executable).parent
    for exe in ("pythonw.exe", "python.exe"):
        if (exe_dir / exe).exists():
            run(cli, "--app-reg", str(exe_dir / exe))
    unhide_virtual(cli)
    devs, err = gaming_devices(cli)
    hidden, restart = [], []
    for name, paths in devs:
        # hide the controller's HID device and its parent: games reading the
        # pad through XInput open the parent, so both must be hidden
        for p in paths:
            run(cli, "--dev-hide", p)
        hidden.append(name)
        restart.append(paths[-1])          # the base device (USB / Bluetooth) restarts the whole pad
    rc, out = run(cli, "--cloak-on")
    try:
        LAST.write_text(json.dumps(restart), encoding="utf-8")
    except Exception:
        pass
    restart_devices(restart)
    return {"ok": rc == 0 and bool(hidden), "hidden": hidden,
            "error": (out.strip()[:300] if rc else "") or (err if not hidden else "")
            or ("" if hidden else "No controller found - plug it in and press Apply output.")}


def main():
    try:
        req = json.loads(REQ.read_text(encoding="utf-8"))
    except Exception:
        return
    if time.time() - float(req.get("time", 0)) > 120:
        return                                  # stale request
    try:
        res = handle(req)
    except Exception as exc:
        res = {"ok": False, "error": str(exc)}
    res["id"] = req.get("id")
    tmp = RES.with_suffix(".tmp")
    tmp.write_text(json.dumps(res), encoding="utf-8")
    tmp.replace(RES)


if __name__ == "__main__":
    main()
