"""STEP UP FN shot macro, built into GLCRY METER (no video needed).

Same behaviour as STEP_UP_FN_Shot_Macro_Titan_Two.gpc:

  Press X (Square on PlayStation) to shoot. GLCRY METER waits briefly, then
  holds X for the shot's hold time and lets go for you.

    Fade Left  : RT (R2) held + left stick in the left half
    Fade Right : RT (R2) held + left stick in the right half
    Standard   : anything else

  Pause before the shot: 125 ms standard, 100 ms fade. The fade direction is
  locked the moment X is pressed; during a fade the left stick is forced fully
  left/right and RT is held for the whole shot.

  Two profiles, OFFLINE and ONLINE, each with its own three hold times.
  Hold LT + press View (L2 + Share) to switch profile in game.

Runs inside the virtual controller's 1000 Hz loop, so timing is to the
millisecond. Values use GLCRY METER's controller layout (0..100 / -100..100).
"""

import threading
import time

X, RT, LT, VIEW, LX, LY = 16, 4, 7, 1, 23, 24
RT_THRESHOLD = 10
FADE_DEADZONE = 10
VAL_MIN, VAL_MAX = 50, 2000

DEFAULTS = {
    "profile": "offline",
    "offline": {"shot": 505, "fade_left": 771, "fade_right": 771},
    "online": {"shot": 607, "fade_left": 811, "fade_right": 811},
    "shot_wait": 125,
    "fade_wait": 100,
}

KIND_NAMES = {"shot": "Standard", "fade_left": "Fade left", "fade_right": "Fade right"}


def clamp(v):
    return max(VAL_MIN, min(VAL_MAX, int(v)))


def load(cfg):
    """Macro settings from app.json's "macro" entry, filled in with defaults."""
    m = cfg.get("macro") if isinstance(cfg.get("macro"), dict) else {}
    out = {"profile": "online" if m.get("profile") == "online" else "offline",
           "shot_wait": int(m.get("shot_wait", DEFAULTS["shot_wait"])),
           "fade_wait": int(m.get("fade_wait", DEFAULTS["fade_wait"]))}
    for p in ("offline", "online"):
        src = m.get(p) if isinstance(m.get(p), dict) else {}
        out[p] = {k: clamp(src.get(k, DEFAULTS[p][k])) for k in ("shot", "fade_left", "fade_right")}
    return out


class ShotMacro:
    def __init__(self, settings, log=None):
        self.s = settings
        self.log = log
        self.enabled = False
        self.lock = threading.Lock()
        self.changed = False          # profile switched in game -> app saves it
        self.last = ""                # "Fade left 771 ms" - for the status line
        self._t0 = None               # time X was pressed for the shot in flight
        self._wait = 0.0
        self._hold = 0.0
        self._fade = 0
        self._lock_x = False
        self._prev_x = False
        self._prev_view = False

    # ------------------------------------------------------------------ edit
    def update(self, settings):
        with self.lock:
            self.s = settings

    def profile(self):
        return self.s["profile"]

    def times(self):
        return self.s[self.s["profile"]]

    # ------------------------------------------------------------------ run
    def running(self):
        return self._t0 is not None

    def apply(self, v, now=None):
        """Modify one controller snapshot `v` (list) in place."""
        if not self.enabled:
            self._t0, self._lock_x = None, False
            self._prev_x = v[X] >= 50
            return v
        now = time.perf_counter() if now is None else now
        with self.lock:
            x_down = v[X] >= 50
            press = x_down and not self._prev_x
            self._prev_x = x_down

            # LT + View: switch OFFLINE / ONLINE (View is kept from the game)
            lt = v[LT] > RT_THRESHOLD
            view = v[VIEW] >= 50
            if lt and view and not self._prev_view:
                self.s["profile"] = "online" if self.s["profile"] == "offline" else "offline"
                self.changed = True
                if self.log:
                    self.log.write("Macro profile: %s" % self.s["profile"].upper())
            self._prev_view = view
            if lt and view:
                v[VIEW] = 0.0

            # start a shot
            if press and self._t0 is None:
                t = self.times()
                kind, wait = "shot", self.s["shot_wait"]
                self._fade = 0
                if v[RT] > RT_THRESHOLD:
                    if v[LX] < -FADE_DEADZONE:
                        kind, wait, self._fade = "fade_left", self.s["fade_wait"], -100
                    elif v[LX] > FADE_DEADZONE:
                        kind, wait, self._fade = "fade_right", self.s["fade_wait"], 100
                self._t0 = now
                self._wait = wait / 1000.0
                self._hold = t[kind] / 1000.0
                self._lock_x = True
                self.last = "%s %d ms (%s)" % (KIND_NAMES[kind], t[kind], self.s["profile"].upper())

            # shot in flight: wait, hold X, let go
            if self._t0 is not None:
                el = now - self._t0
                if el < self._wait:
                    v[X] = 0.0
                elif el < self._wait + self._hold:
                    v[X] = 100.0
                else:
                    v[X] = 0.0
                    self._t0 = None
                if self._fade and self._t0 is not None:
                    v[LX], v[LY], v[RT] = float(self._fade), 0.0, 100.0
            elif self._lock_x:
                # block the real X until it's let go, so the game sees one press
                if x_down:
                    v[X] = 0.0
                else:
                    self._lock_x = False
        return v
