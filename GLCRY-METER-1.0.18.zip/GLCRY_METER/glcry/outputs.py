"""Controller input and the two outputs (virtual controller, Titan Two).

Values use the Helios / Titan Two identifiers (see compat/helios/controls.py).
The CV packet is the Helios 'Creative' layout scripts already write:
  byte 11+i  button i:  low bit set = override, value = byte & 0xFE (0..100)
  byte 28+k  stick k (0 right X, 1 right Y, 2 left X, 3 left Y):
             low bit set = override, value = (byte & 0xFE) - 100
  byte 32+4k same stick as big-endian 16.16 fixed point (finer)
Byte 1 (GLCRY METER): bit0 = Titan Two holds an override-to-0 until the button is
physically let go (needed because in Titan mode the PC reads the Titan's output).
"""

import ctypes
import socket
import struct
import sys
import threading
import time

BUTTON_OFFSET = 11
LEGACY_STICK_OFFSET = 28
PRECISION_STICK_OFFSET = 32
PACKET_SIZE = 48
N_BUTTONS = 21
STICK_IDS = (21, 22, 23, 24)          # STICK_1_X, STICK_1_Y, STICK_2_X, STICK_2_Y
FLAG_LATCH = 0x01

BUTTON_NAMES = ["Guide", "View", "Menu", "RB", "RT", "RS", "LB", "LT", "LS",
                "Up", "Down", "Left", "Right", "Y", "B", "A", "X", "B18", "B19", "B20", "B21"]


def decode_packet(pkt):
    """-> (button overrides {id: 0..100}, stick overrides {id: -100..100})."""
    b_ov, s_ov = {}, {}
    if not pkt or len(pkt) < PACKET_SIZE:
        return b_ov, s_ov
    for i in range(N_BUTTONS):
        v = pkt[BUTTON_OFFSET + i]
        if v & 1:
            b_ov[i] = float(min(100, v & 0xFE))
    for k in range(4):
        v = pkt[LEGACY_STICK_OFFSET + k]
        if v & 1:
            fine = struct.unpack_from(">i", pkt, PRECISION_STICK_OFFSET + 4 * k)[0] / 65536.0
            coarse = float((v & 0xFE) - 100)
            s_ov[STICK_IDS[k]] = fine if abs(fine - coarse) <= 2.0 else coarse
    return b_ov, s_ov


# ----------------------------------------------------------------------------
# XInput (Xbox-style controllers, and the Titan Two's output as Windows sees it)
# ----------------------------------------------------------------------------
class _GAMEPAD(ctypes.Structure):
    _fields_ = [("wButtons", ctypes.c_ushort), ("bLeftTrigger", ctypes.c_ubyte),
                ("bRightTrigger", ctypes.c_ubyte), ("sThumbLX", ctypes.c_short),
                ("sThumbLY", ctypes.c_short), ("sThumbRX", ctypes.c_short),
                ("sThumbRY", ctypes.c_short)]


class _STATE(ctypes.Structure):
    # XInputGetStateEx (ordinal 100) can write a 4-byte reserved field after
    # the gamepad block; the padding keeps that from overwriting memory.
    _fields_ = [("dwPacketNumber", ctypes.c_uint), ("Gamepad", _GAMEPAD), ("_reserved", ctypes.c_uint * 4)]


# XInput bit -> Titan button id
_XI_BITS = [(0x0400, 0), (0x0020, 1), (0x0010, 2), (0x0200, 3), (0x0080, 5), (0x0100, 6),
            (0x0040, 8), (0x0001, 9), (0x0002, 10), (0x0004, 11), (0x0008, 12),
            (0x8000, 13), (0x2000, 14), (0x1000, 15), (0x4000, 16)]


class XInputReader:
    def __init__(self, slot=0):
        self.slot = int(slot)
        self.ok = False
        self.connected = False
        self.values = [0.0] * 40
        self._get = None
        if sys.platform != "win32":
            return
        for dll in ("xinput1_4", "xinput1_3", "xinput9_1_0"):
            try:
                lib = ctypes.WinDLL(dll)
            except OSError:
                continue
            fn = None
            try:
                fn = lib[100]            # XInputGetStateEx: includes the Guide button
            except Exception:
                fn = None
            if fn is None:
                fn = lib.XInputGetState
            fn.argtypes = [ctypes.c_uint, ctypes.POINTER(_STATE)]
            fn.restype = ctypes.c_uint
            self._get = fn
            self.ok = True
            break
        self._st = _STATE()

    def poll(self):
        if not self.ok:
            self.connected = False
            return self.values
        r = self._get(self.slot, ctypes.byref(self._st))
        if r != 0:
            if self.connected:
                self.values = [0.0] * 40
            self.connected = False
            return self.values
        self.connected = True
        g = self._st.Gamepad
        v = [0.0] * 40
        for bit, idx in _XI_BITS:
            if g.wButtons & bit:
                v[idx] = 100.0
        v[4] = g.bRightTrigger * 100.0 / 255.0
        v[7] = g.bLeftTrigger * 100.0 / 255.0
        v[21] = max(-100.0, g.sThumbRX / 327.67)
        v[22] = max(-100.0, -g.sThumbRY / 327.67)       # Titan: +Y = down
        v[23] = max(-100.0, g.sThumbLX / 327.67)
        v[24] = max(-100.0, -g.sThumbLY / 327.67)
        self.values = v
        return v


# ----------------------------------------------------------------------------
# Direct controller reading (raw HID)
# ----------------------------------------------------------------------------
# While your controller is hidden from games, Windows' usual way of reading an
# Xbox pad (XInput) can be hidden from GLCRY METER too, because Windows reads
# it through a system service rather than inside GLCRY METER. HidHide lets
# GLCRY METER itself open the controller, so we read its raw HID reports
# directly - the same approach tools like DS4Windows use.

if sys.platform == "win32":
    from ctypes import wintypes

    class _GUID(ctypes.Structure):
        _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_ushort),
                    ("Data3", ctypes.c_ushort), ("Data4", ctypes.c_ubyte * 8)]

    class _SP_DEVICE_INTERFACE_DATA(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("InterfaceClassGuid", _GUID),
                    ("Flags", wintypes.DWORD), ("Reserved", ctypes.c_size_t)]

    class _HIDD_ATTRIBUTES(ctypes.Structure):
        _fields_ = [("Size", ctypes.c_uint32), ("VendorID", ctypes.c_ushort),
                    ("ProductID", ctypes.c_ushort), ("VersionNumber", ctypes.c_ushort)]


class _HIDP_CAPS(ctypes.Structure):
    _fields_ = [("Usage", ctypes.c_ushort), ("UsagePage", ctypes.c_ushort),
                ("InputReportByteLength", ctypes.c_ushort), ("OutputReportByteLength", ctypes.c_ushort),
                ("FeatureReportByteLength", ctypes.c_ushort), ("Reserved", ctypes.c_ushort * 17),
                ("NumberLinkCollectionNodes", ctypes.c_ushort),
                ("NumberInputButtonCaps", ctypes.c_ushort), ("NumberInputValueCaps", ctypes.c_ushort),
                ("NumberInputDataIndices", ctypes.c_ushort),
                ("NumberOutputButtonCaps", ctypes.c_ushort), ("NumberOutputValueCaps", ctypes.c_ushort),
                ("NumberOutputDataIndices", ctypes.c_ushort),
                ("NumberFeatureButtonCaps", ctypes.c_ushort), ("NumberFeatureValueCaps", ctypes.c_ushort),
                ("NumberFeatureDataIndices", ctypes.c_ushort)]


class _HIDP_VALUE_CAPS(ctypes.Structure):
    _fields_ = [("UsagePage", ctypes.c_ushort), ("ReportID", ctypes.c_ubyte), ("IsAlias", ctypes.c_ubyte),
                ("BitField", ctypes.c_ushort), ("LinkCollection", ctypes.c_ushort),
                ("LinkUsage", ctypes.c_ushort), ("LinkUsagePage", ctypes.c_ushort),
                ("IsRange", ctypes.c_ubyte), ("IsStringRange", ctypes.c_ubyte),
                ("IsDesignatorRange", ctypes.c_ubyte), ("IsAbsolute", ctypes.c_ubyte),
                ("HasNull", ctypes.c_ubyte), ("Reserved", ctypes.c_ubyte),
                ("BitSize", ctypes.c_ushort), ("ReportCount", ctypes.c_ushort),
                ("Reserved2", ctypes.c_ushort * 5), ("UnitsExp", ctypes.c_uint32), ("Units", ctypes.c_uint32),
                ("LogicalMin", ctypes.c_int32), ("LogicalMax", ctypes.c_int32),
                ("PhysicalMin", ctypes.c_int32), ("PhysicalMax", ctypes.c_int32),
                ("u", ctypes.c_ushort * 8)]          # NotRange: u[0] = Usage; Range: u[0..1] = UsageMin/Max


# HID button number -> Titan index (Xbox HID order: A B X Y LB RB View Menu LS RS)
_HID_BUTTONS = {1: 15, 2: 14, 3: 16, 4: 13, 5: 6, 6: 3, 7: 1, 8: 2, 9: 8, 10: 5}
# PlayStation pads (DualShock 4 / DualSense / DualSense Edge, Sony vendor 054C):
# Square Cross Circle Triangle L1 R1 L2 R2 Share/Create Options L3 R3 PS Touchpad
_PS_BUTTONS = {1: 16, 2: 15, 3: 14, 4: 13, 5: 6, 6: 3, 9: 1, 10: 2, 11: 8, 12: 5, 13: 0, 14: 17}
SONY_VID = 0x054C
_HAT_DIRS = [(9,), (9, 12), (12,), (10, 12), (10,), (10, 11), (11,), (9, 11)]   # N NE E SE S SW W NW
_GD_X, _GD_Y, _GD_Z, _GD_RX, _GD_RY, _GD_RZ, _GD_HAT = 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x39
_SIM_ACCEL, _SIM_BRAKE = 0xC4, 0xC5


def _norm(v, lo, hi):
    """Raw HID axis value -> -100..100."""
    if hi <= lo:
        return 0.0
    mid = (lo + hi) / 2.0
    return max(-100.0, min(100.0, (v - mid) / ((hi - lo) / 2.0) * 100.0))


def _trig(val, lo, hi):
    return max(0.0, min(100.0, (val - lo) * 100.0 / max(1, hi - lo)))


def hid_values(axes, buttons, hat, playstation=False):
    """Turn decoded HID data into GLCRY METER's 40-value controller layout.
    axes: {usage: (value, lo, hi)} with keys like _GD_X or ("sim", 0xC4).
    playstation: Sony layout (right stick on Z/Rz, analog L2/R2 on Rx/Ry)."""
    v = [0.0] * 40
    bmap = _PS_BUTTONS if playstation else _HID_BUTTONS
    for b in buttons:
        if b in bmap:
            v[bmap[b]] = 100.0
    if hat is not None:
        val, lo, hi = hat
        i = val - lo
        if 0 <= i < 8 and (hi - lo) >= 7:
            for idx in _HAT_DIRS[i]:
                v[idx] = 100.0
    if _GD_X in axes:
        v[23] = _norm(*axes[_GD_X])
    if _GD_Y in axes:
        v[24] = _norm(*axes[_GD_Y])              # HID: up = minimum -> -100, same as ours
    if playstation:
        if _GD_Z in axes:
            v[21] = _norm(*axes[_GD_Z])
        if _GD_RZ in axes:
            v[22] = _norm(*axes[_GD_RZ])
        if _GD_RX in axes:
            v[7] = _trig(*axes[_GD_RX])          # L2
        if _GD_RY in axes:
            v[4] = _trig(*axes[_GD_RY])          # R2
        for b, idx in ((7, 7), (8, 4)):          # digital L2/R2 if the analog value is missing
            if b in buttons and v[idx] < 1.0:
                v[idx] = 100.0
        return v
    if _GD_RX in axes:
        v[21] = _norm(*axes[_GD_RX])
    if _GD_RY in axes:
        v[22] = _norm(*axes[_GD_RY])
    if ("sim", _SIM_BRAKE) in axes or ("sim", _SIM_ACCEL) in axes:
        if ("sim", _SIM_BRAKE) in axes:          # separate triggers (Bluetooth Xbox pads)
            val, lo, hi = axes[("sim", _SIM_BRAKE)]
            v[7] = max(0.0, min(100.0, (val - lo) * 100.0 / max(1, hi - lo)))
        if ("sim", _SIM_ACCEL) in axes:
            val, lo, hi = axes[("sim", _SIM_ACCEL)]
            v[4] = max(0.0, min(100.0, (val - lo) * 100.0 / max(1, hi - lo)))
    elif _GD_Z in axes:
        # Both triggers share one axis on USB Xbox pads: left trigger moves it
        # one way, right trigger the other (pressing both reads as neither).
        z = _norm(*axes[_GD_Z])
        if HidPadReader.Z_SIGN > 0:
            v[7], v[4] = max(0.0, -z), max(0.0, z)
        else:
            v[7], v[4] = max(0.0, z), max(0.0, -z)
    return v


class HidPadReader:
    """Reads one game controller's raw HID reports on its own thread.
    Same interface as XInputReader (poll(), values, connected, ok, slot)."""

    Z_SIGN = 1        # +1: left trigger = low end of the shared axis (Windows' usual mapping)

    def __init__(self, path, log=None, name="controller", vid=0):
        self.slot = -1
        self.path = path
        self.playstation = vid == SONY_VID
        self.name = name
        self.log = log
        self.ok = sys.platform == "win32"
        self.connected = False
        self.values = [0.0] * 40
        self.running = self.ok
        if self.ok:
            threading.Thread(target=self._loop, name="hidpad", daemon=True).start()

    def poll(self):
        return self.values

    def close(self):
        self.running = False

    # -- Windows plumbing --------------------------------------------------
    def _open(self):
        k32 = ctypes.windll.kernel32
        k32.CreateFileW.restype = wintypes.HANDLE
        k32.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
                                    wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
        h = k32.CreateFileW(self.path, 0x80000000, 0x1 | 0x2, None, 3, 0, None)   # GENERIC_READ, share R/W
        if not h or h == wintypes.HANDLE(-1).value:
            return None
        return h

    def _loop(self):
        hid = ctypes.windll.hid
        k32 = ctypes.windll.kernel32
        while self.running:
            h = self._open()
            if h is None:
                self.connected = False
                self.values = [0.0] * 40
                time.sleep(1.0)
                continue
            pp = ctypes.c_void_p()
            try:
                if not hid.HidD_GetPreparsedData(wintypes.HANDLE(h), ctypes.byref(pp)):
                    raise OSError("no HID data")
                caps = _HIDP_CAPS()
                hid.HidP_GetCaps(pp, ctypes.byref(caps))
                n = ctypes.c_ushort(caps.NumberInputValueCaps)
                vcaps = (_HIDP_VALUE_CAPS * max(1, n.value))()
                hid.HidP_GetValueCaps(0, vcaps, ctypes.byref(n), pp)
                axes_caps = []               # (page, usage, lo, hi)
                for i in range(n.value):
                    c = vcaps[i]
                    usages = range(c.u[0], c.u[1] + 1) if c.IsRange else [c.u[0]]
                    for u in usages:
                        axes_caps.append((c.UsagePage, u, c.LogicalMin, c.LogicalMax))
                rlen = caps.InputReportByteLength
                buf = ctypes.create_string_buffer(rlen)
                got = wintypes.DWORD()
                ulist = (ctypes.c_ushort * 32)()
                while self.running:
                    if not k32.ReadFile(wintypes.HANDLE(h), buf, rlen, ctypes.byref(got), None):
                        break                # unplugged or restarted
                    self.connected = True
                    axes, hat = {}, None
                    for page, u, lo, hi in axes_caps:
                        val = ctypes.c_uint32()
                        if hid.HidP_GetUsageValue(0, page, 0, u, ctypes.byref(val), pp, buf, rlen) != 0x00110000:
                            continue
                        x = val.value
                        if lo < 0 and x > hi:        # signed field
                            x -= 1 << 32
                        if page == 0x01 and u == _GD_HAT:
                            hat = (x, lo, hi)
                        elif page == 0x01:
                            axes[u] = (x, lo, hi)
                        elif page == 0x02:
                            axes[("sim", u)] = (x, lo, hi)
                    cnt = ctypes.c_uint32(32)
                    pressed = []
                    if hid.HidP_GetUsages(0, 0x09, 0, ulist, ctypes.byref(cnt), pp, buf, rlen) == 0x00110000:
                        pressed = [ulist[i] for i in range(cnt.value)]
                    self.values = hid_values(axes, pressed, hat, self.playstation)
            except Exception as exc:
                if self.log:
                    self.log.write("Direct controller read error: %s" % exc)
            finally:
                if pp:
                    hid.HidD_FreePreparsedData(pp)
                k32.CloseHandle(wintypes.HANDLE(h))
            self.connected = False
            self.values = [0.0] * 40
            time.sleep(0.5)


def list_hid_gamepads():
    """[(device path, vendor id, product id)] for game controllers GLCRY METER can open."""
    if sys.platform != "win32":
        return []
    hid, setup, k32 = ctypes.windll.hid, ctypes.windll.setupapi, ctypes.windll.kernel32
    setup.SetupDiGetClassDevsW.restype = wintypes.HANDLE
    setup.SetupDiGetClassDevsW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR, wintypes.HWND, wintypes.DWORD]
    setup.SetupDiEnumDeviceInterfaces.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p,
                                                  wintypes.DWORD, ctypes.c_void_p]
    setup.SetupDiGetDeviceInterfaceDetailW.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p,
                                                       wintypes.DWORD, ctypes.POINTER(wintypes.DWORD),
                                                       ctypes.c_void_p]
    setup.SetupDiDestroyDeviceInfoList.argtypes = [wintypes.HANDLE]
    k32.CreateFileW.restype = wintypes.HANDLE
    k32.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
                                wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    guid = _GUID()
    hid.HidD_GetHidGuid(ctypes.byref(guid))
    info = setup.SetupDiGetClassDevsW(ctypes.byref(guid), None, None, 0x02 | 0x10)  # PRESENT | DEVICEINTERFACE
    out = []
    if not info or info == wintypes.HANDLE(-1).value:
        return out
    try:
        i = 0
        while True:
            ifd = _SP_DEVICE_INTERFACE_DATA()
            ifd.cbSize = ctypes.sizeof(_SP_DEVICE_INTERFACE_DATA)
            if not setup.SetupDiEnumDeviceInterfaces(info, None, ctypes.byref(guid), i, ctypes.byref(ifd)):
                break
            i += 1
            need = wintypes.DWORD()
            setup.SetupDiGetDeviceInterfaceDetailW(info, ctypes.byref(ifd), None, 0, ctypes.byref(need), None)
            if not need.value:
                continue
            buf = ctypes.create_string_buffer(need.value)
            ctypes.c_uint32.from_buffer(buf).value = 8 if ctypes.sizeof(ctypes.c_void_p) == 8 else 6
            if not setup.SetupDiGetDeviceInterfaceDetailW(info, ctypes.byref(ifd), buf, need, None, None):
                continue
            path = ctypes.wstring_at(ctypes.addressof(buf) + 4)
            h = k32.CreateFileW(path, 0, 0x1 | 0x2, None, 3, 0, None)          # query only
            if not h or h == wintypes.HANDLE(-1).value:
                continue
            try:
                attr = _HIDD_ATTRIBUTES()
                attr.Size = ctypes.sizeof(_HIDD_ATTRIBUTES)
                hid.HidD_GetAttributes(wintypes.HANDLE(h), ctypes.byref(attr))
                pp = ctypes.c_void_p()
                if hid.HidD_GetPreparsedData(wintypes.HANDLE(h), ctypes.byref(pp)):
                    caps = _HIDP_CAPS()
                    hid.HidP_GetCaps(pp, ctypes.byref(caps))
                    hid.HidD_FreePreparsedData(pp)
                    if caps.UsagePage == 0x01 and caps.Usage in (0x04, 0x05):       # joystick / gamepad
                        out.append((path, attr.VendorID, attr.ProductID))
            finally:
                k32.CloseHandle(wintypes.HANDLE(h))
    finally:
        setup.SetupDiDestroyDeviceInfoList(info)
    return out


def _raw_thumbs(slot):
    """(connected, sThumbLX, sThumbRY) straight from XInput, for finding our own pad."""
    r = XInputReader(slot)
    if not r.ok:
        return False, 0, 0
    if r._get(slot, ctypes.byref(r._st)) != 0:
        return False, 0, 0
    g = r._st.Gamepad
    return True, g.sThumbLX, g.sThumbRY



def xinput_slots_status():
    """[(slot, connected)] for the 4 XInput slots."""
    out = []
    for s in range(4):
        r = XInputReader(s)
        r.poll()
        out.append((s, r.connected))
    return out


# ----------------------------------------------------------------------------
# Outputs
# ----------------------------------------------------------------------------
def pick_input_slot(current, exclude=None):
    """Keep the current slot if a controller is on it, else the first connected
    one (skipping our own virtual pad). None if nothing is connected."""
    st = dict(xinput_slots_status())
    if st.get(current) and current != exclude:
        return current
    for sl in range(4):
        if st.get(sl) and sl != exclude:
            return sl
    return None


class PreviewOutput:
    """No controller output: read a pad so scripts see input, send nothing."""

    name = "Preview only"
    virtual_slot = None
    macro = None            # glcry.macro.ShotMacro when the shot macro is in use

    def __init__(self, log, slot=0):
        self.log = log
        self.reader = XInputReader(slot)
        self.lock = threading.Lock()
        self.packet = bytes(PACKET_SIZE)
        self.status = "Preview: script runs, nothing is sent to the game"

    def get_actual(self, identifier):
        v = self.reader.poll()
        return v[identifier] if 0 <= identifier < len(v) else 0.0

    def send_cvdata(self, data):
        self.packet = data

    def output_values(self):
        v = list(self.reader.values)
        b, s = decode_packet(self.packet)
        for k, x in b.items():
            v[k] = x
        for k, x in s.items():
            v[k] = x
        return v

    def close(self):
        pass


class VirtualPadOutput(PreviewOutput):
    """Your real controller -> GLCRY METER -> a virtual Xbox 360 controller (ViGEm).

    Passthrough runs at ~1000 Hz on its own thread; script overrides are
    applied the moment the script sends them. Hide the real controller from
    the game with HidHide so it only sees the virtual one."""

    name = "Virtual controller"

    def __init__(self, log, slot=0):
        super().__init__(log, slot)
        self.pad = None
        self.vg = None
        self.virtual_slot = None
        self.hidden = False
        self.hide_error = ""
        # Hide the real controller from the game first, so the game only sees
        # the virtual pad (made next, so it stays visible).
        try:
            from . import hidhide
            r = hidhide.request("on", log)
            self.hidden = bool(r.get("ok"))
            self.hide_error = r.get("error") or ""
            log.write("Controller hiding: %s" % (("on - hid " + ", ".join(r.get("hidden") or []))
                                                 if self.hidden else "FAILED - " + self.hide_error))
            if self.hidden:
                log.write("If 2K21 was already open, unplug your controller and plug it back in once "
                          "so the game stops reading it directly.")
        except Exception as exc:
            self.hide_error = str(exc)
            log.write("Controller hiding: FAILED - %s" % exc)
        self.direct = False
        real_hid = []
        if self.hidden:
            # hiding restarts your controller: wait for it to come back, then
            # note which controllers are real (before the virtual pad exists)
            t_end = time.time() + 10.0
            time.sleep(0.5)
            while time.time() < t_end:
                try:
                    real_hid = list_hid_gamepads()
                except Exception:
                    real_hid = []
                if real_hid or any(c for _, c in xinput_slots_status()):
                    break
                time.sleep(0.3)
        before = {sl for sl, c in xinput_slots_status() if c}
        self.status = "Virtual controller: starting"
        try:
            import vgamepad as vg
            self.vg = vg
            self.pad = vg.VX360Gamepad()
            self.status = ("Virtual controller: running (Xbox 360 pad via ViGEm)" if self.hidden else
                           "Virtual pad running, but your real controller couldn't be hidden from the game: "
                           + self.hide_error)
        except Exception as exc:
            self.status = "Virtual controller unavailable: %s (install ViGEmBus + 'pip install vgamepad')" % exc
            log.write(self.status)
        self._b_ov, self._s_ov = {}, {}
        self.running = self.pad is not None
        self.rate_hz = 0.0
        if self.running:
            self._find_virtual_slot(before)
            self._choose_reader(real_hid)
            self.thread = threading.Thread(target=self._loop, name="vpad", daemon=True)
            self.thread.start()

    MARK_LX, MARK_RY = 1234, -1234     # tiny stick values inside every deadzone

    def _find_virtual_slot(self, before):
        """Which XInput slot is our own virtual pad? Give it a tell-tale stick
        position (too small for any game to notice) and see where it shows up."""
        rep = self.pad.report
        try:
            rep.sThumbLX, rep.sThumbRY = self.MARK_LX, self.MARK_RY
            self.pad.update()
            t_end = time.time() + 3.0
            while time.time() < t_end and self.virtual_slot is None:
                time.sleep(0.05)
                for sl in range(4):
                    ok, lx, ry = _raw_thumbs(sl)
                    if ok and lx == self.MARK_LX and ry == self.MARK_RY:
                        self.virtual_slot = sl
                        break
        except Exception as exc:
            self.log.write("Virtual controller: slot check failed (%s)" % exc)
        finally:
            try:
                rep.sThumbLX = rep.sThumbRY = 0
                self.pad.update()
            except Exception:
                pass
        if self.virtual_slot is None:
            new = [sl for sl, c in xinput_slots_status() if c and sl not in before]
            if len(new) == 1:
                self.virtual_slot = new[0]
        if self.virtual_slot is not None:
            self.log.write("Virtual controller is on slot %d" % (self.virtual_slot + 1))

    def _choose_reader(self, real_hid):
        """Read your controller through XInput if GLCRY METER can still see it
        there; otherwise (hidden) read it directly."""
        others = [sl for sl, c in xinput_slots_status() if c and sl != self.virtual_slot]
        if others and self.virtual_slot is not None:
            self.reader.slot = others[0] if self.reader.slot not in others else self.reader.slot
            self.log.write("Reading your controller on slot %d" % (self.reader.slot + 1))
            return
        if real_hid:
            path, vid, pid = real_hid[0]
            self.reader = HidPadReader(path, self.log, vid=vid)
            self.direct = True
            self.log.write("Reading your %scontroller directly (VID %04X PID %04X)"
                           % ("PlayStation " if vid == SONY_VID else "", vid, pid))
            return
        self.log.write("Your controller wasn't found - plug it in, then press Controller setup")

    def send_cvdata(self, data):
        self.packet = data
        b, s = decode_packet(data)
        changed = (b != self._b_ov) or (s != self._s_ov)
        self._b_ov, self._s_ov = b, s
        if changed and self.running:
            self._push(self.reader.values)       # apply overrides immediately

    def _push(self, phys):
        with self.lock:
            v = list(phys)
            m = self.macro
            if m is not None:
                m.apply(v)
            for k, x in self._b_ov.items():
                v[k] = x
            for k, x in self._s_ov.items():
                v[k] = x
            self._write(v)

    def _write(self, v):
        rep = self.pad.report
        bits = 0
        for bit, idx in _XI_BITS:
            if v[idx] >= 50.0:
                bits |= bit
        rep.wButtons = bits
        rep.bLeftTrigger = int(max(0, min(255, round(v[7] * 2.55))))
        rep.bRightTrigger = int(max(0, min(255, round(v[4] * 2.55))))

        def ax(x, invert=False):
            x = max(-100.0, min(100.0, -x if invert else x))
            return int(max(-32768, min(32767, round(x * 327.67))))
        rep.sThumbLX, rep.sThumbLY = ax(v[23]), ax(v[24], True)
        rep.sThumbRX, rep.sThumbRY = ax(v[21]), ax(v[22], True)
        self.pad.update()

    def _loop(self):
        n, t_win = 0, time.perf_counter()
        period = 0.001
        nxt = time.perf_counter()
        while self.running:
            phys = self.reader.poll()
            try:
                self._push(phys)
            except Exception as exc:
                self.log.write("Virtual controller error: %s" % exc)
                time.sleep(0.05)
            n += 1
            now = time.perf_counter()
            if now - t_win >= 1.0:
                self.rate_hz = n / (now - t_win)
                n, t_win = 0, now
            nxt += period
            d = nxt - time.perf_counter()
            if d > 0:
                time.sleep(d)
            else:
                nxt = time.perf_counter()

    def close(self):
        self.running = False
        try:
            if self.pad is not None:
                self.pad.reset()
                self.pad.update()
        except Exception:
            pass
        if self.direct:
            try:
                self.reader.close()
            except Exception:
                pass
        # remove the virtual pad now (not whenever Python gets round to it), so
        # it's gone before a new output hides controllers
        vslot = self.virtual_slot
        self.pad = None
        try:
            import gc
            gc.collect()
            t_end = time.time() + 1.5
            while vslot is not None and time.time() < t_end and _raw_thumbs(vslot)[0]:
                time.sleep(0.1)
        except Exception:
            pass
        if self.hidden:                 # give the game your real controller back
            self.hidden = False
            try:
                from . import hidhide
                hidhide.request("off", self.log, timeout=8.0)
            except Exception:
                pass


class TitanOutput(PreviewOutput):
    """Sends the packet to GLCRY METER's Gtuner IV bridge (GLCRY_METER_GtunerBridge.py)
    over localhost UDP; the bridge hands it to the Titan Two each Gtuner
    frame and GLCRY_METER_Bridge.gpc applies it.

    Controller input is read from the Titan Two's output as Windows sees it
    (its XInput slot), so the Titan holds a forced release until you let go of
    the button (latch flag) - otherwise the script would see the release as
    you letting go and the game would get a second press."""

    name = "Titan Two (Gtuner IV)"

    def __init__(self, log, slot=0, port=47654, latch=True):
        super().__init__(log, slot)
        self.port = int(port)
        self.latch = bool(latch)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.ack = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.bridge_fps = 0.0
        self.bridge_seen = 0.0
        try:
            self.ack.bind(("127.0.0.1", self.port + 1))
            self.ack.setblocking(False)
        except OSError:
            self.ack = None
        self.running = True
        self.status = "Titan Two: waiting for the Gtuner IV bridge script"
        self.thread = threading.Thread(target=self._loop, name="titan", daemon=True)
        self.thread.start()

    def send_cvdata(self, data):
        pkt = bytearray(data[:PACKET_SIZE].ljust(PACKET_SIZE, b"\0"))
        if self.latch:
            pkt[1] |= FLAG_LATCH
        self.packet = bytes(pkt)
        try:
            self.sock.sendto(self.packet, ("127.0.0.1", self.port))
        except OSError:
            pass

    def _loop(self):
        # keep the bridge fed when the script isn't sending (e.g. no video),
        # and read the bridge's heartbeat for the status line
        while self.running:
            try:
                self.sock.sendto(self.packet, ("127.0.0.1", self.port))
            except OSError:
                pass
            if self.ack is not None:
                try:
                    while True:
                        msg, _ = self.ack.recvfrom(64)
                        if msg.startswith(b"GLCR"):
                            try:
                                self.bridge_fps = float(msg[4:].decode() or 0)
                            except ValueError:
                                self.bridge_fps = 0.0
                            self.bridge_seen = time.perf_counter()
                except (BlockingIOError, OSError):
                    pass
            age = time.perf_counter() - self.bridge_seen
            if self.bridge_seen and age < 2.0:
                self.status = "Titan Two: bridge connected (Gtuner %.0f fps)" % self.bridge_fps
            else:
                self.status = "Titan Two: waiting for the Gtuner IV bridge script"
            time.sleep(0.01)

    def close(self):
        self.running = False
        try:
            self.sock.sendto(bytes(PACKET_SIZE), ("127.0.0.1", self.port))
        except OSError:
            pass
        for s in (self.sock, self.ack):
            try:
                if s is not None:
                    s.close()
            except OSError:
                pass
