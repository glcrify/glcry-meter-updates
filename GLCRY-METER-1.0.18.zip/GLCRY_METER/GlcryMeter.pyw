"""GLCRY METER - computer-vision script host with virtual-controller and Titan Two output.

Opens on a lock screen (this PC's ID + a key box). Once activated it sets
itself up: finds OBS Virtual Camera, finds the controller, starts the shot
meter. 'Advanced view' shows the full script/capture/output panels.
"""

import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

# Crash reports first, so even a missing component gives a message + report.
from glcry import crash  # noqa: E402  (standard library only)
crash.install(Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "GLCRY METER", APP_DIR)

import cv2  # noqa: E402
from PySide6.QtCore import QDir, Qt, QTimer  # noqa: E402
from PySide6.QtGui import QColor, QFont, QIcon, QImage, QPainter  # noqa: E402
try:                                    # where it lives differs between PySide6 versions
    from PySide6.QtWidgets import QFileSystemModel  # noqa: E402
except ImportError:
    from PySide6.QtGui import QFileSystemModel  # noqa: E402
from PySide6.QtWidgets import (  # noqa: E402
    QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog, QDockWidget, QFileDialog,
    QFormLayout, QFrame, QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QMessageBox, QPlainTextEdit, QPushButton, QRadioButton, QSpinBox,
    QTreeView, QVBoxLayout, QWidget)

from glcry import license as lic  # noqa: E402
from glcry import render  # noqa: E402
from glcry import macro as shotmacro  # noqa: E402
from glcry.engine import APP_NAME, Engine, Log, data_root, find_obs_camera, list_cameras  # noqa: E402
from glcry.outputs import (PreviewOutput, TitanOutput, VirtualPadOutput,  # noqa: E402
                            pick_input_slot, xinput_slots_status)

SCRIPTS_DIR = APP_DIR / "scripts"
DEFAULT_SCRIPT = SCRIPTS_DIR / "NBA2K21_Meter.py"
CONFIG = data_root() / "app.json"
try:
    VERSION = (APP_DIR / "glcry" / "version.txt").read_text().strip()
except Exception:
    VERSION = "dev"

STYLE = """
QWidget { background: #0b0f15; color: #eef1f6; font-family: 'Segoe UI'; font-size: 13px; }
QMainWindow::separator { background: #233042; width: 1px; height: 1px; }
QFrame#card { background: #141b26; border: 1px solid #233042; border-radius: 14px; }
QFrame#card QLabel { background: transparent; }
QLabel#brand { font-size: 30px; font-weight: 800; letter-spacing: 2px; }
QLabel#title { font-size: 30px; font-weight: 800; letter-spacing: 2px; }
QLabel#sub { color: #98a2b3; font-size: 14px; }
QLabel#cardTitle { color: #f2b93b; font-size: 11px; font-weight: 700; letter-spacing: 2px; }
QLabel#cardText { font-size: 15px; }
QLabel#hint { color: #98a2b3; font-size: 12px; }
QLabel#link { color: #98a2b3; font-size: 12px; }
QLabel#err { color: #ff6b6b; font-size: 13px; }
QLabel#good { color: #3ddc84; font-size: 13px; font-weight: 600; }
QLineEdit { background: #0b0f15; border: 1px solid #2d3b50; border-radius: 10px; padding: 11px; font-size: 16px;
            selection-background-color: #f2b93b; selection-color: #1a1203; }
QLineEdit:focus { border-color: #f2b93b; }
QLineEdit#hwid { font-family: Consolas; font-size: 15px; letter-spacing: 1px; color: #98a2b3; padding: 8px; }
QLineEdit#key { font-family: Consolas; font-size: 14px; color: #f2b93b; }
QPushButton { background: #19222f; border: 1px solid #2d3b50; border-radius: 10px; padding: 8px 16px; font-size: 13px; }
QPushButton:hover { background: #212c3c; border-color: #3a4b64; }
QPushButton:pressed { background: #141b26; }
QPushButton:checked { background: #2a2414; border-color: #f2b93b; color: #f2b93b; }
QPushButton#big { font-size: 15px; padding: 13px 22px; font-weight: 600; }
QPushButton#on { background: #3ddc84; border-color: #3ddc84; color: #04150b; font-size: 15px; padding: 13px 24px; font-weight: 700; }
QPushButton#on:hover { background: #57e598; }
QPushButton#off { background: #233042; border-color: #2d3b50; color: #98a2b3; font-size: 15px; padding: 13px 24px; font-weight: 700; }
QPushButton#seg { font-size: 14px; padding: 13px 18px; font-weight: 700; color: #98a2b3; }
QPushButton#seg:checked { background: #2a2414; border-color: #f2b93b; color: #f2b93b; }
QSpinBox#ms { font-family: Consolas; font-size: 18px; padding: 6px 8px; min-width: 110px; color: #f2b93b; }
QPushButton#choice { font-size: 15px; padding: 22px; text-align: left; border-radius: 14px; background: #141b26; }
QPushButton#choice:hover { border-color: #f2b93b; background: #19222f; }
QComboBox, QSpinBox, QPlainTextEdit, QTreeView { background: #0b0f15; border: 1px solid #233042; border-radius: 8px; padding: 4px; }
QComboBox QAbstractItemView { background: #141b26; selection-background-color: #233042; }
QCheckBox, QRadioButton { spacing: 8px; padding: 3px 0; }
QGroupBox { border: 1px solid #233042; border-radius: 10px; margin-top: 14px; padding-top: 10px; }
QGroupBox::title { subcontrol-origin: margin; left: 12px; color: #f2b93b; }
QDockWidget { color: #98a2b3; }
QDockWidget::title { background: #141b26; padding: 6px 8px; border-bottom: 1px solid #233042; }
QScrollBar:vertical { background: transparent; width: 10px; }
QScrollBar::handle:vertical { background: #2d3b50; border-radius: 5px; min-height: 24px; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0; width: 0; }
QToolTip { background: #19222f; color: #eef1f6; border: 1px solid #2d3b50; }
"""


def load_config():
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config(cfg):
    try:
        CONFIG.parent.mkdir(parents=True, exist_ok=True)
        CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception:
        pass


def dot(color):
    return "<span style='color:%s;font-size:18px'>&#9679;</span>" % color


GREEN, AMBER, RED, GREY = "#52d98a", "#f5b942", "#ff7676", "#6b7280"


def repolish(w):
    """Re-apply the stylesheet after changing a widget's objectName."""
    st = w.style()
    st.unpolish(w)
    st.polish(w)
    w.update()


# ----------------------------------------------------------------------------
# Lock screen
# ----------------------------------------------------------------------------
class LockPage(QWidget):
    """This PC's ID and a key box. Nothing else to click."""

    def __init__(self, on_unlock, message=None):
        super().__init__()
        self.on_unlock = on_unlock
        outer = QVBoxLayout(self)
        outer.addStretch(1)
        card = QFrame()
        card.setObjectName("card")
        card.setFixedWidth(620)
        v = QVBoxLayout(card)
        v.setContentsMargins(40, 36, 40, 36)
        v.setSpacing(10)
        t = QLabel("GLCRY <span style='color:#f2b93b'>METER</span>")
        t.setObjectName("title")
        t.setTextFormat(Qt.RichText)
        t.setAlignment(Qt.AlignCenter)
        v.addWidget(t)
        s = QLabel("Paste your key to activate this PC")
        s.setObjectName("sub")
        s.setAlignment(Qt.AlignCenter)
        v.addWidget(s)
        v.addSpacing(22)
        lab = QLabel("YOUR KEY")
        lab.setObjectName("cardTitle")
        v.addWidget(lab)
        self.key = QLineEdit()
        self.key.setObjectName("key")
        self.key.setPlaceholderText("Paste your key here (it starts with GLCRY-)")
        self.key.textChanged.connect(self.check)
        v.addWidget(self.key)
        self.msg = QLabel("Your key is on the page you saw after checkout. It locks to this PC the first time it's used.")
        self.msg.setObjectName("hint")
        self.msg.setWordWrap(True)
        v.addWidget(self.msg)
        if message:
            self._say("err", message)
        v.addSpacing(16)
        lab = QLabel("THIS PC'S ID  (only if support asks for it)")
        lab.setObjectName("cardTitle")
        v.addWidget(lab)
        self.hwid = QLineEdit(lic.this_hwid())
        self.hwid.setObjectName("hwid")
        self.hwid.setReadOnly(True)
        self.hwid.setAlignment(Qt.AlignCenter)
        self.hwid.setContextMenuPolicy(Qt.NoContextMenu)
        v.addWidget(self.hwid)
        v.addSpacing(12)
        ln = QLabel("No key yet? <a style='color:#f2b93b' href='https://glcrify.github.io/glcry-meter-updates/'>Join the beta</a>"
                    " &nbsp;&middot;&nbsp; Help: <a style='color:#f2b93b' href='https://discord.gg/glcrify'>discord.gg/glcrify</a>"
                    " &nbsp;&middot;&nbsp; Version %s" % VERSION)
        ln.setObjectName("link")
        ln.setTextFormat(Qt.RichText)
        ln.setOpenExternalLinks(True)
        ln.setAlignment(Qt.AlignCenter)
        v.addWidget(ln)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(card)
        row.addStretch(1)
        outer.addLayout(row)
        outer.addStretch(1)
        self.key.setFocus()

    def showEvent(self, e):
        super().showEvent(e)
        self.key.setFocus()

    def check(self, text):
        t = text.strip()
        if len("".join(c for c in t if c.isalnum())) < 40:
            self._say("hint", "Your key is on the page you saw after checkout. It locks to this PC the first time it's used."
                      if not t else "Keep pasting - that's not the whole key yet.")
            return
        ok, info = lic.check_key(t)
        if not ok:
            self._say("err", info)
            return
        if info.get("activate") and not lic.is_activated_here(data_root(), info["key_id"]):
            # first use: claim this key for this PC on the activation server
            self.key.setReadOnly(True)
            self._say("hint", "Activating this PC...")
            res = []
            threading.Thread(target=lambda: res.append(lic.activate_online(t)), daemon=True).start()

            def wait():
                if not res:
                    QTimer.singleShot(150, wait)
                    return
                self.key.setReadOnly(False)
                if res[0] == "ok":
                    try:
                        lic.mark_activated(data_root(), info["key_id"])
                    except Exception:
                        pass
                    self._accept(t, info)
                else:
                    self._say("err", lic.ACTIVATION_MESSAGES.get(res[0], res[0]))
            wait()
            return
        self._accept(t, info)

    def _accept(self, t, info):
        try:
            f = lic.key_file(data_root())
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text(t, encoding="utf-8")
        except Exception:
            pass
        self._say("good", "Key accepted - welcome, %s!" % (info["name"] or "player"))
        self.key.setReadOnly(True)
        QTimer.singleShot(900, lambda: self.on_unlock(info))

    def _say(self, kind, text):
        self.msg.setObjectName(kind)
        self.msg.setText(text)
        repolish(self.msg)


# ----------------------------------------------------------------------------
# Video
# ----------------------------------------------------------------------------
class VideoWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.img = None
        self.info = ""
        self.empty_text = "Waiting for video..."
        self.setMinimumSize(480, 270)
        self.setAttribute(Qt.WA_OpaquePaintEvent)

    def set_image(self, img):
        self.img = img
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(8, 9, 12))
        if self.img is not None:
            x = (self.width() - self.img.width()) // 2
            y = (self.height() - self.img.height()) // 2
            p.drawImage(x, y, self.img)
        else:
            p.setPen(QColor(130, 136, 148))
            p.setFont(QFont("Segoe UI", 13))
            p.drawText(self.rect(), Qt.AlignCenter, self.empty_text)
        if self.info:
            p.setPen(QColor(200, 205, 215))
            p.setFont(QFont("Consolas", 9))
            p.drawText(self.rect().adjusted(0, 6, -10, 0), Qt.AlignTop | Qt.AlignRight, self.info)
        p.end()


# ----------------------------------------------------------------------------
# Dialogs
# ----------------------------------------------------------------------------
class SetupDialog(QDialog):
    """'How do you play?' - two big choices."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("How do you play?")
        self.choice = None
        v = QVBoxLayout(self)
        v.setContentsMargins(28, 24, 28, 24)
        v.setSpacing(14)
        t = QLabel("How is your controller connected?")
        t.setStyleSheet("font-size: 21px; font-weight: 700;")
        v.addWidget(t)
        h = QLabel("You can change this later with <b>Controller setup</b>.")
        h.setObjectName("hint")
        h.setTextFormat(Qt.RichText)
        v.addWidget(h)
        a = QPushButton("My controller is plugged into this PC\n"
                        "USB or Bluetooth. GLCRY METER passes it to the game as a virtual controller.")
        a.setObjectName("choice")
        a.clicked.connect(lambda: self.pick(0))
        v.addWidget(a)
        b = QPushButton("I use a Titan Two\n"
                        "Needs Gtuner IV open with the GLCRY METER bridge running.")
        b.setMinimumWidth(460)
        b.setObjectName("choice")
        b.clicked.connect(lambda: self.pick(1))
        v.addWidget(b)

    def pick(self, c):
        self.choice = c
        self.accept()


class ShotSettingsDialog(QDialog):
    """The shot meter's main settings, edited in its settings file (the
    script picks changes up within a second)."""

    def __init__(self, parent, script_stem):
        super().__init__(parent)
        self.setWindowTitle("Shot settings")
        self.setMinimumWidth(460)
        d = data_root() / "ScriptData" / script_stem
        files = sorted(d.glob("settings_v*.json"), key=lambda p: p.stat().st_mtime) if d.exists() else []
        self.path = files[-1] if files else None
        self.data = {}
        if self.path:
            try:
                self.data = json.loads(self.path.read_text(encoding="utf-8"))
            except Exception:
                self.data = {}
        v = QVBoxLayout(self)
        v.setContentsMargins(24, 20, 24, 20)
        if not self.path:
            v.addWidget(QLabel("Start the shot meter once, then its settings appear here."))
            return
        t = QLabel("RELEASE TIMING")
        t.setObjectName("cardTitle")
        v.addWidget(t)
        h = QLabel("Shots coming out <b>early</b>? Press <b>-</b>.&nbsp;&nbsp; Coming out <b>late</b>? Press <b>+</b>.<br>"
                   "Changes apply to your next shot. Small steps work best.")
        h.setObjectName("hint")
        h.setTextFormat(Qt.RichText)
        v.addWidget(h)
        row = QHBoxLayout()
        for txt, d_ in (("-5", -5), ("-1", -1)):
            b = QPushButton(txt)
            b.setObjectName("big")
            b.clicked.connect(lambda _=False, d_=d_: self.bump(d_))
            row.addWidget(b)
        self.lead = QLabel()
        self.lead.setAlignment(Qt.AlignCenter)
        self.lead.setStyleSheet("font-size: 32px; font-weight: 700; min-width: 130px; color: #f2b93b;")
        row.addWidget(self.lead)
        for txt, d_ in (("+1", 1), ("+5", 5)):
            b = QPushButton(txt)
            b.setObjectName("big")
            b.clicked.connect(lambda _=False, d_=d_: self.bump(d_))
            row.addWidget(b)
        v.addLayout(row)
        v.addSpacing(10)
        t = QLabel("OPTIONS")
        t.setObjectName("cardTitle")
        v.addWidget(t)
        self.enabled = QCheckBox("Shot meter on when it starts")
        self.enabled.setChecked(bool(self.data.get("enabled_on_start", True)))
        self.enabled.toggled.connect(lambda c: self.set("enabled_on_start", bool(c)))
        v.addWidget(self.enabled)
        self.box = QCheckBox("Show the search box on the video")
        self.box.setChecked(bool(self.data.get("show_search_box", True)))
        self.box.toggled.connect(lambda c: self.set("show_search_box", bool(c)))
        v.addWidget(self.box)
        stick = QCheckBox("I shoot with the shot stick (right stick) instead of a button")
        stick.setChecked(self.data.get("shoot_mode") == "stick")
        stick.toggled.connect(lambda c: self.set("shoot_mode", "stick" if c else "button"))
        v.addWidget(stick)
        v.addSpacing(6)
        close = QPushButton("Done")
        close.setObjectName("big")
        close.clicked.connect(self.accept)
        v.addWidget(close, 0, Qt.AlignRight)
        self.show_lead()

    def last_verdict(self):
        try:
            lines = (self.path.parent / "shots_log.txt").read_text(encoding="utf-8").splitlines()
            for ln in reversed(lines[-50:]):
                rec = json.loads(ln)
                if "verdict" in rec:
                    return "Last shot: 2K said %s" % rec["verdict"]
        except Exception:
            pass
        return ""

    def set_auto(self, on):
        # one switch for both ways the script can adjust the timing
        self.set("use_2k_verdict", bool(on))
        self.set("auto_calibrate", bool(on))

    def show_lead(self):
        self.lead.setText("%d ms" % int(self.data.get("lead_ms", 40)))

    def bump(self, d):
        self.set("lead_ms", max(0, min(400, int(self.data.get("lead_ms", 40)) + d)))
        self.show_lead()

    def set(self, k, val):
        try:
            cur = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            cur = dict(self.data)
        cur[k] = val
        self.data = cur
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(cur, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)


class MacroSettingsDialog(QDialog):
    """Hold times for the STEP UP FN shot macro, per profile. Changes apply
    to the next shot and are saved straight away."""

    ROWS = (("shot", "Standard shot"), ("fade_left", "Fade left  (RT + stick left)"),
            ("fade_right", "Fade right  (RT + stick right)"))

    def __init__(self, parent, settings, on_change):
        super().__init__(parent)
        self.setWindowTitle("Macro settings")
        self.setMinimumWidth(500)
        self.s = settings
        self.on_change = on_change
        v = QVBoxLayout(self)
        v.setContentsMargins(24, 20, 24, 20)
        v.setSpacing(10)
        t = QLabel("PROFILE")
        t.setObjectName("cardTitle")
        v.addWidget(t)
        row = QHBoxLayout()
        self.pg = QButtonGroup(self)
        for i, (key, label) in enumerate((("offline", "Offline"), ("online", "Online"))):
            b = QPushButton(label)
            b.setObjectName("seg")
            b.setCheckable(True)
            b.setChecked(self.s["profile"] == key)
            self.pg.addButton(b, i)
            row.addWidget(b)
        self.pg.idClicked.connect(self.pick_profile)
        v.addLayout(row)
        h = QLabel("In game: hold <b>LT</b> and press <b>View</b> (L2 + Share) to switch.")
        h.setObjectName("hint")
        h.setTextFormat(Qt.RichText)
        v.addWidget(h)
        v.addSpacing(8)
        t = QLabel("HOLD TIMES")
        t.setObjectName("cardTitle")
        v.addWidget(t)
        h = QLabel("How long X (Square) is held. Shots <b>early</b>? Raise it. <b>Late</b>? Lower it.")
        h.setObjectName("hint")
        h.setTextFormat(Qt.RichText)
        v.addWidget(h)
        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        self.spins = {}
        for r, (key, label) in enumerate(self.ROWS):
            grid.addWidget(QLabel(label), r, 0)
            for c, d in ((1, -10), (2, -1)):
                b = QPushButton("%d" % d)
                b.clicked.connect(lambda _=False, k=key, d=d: self.bump(k, d))
                grid.addWidget(b, r, c)
            sp = QSpinBox()
            sp.setObjectName("ms")
            sp.setRange(shotmacro.VAL_MIN, shotmacro.VAL_MAX)
            sp.setSuffix(" ms")
            sp.setAlignment(Qt.AlignCenter)
            sp.valueChanged.connect(lambda val, k=key: self.set_val(k, val))
            self.spins[key] = sp
            grid.addWidget(sp, r, 3)
            for c, d in ((4, 1), (5, 10)):
                b = QPushButton("+%d" % d)
                b.clicked.connect(lambda _=False, k=key, d=d: self.bump(k, d))
                grid.addWidget(b, r, c)
        v.addLayout(grid)
        h = QLabel("Pause before the hold starts: %d ms on a standard shot, %d ms on a fade."
                   % (self.s["shot_wait"], self.s["fade_wait"]))
        h.setObjectName("hint")
        v.addWidget(h)
        row = QHBoxLayout()
        b = QPushButton("Reset this profile")
        b.clicked.connect(self.reset)
        row.addWidget(b)
        row.addStretch(1)
        done = QPushButton("Done")
        done.setObjectName("big")
        done.clicked.connect(self.accept)
        row.addWidget(done)
        v.addLayout(row)
        self.show_vals()

    def show_vals(self):
        t = self.s[self.s["profile"]]
        for k, sp in self.spins.items():
            sp.blockSignals(True)
            sp.setValue(int(t[k]))
            sp.blockSignals(False)

    def pick_profile(self, i):
        self.s["profile"] = "online" if i == 1 else "offline"
        self.show_vals()
        self.on_change()

    def set_val(self, k, val):
        self.s[self.s["profile"]][k] = shotmacro.clamp(val)
        self.on_change()

    def bump(self, k, d):
        self.spins[k].setValue(shotmacro.clamp(self.spins[k].value() + d))

    def reset(self):
        p = self.s["profile"]
        self.s[p] = dict(shotmacro.DEFAULTS[p])
        self.show_vals()
        self.on_change()


# ----------------------------------------------------------------------------
# Main window
# ----------------------------------------------------------------------------
class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1360, 860)
        self.cfg = load_config()
        self.log = Log()
        self.engine = None
        self.built = False
        self.relock_reason = None
        lic.set_data_root(data_root())
        threading.Thread(target=self._watch_revocations, daemon=True).start()
        ok, info = lic.saved_key_ok(data_root())
        if ok:
            self.unlock(info)
        else:
            msg = None
            if lic.key_file(data_root()).exists():
                k = lic.key_file(data_root()).read_text(encoding="utf-8").strip()
                r = lic.check_key(k)[1]
                msg = r if isinstance(r, str) else None
            self.setCentralWidget(LockPage(self.unlock, msg))

    # ------------------------------------------------------------- licence
    def _watch_revocations(self):
        """Fetch the owner's cancelled-keys list now and every 30 minutes; if
        this PC's key is on it, go back to the lock screen."""
        while True:
            try:
                lic.refresh_revocations()
                if lic.key_file(data_root()).exists():
                    k = lic.key_file(data_root()).read_text(encoding="utf-8").strip()
                    ok, info = lic.check_key(k)
                    if ok and info.get("activate"):
                        r = lic.activate_online(k)      # offline: keep working
                        if r in ("taken", "cancelled"):
                            self.relock_reason = lic.ACTIVATION_MESSAGES[r]
                            lic.clear_activation(data_root())
                    ok, info = lic.saved_key_ok(data_root())
                    if not ok:
                        k = lic.key_file(data_root()).read_text(encoding="utf-8").strip()
                        reason = lic.check_key(k)[1]
                        if isinstance(reason, str) and "cancelled" in reason:
                            self.relock_reason = reason
            except Exception:
                pass
            time.sleep(1800)

    def relock(self, reason):
        self.relock_reason = None
        try:
            lic.key_file(data_root()).unlink()
        except Exception:
            pass
        if self.engine is not None:
            self.engine.shutdown()
            self.engine = None
        for t in ("t_video", "t_ui"):
            if hasattr(self, t):
                getattr(self, t).stop()
        for d in getattr(self, "docks", []):
            self.removeDockWidget(d)
            d.deleteLater()
        self.docks = []
        self.built = False
        self.setCentralWidget(LockPage(self.unlock, reason))

    # ------------------------------------------------------------- unlock
    def unlock(self, info):
        self.user = info
        self.engine = Engine(self.log, None)
        self.log_seq = 0
        self.disp_seq = -1
        self.disp_n, self.disp_t, self.disp_fps = 0, time.perf_counter(), 0.0
        self.next_cam_try = 0.0
        self.no_frame_since = None
        self.meter_on = bool(self.cfg.get("meter_on", True))
        self.shot_mode = "macro" if self.cfg.get("shot_mode") == "macro" else "meter"
        self.macro = shotmacro.ShotMacro(shotmacro.load(self.cfg), self.log)
        self.selected = Path(self.cfg["script"]) if self.cfg.get("script") and Path(self.cfg["script"]).exists() \
            else (DEFAULT_SCRIPT if DEFAULT_SCRIPT.exists() else None)
        self.build_main()
        self.log.write("%s %s - licensed to %s (%s)" % (APP_NAME, VERSION, info.get("name"), info.get("role")))
        if "mode" not in self.cfg:
            QTimer.singleShot(300, self.controller_setup)
        else:
            self.apply_output()

    def build_main(self):
        self.built = True
        centre = QWidget()
        cl = QVBoxLayout(centre)
        cl.setContentsMargins(14, 12, 14, 12)
        cl.setSpacing(12)

        # status cards
        cards = QHBoxLayout()
        cards.setSpacing(12)
        self.card_video = self.make_card("VIDEO")
        self.card_ctrl = self.make_card("CONTROLLER")
        self.card_meter = self.make_card("SHOT")
        for c in (self.card_video, self.card_ctrl, self.card_meter):
            cards.addWidget(c[0], 1)
        cl.addLayout(cards)

        # buttons
        row = QHBoxLayout()
        self.mode_btns = QButtonGroup(self)
        for i, label in enumerate(("Meter", "Macro")):
            b = QPushButton(label)
            b.setObjectName("seg")
            b.setCheckable(True)
            b.setToolTip("Meter: reads the shot meter and releases on the green.\n"
                         "Macro: holds X for a set time (STEP UP FN macro), no video needed.")
            self.mode_btns.addButton(b, i)
            row.addWidget(b)
        self.mode_btns.button(1 if self.shot_mode == "macro" else 0).setChecked(True)
        self.mode_btns.idClicked.connect(lambda i: self.set_shot_mode("macro" if i == 1 else "meter"))
        row.addSpacing(8)
        self.meter_btn = QPushButton()
        self.meter_btn.clicked.connect(self.toggle_meter)
        row.addWidget(self.meter_btn)
        b = QPushButton("Shot settings")
        b.setObjectName("big")
        b.clicked.connect(self.shot_settings)
        row.addWidget(b)
        b = QPushButton("Controller setup")
        b.setObjectName("big")
        b.clicked.connect(self.controller_setup)
        row.addWidget(b)
        row.addStretch(1)
        self.adv_btn = QPushButton("Advanced view")
        self.adv_btn.setCheckable(True)
        self.adv_btn.toggled.connect(self.set_advanced)
        row.addWidget(self.adv_btn)
        cl.addLayout(row)

        self.video = VideoWidget()
        cl.addWidget(self.video, 1)
        foot = QLabel("GLCRY METER %s  \u00b7  licensed to %s  \u00b7  help: discord.gg/glcrify" % (VERSION, self.user.get("name") or "-"))
        foot.setObjectName("hint")
        cl.addWidget(foot)
        self.setCentralWidget(centre)
        self.build_advanced()
        self.paint_meter_btn()

        self.t_video = QTimer(self)
        self.t_video.timeout.connect(self.update_video)
        self.t_video.setTimerType(Qt.PreciseTimer)   # check for a new frame every 1 ms so the
        self.t_video.start(1)                        # display keeps up with 240 fps capture
        self.t_ui = QTimer(self)
        self.t_ui.timeout.connect(self.update_ui)
        self.t_ui.start(250)

    def make_card(self, title):
        f = QFrame()
        f.setObjectName("card")
        v = QVBoxLayout(f)
        v.setContentsMargins(16, 12, 16, 14)
        t = QLabel(title)
        t.setObjectName("cardTitle")
        v.addWidget(t)
        txt = QLabel("...")
        txt.setObjectName("cardText")
        txt.setWordWrap(True)
        txt.setTextFormat(Qt.RichText)
        v.addWidget(txt)
        return f, txt

    # ------------------------------------------------------------- advanced
    def build_advanced(self):
        self.docks = []
        # capture
        cap = QWidget()
        cg = QFormLayout(cap)
        self.cam = QComboBox()
        cg.addRow("Capture device", self.cam)
        self.backend = QComboBox()
        self.backend.addItems(["DirectShow", "Media Foundation"])
        self.backend.setCurrentIndex(int(self.cfg.get("backend", 0)))
        cg.addRow("Capture method", self.backend)
        self.res = QComboBox()
        self.res.addItems(["1920x1080", "1280x720", "2560x1440", "3840x2160"])
        i = self.res.findText(self.cfg.get("res", "1920x1080"))
        self.res.setCurrentIndex(max(0, i))
        cg.addRow("Resolution", self.res)
        self.fps = QSpinBox()
        self.fps.setRange(30, 360)
        self.fps.setValue(int(self.cfg.get("fps", 240)))
        cg.addRow("Frame rate", self.fps)
        self.auto_cam = QCheckBox("Find OBS Virtual Camera automatically")
        self.auto_cam.setChecked(bool(self.cfg.get("auto_cam", True)))
        cg.addRow(self.auto_cam)
        r = QHBoxLayout()
        b = QPushButton("Use this device")
        b.clicked.connect(self.manual_capture)
        r.addWidget(b)
        b = QPushButton("Refresh")
        b.clicked.connect(self.refresh_cameras)
        r.addWidget(b)
        b = QPushButton("Play a recording...")
        b.clicked.connect(self.open_video)
        r.addWidget(b)
        cg.addRow(r)
        self.refresh_cameras()

        # scripts
        left = QWidget()
        ll = QVBoxLayout(left)
        SCRIPTS_DIR.mkdir(exist_ok=True)
        self.fs = QFileSystemModel()
        self.fs.setRootPath(str(SCRIPTS_DIR))
        self.fs.setNameFilters(["*.py"])
        self.fs.setNameFilterDisables(False)
        self.fs.setFilter(QDir.AllDirs | QDir.Files | QDir.NoDotAndDotDot)
        self.tree = QTreeView()
        self.tree.setModel(self.fs)
        self.tree.setRootIndex(self.fs.index(str(SCRIPTS_DIR)))
        for c in (1, 2, 3):
            self.tree.hideColumn(c)
        self.tree.setHeaderHidden(True)
        self.tree.doubleClicked.connect(self.tree_pick)
        ll.addWidget(self.tree, 1)
        self.script_lbl = QLabel(self.selected.name if self.selected else "No script selected")
        ll.addWidget(self.script_lbl)
        self.stats_lbl = QLabel("")
        self.stats_lbl.setFont(QFont("Consolas", 9))
        ll.addWidget(self.stats_lbl)
        r = QHBoxLayout()
        b = QPushButton("Run selected")
        b.clicked.connect(self.run_selected)
        r.addWidget(b)
        b = QPushButton("Scripts folder")
        b.clicked.connect(lambda: self.open_path(SCRIPTS_DIR))
        r.addWidget(b)
        b = QPushButton("Data folder")
        b.clicked.connect(lambda: self.open_path(data_root() / "ScriptData"))
        r.addWidget(b)
        ll.addLayout(r)

        # output
        right = QWidget()
        rl = QVBoxLayout(right)
        g = QGroupBox("Output")
        gl = QVBoxLayout(g)
        self.mode_group = QButtonGroup(self)
        self.rb_vpad = QRadioButton("Virtual controller (ViGEm)")
        self.rb_titan = QRadioButton("Titan Two (Gtuner IV bridge)")
        self.rb_prev = QRadioButton("Preview only (send nothing)")
        for i, rb in enumerate((self.rb_vpad, self.rb_titan, self.rb_prev)):
            self.mode_group.addButton(rb, i)
            gl.addWidget(rb)
        {0: self.rb_vpad, 1: self.rb_titan}.get(int(self.cfg.get("mode", 0)), self.rb_prev).setChecked(True)
        form = QFormLayout()
        self.slot = QComboBox()
        self.slot.addItem("Automatic", -1)
        for s in range(4):
            self.slot.addItem("XInput slot %d" % (s + 1), s)
        want = int(self.cfg.get("slot", -1))
        self.slot.setCurrentIndex(want + 1 if -1 <= want <= 3 else 0)
        form.addRow("Controller input", self.slot)
        self.port = QSpinBox()
        self.port.setRange(1024, 65000)
        self.port.setValue(int(self.cfg.get("titan_port", 47654)))
        form.addRow("Titan bridge port", self.port)
        gl.addLayout(form)
        self.latch = QCheckBox("Titan: hold a release until the button is let go")
        self.latch.setChecked(bool(self.cfg.get("titan_latch", True)))
        gl.addWidget(self.latch)
        b = QPushButton("Apply output")
        b.clicked.connect(self.apply_output_adv)
        gl.addWidget(b)
        rl.addWidget(g)
        g = QGroupBox("Device monitor  (input / output)")
        grid = QGridLayout(g)
        self.mon = {}
        rows = [(16, "X / Square"), (15, "A / Cross"), (14, "B / Circle"), (13, "Y / Triangle"),
                (6, "LB / L1"), (3, "RB / R1"), (7, "LT / L2"), (4, "RT / R2"),
                (23, "Left X"), (24, "Left Y"), (21, "Right X"), (22, "Right Y")]
        for r_, (idx, name) in enumerate(rows):
            grid.addWidget(QLabel(name), r_, 0)
            a, o = QLabel("0"), QLabel("0")
            a.setFont(QFont("Consolas", 9))
            o.setFont(QFont("Consolas", 9))
            grid.addWidget(a, r_, 1)
            grid.addWidget(o, r_, 2)
            self.mon[idx] = (a, o)
        rl.addWidget(g)
        rl.addStretch(1)

        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setFont(QFont("Consolas", 9))
        self.console.setMaximumBlockCount(3000)

        for title, w, area in (("Capture", cap, Qt.LeftDockWidgetArea), ("Scripts", left, Qt.LeftDockWidgetArea),
                               ("Output", right, Qt.RightDockWidgetArea),
                               ("Console", self.console, Qt.BottomDockWidgetArea)):
            d = QDockWidget(title, self)
            d.setWidget(w)
            d.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable)
            self.addDockWidget(area, d)
            d.hide()
            self.docks.append(d)

    def set_advanced(self, on):
        for d in self.docks:
            d.setVisible(on)

    # ------------------------------------------------------------- helpers
    def open_path(self, p):
        p = Path(p)
        p.mkdir(parents=True, exist_ok=True)
        if sys.platform == "win32":
            os.startfile(str(p))
        else:
            subprocess.Popen(["xdg-open", str(p)])

    def save(self):
        if not self.built:
            return
        self.cfg.update({
            "backend": self.backend.currentIndex(), "res": self.res.currentText(),
            "fps": self.fps.value(), "auto_cam": self.auto_cam.isChecked(),
            "slot": self.slot.currentData(), "titan_port": self.port.value(),
            "titan_latch": self.latch.isChecked(), "meter_on": self.meter_on,
            "script": str(self.selected) if self.selected else "",
        })
        save_config(self.cfg)

    # ------------------------------------------------------------- capture
    def refresh_cameras(self):
        self.cam.clear()
        for idx, name in list_cameras():
            self.cam.addItem(name, idx)
        i = int(self.cfg.get("camera", 0))
        self.cam.setCurrentIndex(min(max(0, i), max(0, self.cam.count() - 1)))

    def _open_capture(self, index):
        w, h = (int(v) for v in self.res.currentText().split("x"))
        return self.engine.source.open(index, w, h, self.fps.value(),
                                       "dshow" if self.backend.currentIndex() == 0 else "msmf")

    def manual_capture(self):
        self.auto_cam.setChecked(False)
        self.cfg["camera"] = self.cam.currentIndex()
        self._open_capture(self.cam.currentData())
        self.save()

    def open_video(self):
        p, _ = QFileDialog.getOpenFileName(self, "Play a recording", str(Path.home()),
                                           "Video (*.mp4 *.mkv *.avi *.mov)")
        if p:
            self.auto_cam.setChecked(False)
            self.engine.source.open(p)

    def auto_capture(self):
        """Keep video running: find OBS Virtual Camera, reopen if frames stop."""
        src = self.engine.source
        now = time.monotonic()
        if src.running:
            age = (time.perf_counter_ns() - src.ts_ns) / 1e9 if src.ts_ns else 0.0
            if age > 3.0 and not src.is_file:
                self.log.write("Video stopped arriving - reconnecting")
                src.close()
            return
        if not self.auto_cam.isChecked() or now < self.next_cam_try:
            return
        self.next_cam_try = now + 3.0
        idx = find_obs_camera()
        if idx is not None:
            self._open_capture(idx)

    # ------------------------------------------------------------- script
    def tree_pick(self, index):
        p = Path(self.fs.filePath(index))
        if p.is_file() and p.suffix == ".py":
            self.selected = p
            self.script_lbl.setText(p.name)
            self.save()

    def run_selected(self):
        idx = self.tree.currentIndex()
        if idx.isValid():
            self.tree_pick(idx)
        if self.selected:
            self.meter_on = True
            if self.shot_mode != "meter":
                self.mode_btns.button(0).setChecked(True)
                self.set_shot_mode("meter")
            self.engine.load_script(self.selected)
            self.paint_meter_btn()
            self.save()

    def toggle_meter(self):
        self.meter_on = not self.meter_on
        self.engine.error = None
        if not self.meter_on:
            self.engine.stop_script()
        self.sync_macro()
        self.paint_meter_btn()
        self.save()

    def set_shot_mode(self, mode):
        if mode == self.shot_mode:
            return
        self.shot_mode = mode
        self.cfg["shot_mode"] = mode
        if mode == "macro":
            self.engine.stop_script()        # the meter must not release as well
            out = self.engine.output
            if out is not None:
                try:
                    out.send_cvdata(bytes(len(out.packet)))   # drop any meter overrides
                except Exception:
                    pass
            if isinstance(out, TitanOutput):
                QMessageBox.information(
                    self, "Macro with a Titan Two",
                    "With a Titan Two the macro runs on the Titan itself, for exact timing.\n\n"
                    "In Gtuner IV, put STEP_UP_FN_Shot_Macro_Titan_Two.gpc (in GLCRY METER's 'titan' "
                    "folder) on your Titan Two and run it instead of the bridge.")
        self.log.write("Shot mode: %s" % ("Macro" if mode == "macro" else "Meter"))
        self.sync_macro()
        self.paint_meter_btn()
        self.save()

    def sync_macro(self):
        """Hand the macro to the virtual controller and switch it on or off."""
        out = self.engine.output
        self.macro.enabled = self.shot_mode == "macro" and self.meter_on
        if isinstance(out, VirtualPadOutput):
            out.macro = self.macro

    def macro_changed(self):
        self.macro.update(self.macro.s)
        self.cfg["macro"] = self.macro.s
        save_config(self.cfg)

    def paint_meter_btn(self):
        label = "Macro" if getattr(self, "shot_mode", "meter") == "macro" else "Shot meter"
        self.meter_btn.setText("%s: %s" % (label, "ON" if self.meter_on else "OFF"))
        self.meter_btn.setObjectName("on" if self.meter_on else "off")
        repolish(self.meter_btn)

    def auto_script(self):
        if self.shot_mode == "meter" and self.meter_on and not self.engine.running and self.selected and self.engine.source.running \
                and self.engine.error is None:
            self.engine.load_script(self.selected)

    def shot_settings(self):
        if self.shot_mode == "macro":
            MacroSettingsDialog(self, self.macro.s, self.macro_changed).exec()
            return
        stem = self.selected.stem if self.selected else "NBA2K21_Meter"
        ShotSettingsDialog(self, stem).exec()

    # ------------------------------------------------------------- output
    def controller_setup(self):
        d = SetupDialog(self)
        if d.exec() and d.choice is not None:
            self.cfg["mode"] = d.choice
            (self.rb_vpad if d.choice == 0 else self.rb_titan).setChecked(True)
            self.apply_output()
            if d.choice == 1:
                QMessageBox.information(
                    self, "Titan Two setup",
                    "1. In Gtuner IV, put GLCRY_METER_Bridge.gpc on your Titan Two and run it.\n"
                    "2. In Gtuner IV's Computer Vision tab, open GLCRY_METER_GtunerBridge.py and press Start.\n\n"
                    "Both files are in GLCRY METER's 'titan' folder (Advanced view > Scripts folder, one level up).\n"
                    "The Controller card turns green when it's linked.")

    def apply_output_adv(self):
        self.cfg["mode"] = self.mode_group.checkedId()
        self.apply_output()

    def apply_output(self):
        mode = int(self.cfg.get("mode", 0))
        want = self.slot.currentData()
        slot = want if want is not None and want >= 0 else (pick_input_slot(int(self.cfg.get("last_slot", 0))) or 0)
        old = self.engine.output
        if old is not None:
            # close the old output first: its virtual pad must be gone before
            # the new one hides controllers, or it would get hidden too
            try:
                old.close()
            except Exception:
                pass
        if mode == 0:
            out = VirtualPadOutput(self.log, slot)
        elif mode == 1:
            out = TitanOutput(self.log, slot, self.port.value(), self.latch.isChecked())
        else:
            out = PreviewOutput(self.log, slot)
        self.engine.set_output(out)
        self.sync_macro()
        self.log.write("Output: %s, controller on slot %d" % (out.name, slot + 1))
        self.save()

    def auto_slot(self):
        out = self.engine.output
        if out is None or self.slot.currentData() not in (None, -1):
            return
        if not out.reader.connected:
            s = pick_input_slot(out.reader.slot, exclude=out.virtual_slot)
            if s is not None and s != out.reader.slot:
                out.reader.slot = s
                self.cfg["last_slot"] = s
                self.log.write("Controller found on slot %d" % (s + 1))

    # ------------------------------------------------------------- timers
    def update_video(self):
        if self.engine.running:
            with self.engine.lock:
                frame, cmds, seq = self.engine.display
        else:
            frame, cmds, seq = self.engine.preview_display()
        if frame is None:
            if self.video.img is not None and not self.engine.source.running:
                self.video.set_image(None)
            return
        if seq == self.disp_seq:
            return
        self.disp_seq = seq
        img = render.compose(frame, cmds, self.video.width(), self.video.height())
        h, w = img.shape[:2]
        fmt = getattr(QImage, "Format_BGR888", None)
        if fmt is not None:
            # wrap the BGR frame directly (no colour conversion, no copy); keep the
            # array alive for as long as the widget shows it
            self.video.buf = img
            self.video.set_image(QImage(img.data, w, h, img.strides[0], fmt))
        else:
            rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            self.video.set_image(QImage(rgb.data, w, h, 3 * w, QImage.Format_RGB888).copy())
        self.disp_n += 1
        now = time.perf_counter()
        if now - self.disp_t >= 1.0:
            self.disp_fps = self.disp_n / (now - self.disp_t)
            self.disp_n, self.disp_t = 0, now

    def update_ui(self):
        if self.relock_reason:
            self.relock(self.relock_reason)
            return
        self.auto_capture()
        self.auto_slot()
        self.auto_script()
        src, st, out = self.engine.source, self.engine.stats, self.engine.output

        # video card
        if src.running:
            self.card_video[1].setText("%s Connected  -  %dx%d at %.0f fps" % (
                dot(GREEN if src.fps_measured >= 100 or src.is_file else AMBER),
                src.size[0], src.size[1], src.fps_measured))
            self.video.empty_text = "Waiting for video..."
        elif self.auto_cam.isChecked():
            self.card_video[1].setText("%s Waiting for OBS<br><small>Open OBS and press "
                                       "<b>Start Virtual Camera</b>.</small>" % dot(AMBER))
            self.video.empty_text = "Open OBS and press Start Virtual Camera - the video will appear here."
        else:
            self.card_video[1].setText("%s No video<br><small>Pick a device in Advanced view.</small>" % dot(RED))

        # controller card
        if out is not None:
            pad = out.reader.connected
            if isinstance(out, VirtualPadOutput):
                if out.pad is None:
                    txt = "%s Virtual controller driver missing<br><small>Run the GLCRY METER installer again.</small>" % dot(RED)
                elif not pad:
                    txt = "%s Plug in your controller<br><small>USB or Bluetooth.</small>" % dot(AMBER)
                elif not out.hidden:
                    txt = ("%s The game can still see your real controller<br><small>%s Press <b>Controller setup</b> "
                           "and pick the virtual controller again to retry.</small>" % (dot(RED), out.hide_error))
                else:
                    txt = "%s Ready  -  your controller is passed to the game" % dot(GREEN)
            elif isinstance(out, TitanOutput):
                linked = "connected" in out.status
                if not linked:
                    txt = "%s Titan Two: open Gtuner IV<br><small>Run GLCRY_METER_Bridge.gpc and start "\
                          "GLCRY_METER_GtunerBridge.py in Computer Vision.</small>" % dot(AMBER)
                elif not pad:
                    txt = "%s Titan Two linked - waiting for its controller output" % dot(AMBER)
                else:
                    txt = "%s Titan Two linked  -  %.0f fps" % (dot(GREEN), out.bridge_fps)
            else:
                txt = "%s Preview only - nothing is sent to the game" % dot(GREY)
            self.card_ctrl[1].setText(txt)

        # meter card
        if self.macro.changed:                    # profile switched in game (LT + View)
            self.macro.changed = False
            self.macro_changed()
        if self.shot_mode == "macro":
            t = self.macro.times()
            if not self.meter_on:
                txt = "%s Macro off" % dot(GREY)
            elif isinstance(out, TitanOutput):
                txt = "%s Macro runs on your Titan Two<br><small>Load STEP_UP_FN_Shot_Macro_Titan_Two.gpc in Gtuner IV.</small>" % dot(AMBER)
            else:
                txt = "%s Macro  -  %s  -  shot %d, fades %d / %d ms" % (
                    dot(GREEN), self.macro.profile().upper(), t["shot"], t["fade_left"], t["fade_right"])
                if self.macro.last:
                    txt += "<br><small>Last: %s</small>" % self.macro.last
            self.card_meter[1].setText(txt)
        elif not self.meter_on:
            self.card_meter[1].setText("%s Off" % dot(GREY))
        elif self.engine.error:
            self.card_meter[1].setText("%s Stopped - %s<br><small>See Advanced view > Console.</small>" % (
                dot(RED), self.engine.error))
        elif self.engine.running:
            self.card_meter[1].setText("%s Running  -  %.0f fps, %.1f ms" % (
                dot(GREEN), st["script_fps"], st["process_ms"]))
        else:
            self.card_meter[1].setText("%s Starts when video arrives" % dot(AMBER))

        self.video.info = "Capture %.0f fps   Processing %.0f fps   Display %.0f fps" % (
            src.fps_measured, st["script_fps"] if self.engine.running else 0, self.disp_fps) if src.running else ""

        if self.adv_btn.isChecked():
            self.stats_lbl.setText("Script FPS: %.0f   Process: %.2f ms   Jitter: %.2f ms" % (
                st["script_fps"], st["process_ms"], st["jitter_ms"]) if self.engine.running else "Not running")
            if out is not None:
                ov, iv = out.output_values(), out.reader.values
                for idx, (a, o) in self.mon.items():
                    a.setText("%4.0f" % iv[idx])
                    o.setText("%4.0f" % ov[idx])
        seq, lines = self.log.snapshot()
        if seq != self.log_seq:
            new = seq - self.log_seq
            self.log_seq = seq
            for ln in lines[-min(new, len(lines)):]:
                self.console.appendPlainText(ln)

    def closeEvent(self, e):
        if self.engine is not None and self.built:
            self.save()
            self.engine.shutdown()
        e.accept()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyleSheet(STYLE)
    app.setWindowIcon(QIcon(str(APP_DIR / "glcry" / "icon.ico")))
    w = Main()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
