<# : GLCRY METER - give my controller back (double-click)
@echo off
title GLCRY METER - Fix my controller
set "GLCRY_FIX=%~f0"
net session >nul 2>&1
if not errorlevel 1 goto admin
powershell -NoProfile -Command "Start-Process -FilePath $env:GLCRY_FIX -Verb RunAs"
exit /b
:admin
powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ([IO.File]::ReadAllText($env:GLCRY_FIX))"
exit /b
#>
$ErrorActionPreference = 'Continue'
Write-Host ''
Write-Host '   GLCRY METER - Fix my controller' -ForegroundColor White
Write-Host '   This shows your controller to every game again.' -ForegroundColor Gray
Write-Host ''
Get-Process pythonw, python -ErrorAction SilentlyContinue | Where-Object { $_.Path -like '*GLCRY METER*' -or $_.Path -like '*NovaCV*' } | Stop-Process -Force -ErrorAction SilentlyContinue
$cli = Get-ChildItem -Path "$env:ProgramFiles\Nefarius Software Solutions" -Filter HidHideCLI.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if ($cli) {
    & $cli.FullName --cloak-off | Out-Null
    $list = (& $cli.FullName --dev-list 2>&1) -join "`n"
    $paths = [regex]::Matches($list, '(?:HID|USB|BTHENUM|BTHLEDEVICE|ROOT)\\\\?[^\s"\],]+') | ForEach-Object { $_.Value -replace '\\\\', '\' } | Sort-Object -Unique
    foreach ($p in $paths) { & $cli.FullName --dev-unhide $p | Out-Null; Write-Host "   Un-hid $p" -ForegroundColor Gray }
    Write-Host '   Hiding switched off and the hidden list cleared.' -ForegroundColor Green
} else {
    Write-Host '   HidHide is not installed - nothing to undo.' -ForegroundColor Gray
}
# Restart game controllers so games notice them again
Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object { $_.InstanceId -match 'VID_045E|VID_054C|XUSB|IG_' -and $_.Class -match 'HIDClass|XnaComposite|USB|System' } | ForEach-Object {
    pnputil /restart-device "$($_.InstanceId)" | Out-Null
}
Write-Host ''
Write-Host '   Done. If your controller still does nothing, unplug it and plug it back in.' -ForegroundColor Green
Read-Host '   Press Enter to close'
